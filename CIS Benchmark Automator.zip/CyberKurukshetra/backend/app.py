from flask import Flask, render_template, request, jsonify, redirect, url_for
from routes.audit import audit_bp
from routes.results import results_bp
from routes.auth import auth_bp
from flask_jwt_extended import JWTManager
from utils.os_detection import get_os_info
import webbrowser
import threading

app = Flask(__name__, template_folder='../frontend/templates', static_folder='../frontend/static')
app.config['JWT_SECRET_KEY'] = 'SIH2024'

jwt = JWTManager(app)

# Register blueprints
app.register_blueprint(audit_bp)
app.register_blueprint(results_bp)
app.register_blueprint(auth_bp)

@app.route('/')
@app.route('/home')
def home():
    # Redirect to the login page
    return redirect(url_for('login_page'))

@app.route('/login')
def login_page():
    return render_template('login.html')

@app.route('/audit')
def audit_page():
    os_info = get_os_info()
    return render_template('audit.html', os_type=os_info['os_display'], os_version=os_info['os_version'])

@app.route('/signup', methods=['POST'])
def signup():
    data = request.get_json()
    username = data.get('username')
    email = data.get('email')
    password = data.get('password')
    # Add your signup logic here (e.g., save to database)
    # If signup is successful:
    return jsonify({'success': True, 'message': 'User created successfully'}), 201
    # If signup fails:
    # return jsonify({'success': False, 'message': 'Signup failed'}), 400

@app.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')
    # Add your login logic here (e.g., check credentials)
    return jsonify({'success': True, 'message': 'Login successful!'}), 200

def open_browser():
    webbrowser.open('http://127.0.0.1:5000/login')

if __name__ == '__main__':
    # Use threading to open the browser after the app starts
    threading.Timer(1, open_browser).start()
    app.run(debug=True, use_reloader=False)
