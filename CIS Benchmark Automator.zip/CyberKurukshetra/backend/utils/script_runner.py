import subprocess

def run_audit_script(command):
    result = subprocess.run(command, capture_output=True, text=True)
    print("Script Output:", result.stdout)
    print("Script Error:", result.stderr)
    return result.stdout