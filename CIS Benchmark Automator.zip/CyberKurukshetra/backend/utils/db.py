from pymongo import MongoClient

client = MongoClient('mongodb://localhost:27017/')
db = client['audit_tool']
users_collection = db['users']
audit_results_collection = db['audit_results']