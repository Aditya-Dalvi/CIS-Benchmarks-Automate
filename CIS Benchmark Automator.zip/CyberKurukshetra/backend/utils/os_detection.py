import platform
import re

def get_os_info():
    os_type = platform.system()
    os_release = platform.release()
    os_version = platform.version()
    
    # Check if it's Windows 11 based on version
    if os_type == "Windows" and os_release == "10" and re.match(r"10\.0\.22\d{3}", os_version):
        os_display = "Windows 11"
    else:
        os_display = f"{os_type} {os_release}"
    
    return {
        "os_type": os_type,
        "os_release": os_release,
        "os_version": os_version,
        "os_display": os_display
    }