from flask import Blueprint, jsonify, render_template
from utils.os_detection import get_os_info
from utils.script_runner import run_audit_script
from utils.db import db
import json
import os

audit_bp = Blueprint('audit', __name__)

@audit_bp.route('/')
def index():
    os_info = get_os_info()
    return render_template('index.html', os_type=os_info['os_display'], os_version=os_info['os_version'])

@audit_bp.route('/api/audit', methods=['POST'])
def run_audit():
    os_info = get_os_info()
    
    if os_info['os_display'] == "Windows 11":
        script_path = os.path.join(os.path.dirname(__file__), '..', 'scripts', 'windows_11_audit.ps1')
        result = run_audit_script(["powershell", "-ExecutionPolicy", "Bypass", "-File", script_path])
    else:
        return jsonify({"error": "Unsupported OS type. This script only runs on Windows 11."}), 400

    try:
        audit_results = json.loads(result)
    except json.JSONDecodeError:
        return jsonify({"error": "Failed to parse audit results"}), 500

    # Save results to MongoDB
    inserted_result = db.audit_results.insert_one(audit_results)

    # Fetch the inserted document, excluding ObjectId
    saved_result = db.audit_results.find_one({"_id": inserted_result.inserted_id}, {"_id": 0})
    
    return jsonify({
        "message": "Audit completed successfully.",
        "results": saved_result
    }), 200

