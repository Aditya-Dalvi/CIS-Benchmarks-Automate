from flask import Blueprint, request, jsonify
from flask_bcrypt import Bcrypt
from flask_jwt_extended import JWTManager, create_access_token
from utils.db import users_collection

auth_bp = Blueprint('auth', __name__)
bcrypt = Bcrypt()
jwt = JWTManager()

@auth_bp.route('/signup', methods=['POST'])
def signup():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')
    email = data.get('email')

    if users_collection.find_one({'username': username}):
        return jsonify({"error": "User already exists"}), 400

    if users_collection.find_one({'email': email}):
        return jsonify({"error": "Email already in use"}), 400

    hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')
    users_collection.insert_one({'username': username, 'password': hashed_password, 'email': email})

    return jsonify({"message": "User created successfully"}), 201

@auth_bp.route('/signin', methods=['POST'])
def signin():
    try:
        data = request.get_json()
        username = data.get('username')
        password = data.get('password')

        print(f"Signin attempt: username={username}, password={password}")

        user = users_collection.find_one({'username': username})
        if user:
            print(f"User found: {user}")
            if bcrypt.check_password_hash(user['password'], password):
                access_token = create_access_token(identity=username)
                print(f"Signin successful: access_token={access_token}")
                return jsonify(access_token=access_token), 200
            else:
                print("Invalid password")
        else:
            print("User not found")

        return jsonify({"error": "Invalid credentials"}), 401
    except Exception as e:
        print(f"Error during signin: {e}")
        return jsonify({"error": "An error occurred during signin"}), 500