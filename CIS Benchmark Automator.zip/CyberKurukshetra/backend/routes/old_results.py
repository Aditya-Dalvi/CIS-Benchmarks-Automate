from flask import Blueprint, jsonify
import os
import json
from utils.os_detection import get_os_info

results_bp = Blueprint('results', __name__)

@results_bp.route('/api/results', methods=['GET'])
def get_results():
    os_info = get_os_info()
    
    if os_info['os_display'] == "Windows 11":
        result_file = 'windows11Standalone_audit_results.json'
    else:
        return jsonify({"error": "Unsupported OS type or no results available for this OS."}), 400
    
    try:
        with open(os.path.join(os.path.dirname(__file__), '..', '..', 'results', result_file), 'r') as f:
            return jsonify(json.load(f))
    except FileNotFoundError:
        return jsonify({"error": "No results found"}), 404
