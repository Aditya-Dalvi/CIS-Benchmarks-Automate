from flask import Blueprint, jsonify
import os
import json
from utils.os_detection import get_os_info
from utils.db import audit_results_collection  # Import collection reference

# Create Blueprint
results_bp = Blueprint('results', __name__, url_prefix='/api/results')

@results_bp.route('/', methods=['GET'])
def get_results():
    # Get OS Information
    os_info = get_os_info()
    
    # Determine appropriate file based on OS
    if os_info['os_display'] == "Windows 11":
        result_file = 'windows11Standalone_audit_results.json'
    elif "Linux" in os_info['os_display']:
        result_file = 'ubuntu_audit_results.json'
    else:
        return jsonify({"error": "Unsupported OS type or no results available for this OS."}), 400

    # First, attempt to load results from MongoDB
    try:
        results = list(audit_results_collection.find({}, {'_id': 0}))  # Use imported collection
        if results:
            return jsonify(results), 200  # Return results from MongoDB
    except Exception as e:
        print(f"Error accessing MongoDB: {e}")
    
    # If MongoDB has no results or is inaccessible, fallback to JSON file
    try:
        with open(os.path.join(os.path.dirname(__file__), '..', '..', 'results', result_file), 'r') as f:
            file_results = json.load(f)
            return jsonify(file_results), 200  # Return results from JSON file
    except FileNotFoundError:
        print(f"Result file not found: {result_file}")
        return jsonify({"error": "No results found in MongoDB or file system."}), 404
    except json.JSONDecodeError as e:
        print(f"Error decoding JSON file {result_file}: {e}")
        return jsonify({"error": "Error parsing JSON results file."}), 500
