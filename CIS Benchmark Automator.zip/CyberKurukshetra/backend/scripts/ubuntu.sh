#!/bin/bash

# Ensure the script is run with root privileges
if [ "$EUID" -ne 0 ]; then
    echo "Please run this script as root (use sudo)."
    exit 1
fi

# Function to handle errors
handle_error() {
    local control_id=$1
    local error_message=$2
    categorized_results["$control_id"]="{\"is_compliant\": false, \"non_compliance_reasons\": \"$error_message\"}"
}

# Output file
OUTPUT_DIR="../results"
OUTPUT_FILE="$OUTPUT_DIR/ubuntu_audit_results.json"
mkdir -p "$OUTPUT_DIR"

# Timestamp for report generation
TIMESTAMP=$(date --iso-8601=seconds)

# Initialize data structures
declare -A categorized_results
report_metadata="{\"audit_scope\": \"Ubuntu 22.04\", \"generated_by\": \"System Auditor\", \"generated_on\": \"$TIMESTAMP\", \"report_title\": \"Extended Compliance Report\", \"report_version\": \"2.0\"}"

summary="{\"total_controls\": 0, \"compliant_controls\": 0, \"non_compliant_controls\": 0, \"compliance_percentage\": 0, \"priority_breakdown\": {\"High\": 0, \"Medium\": 0, \"Low\": 0}, \"severity_breakdown\": {\"High\": 0, \"Medium\": 0, \"Low\": 0}}"

# Helper function to update compliance summary
update_summary() {
    local compliant=$1
    local priority=$2
    local severity=$3
    summary=$(jq \
        --argjson compliant $compliant \
        --argjson priority_update "{\"$priority\": 1}" \
        --argjson severity_update "{\"$severity\": 1}" \
        '
        .total_controls += 1 |
        if $compliant then
            .compliant_controls += 1
        else
            .non_compliant_controls += 1
        end |
        .priority_breakdown += $priority_update |
        .severity_breakdown += $severity_update |
        .compliance_percentage = (.compliant_controls / .total_controls * 100)
        ' <<< "$summary")
}

# General function to check a kernel module
check_kernel_module() {
    local control_id=$1
    local category=$2
    local priority=$3
    local severity=$4
    local description=$5
    local corrective_action=$6
    local recommendation=$7
    local module_name=$8

    local command="lsmod | grep -w $module_name"
    local denylist_command="grep -E 'blacklist[[:space:]]+$module_name' /etc/modprobe.d/*.conf"
    local is_compliant=false
    local non_compliance_reason=""

    # Check if module exists
    if modinfo "$module_name" &>/dev/null; then
        # Check if module is loaded
        if $command > /dev/null 2>&1; then
            is_compliant=false
            non_compliance_reason="Module $module_name is loaded in the kernel."
        # Check if module is deny listed
        elif ! $denylist_command > /dev/null 2>&1; then
            is_compliant=false
            non_compliance_reason="Module $module_name is not deny listed in modprobe configuration."
        else
            is_compliant=true
        fi
    else
        is_compliant=true
    fi

    categorized_results["$control_id"]="{\"category\": \"$category\", \"control_id\": \"$control_id\", \"description\": \"$description\", \"corrective_action\": \"$corrective_action\", \"recommendation\": \"$recommendation\", \"frequency_checked\": 1, \"is_compliant\": $is_compliant, \"last_checked\": \"$TIMESTAMP\", \"non_compliance_reasons\": \"$non_compliance_reason\", \"priority\": \"$priority\", \"priority_score\": 3, \"severity\": \"$severity\", \"severity_score\": 3}"

    update_summary $is_compliant "$priority" "$severity"
}

# Function to check service compliance
check_service() {
    local control_id=$1
    local category=$2
    local priority=$3
    local severity=$4
    local description=$5
    local corrective_action=$6
    local recommendation=$7
    local package_name=$8
    local service_name=$9

    local is_compliant=true
    local non_compliance_reason=""

    # Check if package is installed
    if dpkg-query -W -f='${Status}' "$package_name" 2>/dev/null | grep -q "ok installed"; then
        # Check if service exists
        if systemctl list-unit-files | grep -q "^$service_name"; then
            # Check if service is enabled
            if systemctl is-enabled "$service_name" &>/dev/null; then
                is_compliant=false
                non_compliance_reason="$service_name is enabled. "
            fi
            
            # Check if service is active
            if systemctl is-active "$service_name" &>/dev/null; then
                is_compliant=false
                non_compliance_reason+="$service_name is running. "
            fi
            
            # Check if service is masked
            if ! systemctl is-masked "$service_name" &>/dev/null; then
                is_compliant=false
                non_compliance_reason+="$service_name is not masked. "
            fi
        fi
        
        # If package is installed but service not enabled/active
        if [ "$is_compliant" = true ]; then
            non_compliance_reason="$package_name is installed but service is not running or enabled."
        fi
    fi

    categorized_results["$control_id"]="{\"category\": \"$category\", \"control_id\": \"$control_id\", \"description\": \"$description\", \"corrective_action\": \"$corrective_action\", \"recommendation\": \"$recommendation\", \"frequency_checked\": 1, \"is_compliant\": $is_compliant, \"last_checked\": \"$TIMESTAMP\", \"non_compliance_reasons\": \"$non_compliance_reason\", \"priority\": \"$priority\", \"priority_score\": 2, \"severity\": \"$severity\", \"severity_score\": 2}"

    update_summary $is_compliant "$priority" "$severity"
}

# Function to check file permissions and ownership
check_file_permissions() {
    local file_path=$1
    local expected_perms=$2
    local expected_owner=$3
    local expected_group=$4
    
    local actual_perms=$(stat -c %a "$file_path" 2>/dev/null)
    local actual_owner=$(stat -c %U "$file_path" 2>/dev/null)
    local actual_group=$(stat -c %G "$file_path" 2>/dev/null)
    
    if [ "$actual_perms" != "$expected_perms" ] || \
       [ "$actual_owner" != "$expected_owner" ] || \
       [ "$actual_group" != "$expected_group" ]; then
        return 1
    fi
    return 0
}

# Kernel module checks
check_kernel_module "1.1.1.1" "Filesystem" "High" "High" "Ensure cramfs kernel module is not available" \
    "Remove the cramfs module or deny list it." "Ensure cramfs is removed or deny listed." "cramfs"

check_kernel_module "1.1.1.2" "Filesystem" "High" "High" "Ensure freevxfs kernel module is not available" \
    "Remove or deny list the freevxfs module." "Ensure freevxfs is removed or deny listed." "freevxfs"

check_kernel_module "1.1.1.3" "Filesystem" "High" "High" "Ensure hfs kernel module is not available" \
    "Remove or deny list the hfs module." "Ensure hfs is removed or deny listed." "hfs"

check_kernel_module "1.1.1.4" "Filesystem" "High" "High" "Ensure hfsplus kernel module is not available" \
    "Remove or deny list the hfsplus module." "Ensure hfsplus is removed or deny listed." "hfsplus"

check_kernel_module "1.1.1.5" "Filesystem" "High" "High" "Ensure jffs2 kernel module is not available" \
    "Remove or deny list the jffs2 module." "Ensure jffs2 is removed or deny listed." "jffs2"

check_kernel_module "1.1.1.6" "Filesystem" "High" "High" "Ensure squashfs kernel module is not available" \
    "Remove or deny list the squashfs module. Note: Disabling squashfs may affect Snap packages." \
    "Ensure squashfs is removed or deny listed if not required by Snap applications." "squashfs"

check_kernel_module "1.1.1.7" "Filesystem" "Medium" "Medium" "Ensure udf kernel module is not available" \
    "Remove or deny list the udf module." "Ensure udf is removed or deny listed." "udf"

check_kernel_module "1.1.1.8" "Filesystem" "High" "High" "Ensure usb-storage kernel module is not available" \
    "Remove or deny list the usb-storage module." "Ensure usb-storage is removed or deny listed." "usb-storage"

# Service checks
check_service "2.1.1" "Services" "Medium" "Medium" "Ensure autofs services are not in use" \
    "Uninstall autofs or stop and mask the autofs service if dependent packages require it." \
    "Ensure autofs is not installed, or its service is stopped and masked if required by dependencies." \
    "autofs" "autofs.service"

check_service "2.1.2" "Services" "Medium" "Medium" "Ensure avahi daemon services are not in use" \
    "Uninstall avahi-daemon or stop and mask the avahi-daemon services and socket if dependent packages require it." \
    "Ensure avahi-daemon is not installed, or its services and socket are stopped and masked if required by dependencies." \
    "avahi-daemon" "avahi-daemon.service"

check_service "2.1.3" "Services" "Medium" "Medium" "Ensure DHCP server services are not in use" \
    "Uninstall isc-dhcp-server or stop and mask isc-dhcp-server.service and isc-dhcp-server6.service if dependent packages require it." \
    "Ensure isc-dhcp-server is not installed, or its services are stopped and masked if required by dependencies." \
    "isc-dhcp-server" "isc-dhcp-server.service"

check_service "2.1.4" "Services" "Medium" "Medium" "Ensure DNS server services are not in use" \
    "Uninstall bind9 or stop and mask the bind9.service if dependent packages require it." \
    "Ensure bind9 is not installed, or its service is stopped and masked if required by dependencies." \
    "bind9" "bind9.service"

check_service "2.1.5" "Services" "Medium" "Medium" "Ensure dnsmasq services are not in use" \
    "Uninstall dnsmasq or stop and mask the dnsmasq service if dependent packages require it." \
    "Ensure dnsmasq is not installed, or its service is stopped and masked if required by dependencies." \
    "dnsmasq" "dnsmasq.service"

check_service "2.1.6" "Services" "Medium" "Medium" "Ensure FTP server services are not in use" \
    "Uninstall vsftpd or stop and mask the vsftpd service if dependent packages require it." \
    "Ensure vsftpd is not installed, or its service is stopped and masked if required by dependencies." \
    "vsftpd" "vsftpd.service"

check_service "2.1.7" "Services" "Medium" "Medium" "Ensure LDAP server services are not in use" \
    "Uninstall slapd or stop and mask the slapd service if dependent packages require it." \
    "Ensure slapd is not installed, or its service is stopped and masked if required by dependencies." \
    "slapd" "slapd.service"

# Compile categorized results into JSON
categorized_results_json=$(printf '%s\n' "${categorized_results[@]}" | jq -s 'reduce .[] as $item ({}; .[$item.category] += [$item])')

# Combine metadata, summary, and categorized results into final JSON
final_report=$(jq -n \
    --argjson metadata "$report_metadata" \
    --argjson summary "$summary" \
    --argjson categorized_results "$categorized_results_json" \
    '{report_metadata: $metadata, summary: $summary, categorized_results: $categorized_results}')

# Write to output file
echo "$final_report" > "$OUTPUT_FILE"

# Notify user
echo "Audit completed. Results saved to $OUTPUT_FILE"
