# Create an ordered dictionary to store audit results
$auditResults = [ordered]@{}

# Function to add results to the dictionary with a consistent structure
function Add-Result {
    param (
        [string]$Control,
        [string]$Status,
        [string]$Message,
        [string]$Description,
        [string]$Category,
        [string]$Priority,
        [string]$Severity,
        [string]$Recommendation,
        [string]$CorrectiveAction,
        [string]$Presence
    )
    $auditResults[$Control] = @{
        Status = $Status
        Message = $Message
        Description = $Description
        Category = $Category
        Priority = $Priority
        Severity = $Severity
        Recommendation = $Recommendation
        CorrectiveAction = $CorrectiveAction
        Presence = $Presence
        LastChecked = (Get-Date).ToString("o")
    }
}

# Start auditing
try {
    # Ensure 'Enforce password history' is set to '24 or more passwords'
    $passwordHistory = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Netlogon\Parameters" -Name "PasswordHistorySize" -ErrorAction Stop
    if ($passwordHistory.PasswordHistorySize -ge 24) {
        Add-Result "1.1.1" "Pass" "Enforce password history is set to 24 or more passwords." "Ensure 'Enforce password history' is set to '24 or more passwords'" "Password Policy" "High" "High" "Ensure the password history is set to 24 or more passwords." "Review and update the password history settings."
    } elseif ($passwordHistory -eq $null) {
        Add-Result "1.1.1" "Null" "Enforce password history setting is missing." "Ensure 'Enforce password history' is set to '24 or more passwords'" "Password Policy" "High" "High" "Ensure the password history is set to 24 or more passwords." "Review and update the password history settings."
    } else {
        Add-Result "1.1.1" "Fail" "Enforce password history is less than 24 passwords." "Ensure 'Enforce password history' is set to '24 or more passwords'" "Password Policy" "High" "High" "Ensure the password history is set to 24 or more passwords." "Review and update the password history settings."
    }
} catch {
    Add-Result "1.1.1" "Error" "Could not check 'Enforce password history'. Error: $($_.Exception.Message)" "Ensure 'Enforce password history' is set to '24 or more passwords'" "Password Policy" "High" "High" "Ensure the password history is set to 24 or more passwords." "Review and update the password history settings."
}

try {
    # Ensure 'Maximum password age' is set to '365 or fewer days, but not 0'
    $maxPasswordAge = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Netlogon\Parameters" -Name "MaximumPasswordAge" -ErrorAction Stop
    if ($maxPasswordAge.MaximumPasswordAge -le 365 -and $maxPasswordAge.MaximumPasswordAge -gt 0) {
        Add-Result "1.1.2" "Pass" "Maximum password age is set correctly." "Ensure 'Maximum password age' is set to '365 or fewer days, but not 0'" "Password Policy" "Medium" "Medium" "Ensure the maximum password age is set to 365 or fewer days, but not 0." "Review and update the maximum password age settings."
    } elseif ($maxPasswordAge -eq $null) {
        Add-Result "1.1.2" "Null" "Maximum password age setting is missing." "Ensure 'Maximum password age' is set to '365 or fewer days, but not 0'" "Password Policy" "Medium" "Medium" "Ensure the maximum password age is set to 365 or fewer days, but not 0." "Review and update the maximum password age settings."
    } else {
        Add-Result "1.1.2" "Fail" "Maximum password age is not within the recommended range." "Ensure 'Maximum password age' is set to '365 or fewer days, but not 0'" "Password Policy" "Medium" "Medium" "Ensure the maximum password age is set to 365 or fewer days, but not 0." "Review and update the maximum password age settings."
    }
} catch {
    Add-Result "1.1.2" "Error" "Could not check 'Maximum password age'. Error: $($_.Exception.Message)" "Ensure 'Maximum password age' is set to '365 or fewer days, but not 0'" "Password Policy" "Medium" "Medium" "Ensure the maximum password age is set to 365 or fewer days, but not 0." "Review and update the maximum password age settings."
}

try {
    # Ensure 'Minimum password age' is set to '1 or more days'
    $minPasswordAge = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Netlogon\Parameters" -Name "MinimumPasswordAge" -ErrorAction Stop
    if ($minPasswordAge.MinimumPasswordAge -ge 1) {
        Add-Result "1.1.3" "Pass" "Minimum password age is set correctly." "Ensure 'Minimum password age' is set to '1 or more days'" "Password Policy" "Low" "Low" "Ensure the minimum password age is set to 1 or more days." "Review and update the minimum password age settings."
    } elseif ($minPasswordAge -eq $null) {
        Add-Result "1.1.3" "Null" "Minimum password age setting is missing." "Ensure 'Minimum password age' is set to '1 or more days'" "Password Policy" "Low" "Low" "Ensure the minimum password age is set to 1 or more days." "Review and update the minimum password age settings."
    } else {
        Add-Result "1.1.3" "Fail" "Minimum password age is less than the recommended value." "Ensure 'Minimum password age' is set to '1 or more days'" "Password Policy" "Low" "Low" "Ensure the minimum password age is set to 1 or more days." "Review and update the minimum password age settings."
    }
} catch {
    Add-Result "1.1.3" "Error" "Could not check 'Minimum password age'. Error: $($_.Exception.Message)" "Ensure 'Minimum password age' is set to '1 or more days'" "Password Policy" "Low" "Low" "Ensure the minimum password age is set to 1 or more days." "Review and update the minimum password age settings."
}

try {
    # Ensure 'Minimum password length' is set to '14 or more characters'
    $minPasswordLength = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Netlogon\Parameters" -Name "MinimumPasswordLength" -ErrorAction Stop
    if ($minPasswordLength.MinimumPasswordLength -ge 14) {
        Add-Result "1.1.4" "Pass" "Minimum password length is set correctly." "Ensure 'Minimum password length' is set to '14 or more characters'" "Password Policy" "High" "High" "Ensure the minimum password length is set to 14 or more characters." "Review and update the minimum password length settings."
    } elseif ($minPasswordLength -eq $null) {
        Add-Result "1.1.4" "Null" "Minimum password length setting is missing." "Ensure 'Minimum password length' is set to '14 or more characters'" "Password Policy" "High" "High" "Ensure the minimum password length is set to 14 or more characters." "Review and update the minimum password length settings."
    } else {
        Add-Result "1.1.4" "Fail" "Minimum password length is less than 14 characters." "Ensure 'Minimum password length' is set to '14 or more characters'" "Password Policy" "High" "High" "Ensure the minimum password length is set to 14 or more characters." "Review and update the minimum password length settings."
    }
} catch {
    Add-Result "1.1.4" "Error" "Could not check 'Minimum password length'. Error: $($_.Exception.Message)" "Ensure 'Minimum password length' is set to '14 or more characters'" "Password Policy" "High" "High" "Ensure the minimum password length is set to 14 or more characters." "Review and update the minimum password length settings."
}

try {
    # Ensure 'Password must meet complexity requirements' is set to 'Enabled'
    $complexity = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Netlogon\Parameters" -Name "PasswordComplexity" -ErrorAction Stop
    if ($complexity.PasswordComplexity -eq 1) {
        Add-Result "1.1.5" "Pass" "Password complexity requirements are enabled." "Ensure 'Password must meet complexity requirements' is set to 'Enabled'" "Password Policy" "High" "High" "Ensure the password complexity requirements are enabled." "Review and update the password complexity settings."
    } elseif ($complexity -eq $null) {
        Add-Result "1.1.5" "Null" "Password complexity setting is missing." "Ensure 'Password must meet complexity requirements' is set to 'Enabled'" "Password Policy" "High" "High" "Ensure the password complexity requirements are enabled." "Review and update the password complexity settings."
    } else {
        Add-Result "1.1.5" "Fail" "Password complexity requirements are disabled." "Ensure 'Password must meet complexity requirements' is set to 'Enabled'" "Password Policy" "High" "High" "Ensure the password complexity requirements are enabled." "Review and update the password complexity settings."
    }
} catch {
    Add-Result "1.1.5" "Error" "Could not check 'Password must meet complexity requirements'. Error: $($_.Exception.Message)" "Ensure 'Password must meet complexity requirements' is set to 'Enabled'" "Password Policy" "High" "High" "Ensure the password complexity requirements are enabled." "Review and update the password complexity settings."
}

try {
    # Ensure 'Lockout threshold' is set to '5 or fewer invalid attempts'
    $lockoutThreshold = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Netlogon\Parameters" -Name "LockoutBadCount" -ErrorAction Stop
    if ($lockoutThreshold.LockoutBadCount -le 5) {
        Add-Result "1.2.1" "Pass" "Lockout threshold is set correctly." "Ensure 'Lockout threshold' is set to '5 or fewer invalid attempts'" "Account Lockout Policy" "High" "High" "Ensure the lockout threshold is set to 5 or fewer invalid attempts." "Review and update the lockout threshold settings."
    } elseif ($lockoutThreshold -eq $null) {
        Add-Result "1.2.1" "Null" "Lockout threshold setting is missing." "Ensure 'Lockout threshold' is set to '5 or fewer invalid attempts'" "Account Lockout Policy" "High" "High" "Ensure the lockout threshold is set to 5 or fewer invalid attempts." "Review and update the lockout threshold settings."
    } else {
        Add-Result "1.2.1" "Fail" "Lockout threshold is greater than 5 invalid attempts." "Ensure 'Lockout threshold' is set to '5 or fewer invalid attempts'" "Account Lockout Policy" "High" "High" "Ensure the lockout threshold is set to 5 or fewer invalid attempts." "Review and update the lockout threshold settings."
    }
} catch {
    Add-Result "1.2.1" "Error" "Could not check 'Lockout threshold'. Error: $($_.Exception.Message)" "Ensure 'Lockout threshold' is set to '5 or fewer invalid attempts'" "Account Lockout Policy" "High" "High" "Ensure the lockout threshold is set to 5 or fewer invalid attempts." "Review and update the lockout threshold settings."
}

try {
    # Ensure 'Lockout duration' is set to '15 or more minutes'
    $lockoutDuration = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Netlogon\Parameters" -Name "LockoutDuration" -ErrorAction Stop
    if ($lockoutDuration.LockoutDuration -ge 15) {
        Add-Result "1.2.2" "Pass" "Lockout duration is set correctly." "Ensure 'Lockout duration' is set to '15 or more minutes'" "Account Lockout Policy" "Medium" "Medium" "Ensure the lockout duration is set to 15 or more minutes." "Review and update the lockout duration settings."
    } elseif ($lockoutDuration -eq $null) {
        Add-Result "1.2.2" "Null" "Lockout duration setting is missing." "Ensure 'Lockout duration' is set to '15 or more minutes'" "Account Lockout Policy" "Medium" "Medium" "Ensure the lockout duration is set to 15 or more minutes." "Review and update the lockout duration settings."
    } else {
        Add-Result "1.2.2" "Fail" "Lockout duration is less than 15 minutes." "Ensure 'Lockout duration' is set to '15 or more minutes'" "Account Lockout Policy" "Medium" "Medium" "Ensure the lockout duration is set to 15 or more minutes." "Review and update the lockout duration settings."
    }
} catch {
    Add-Result "1.2.2" "Error" "Could not check 'Lockout duration'. Error: $($_.Exception.Message)" "Ensure 'Lockout duration' is set to '15 or more minutes'" "Account Lockout Policy" "Medium" "Medium" "Ensure the lockout duration is set to 15 or more minutes." "Review and update the lockout duration settings."
}

try {
    # Ensure 'Reset account lockout counter after' is set to '15 or more minutes'
    $resetLockout = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Netlogon\Parameters" -Name "ResetLockoutCount" -ErrorAction Stop
    if ($resetLockout.ResetLockoutCount -ge 15) {
        Add-Result "1.2.3" "Pass" "Reset account lockout counter is set correctly." "Ensure 'Reset account lockout counter after' is set to '15 or more minutes'" "Account Lockout Policy" "Medium" "Medium" "Ensure the reset account lockout counter is set to 15 or more minutes." "Review and update the reset account lockout counter settings."
    } elseif ($resetLockout -eq $null) {
        Add-Result "1.2.3" "Null" "Reset account lockout counter setting is missing." "Ensure 'Reset account lockout counter after' is set to '15 or more minutes'" "Account Lockout Policy" "Medium" "Medium" "Ensure the reset account lockout counter is set to 15 or more minutes." "Review and update the reset account lockout counter settings."
    } else {
        Add-Result "1.2.3" "Fail" "Reset account lockout counter is less than 15 minutes." "Ensure 'Reset account lockout counter after' is set to '15 or more minutes'" "Account Lockout Policy" "Medium" "Medium" "Ensure the reset account lockout counter is set to 15 or more minutes." "Review and update the reset account lockout counter settings."
    }
} catch {
    Add-Result "1.2.3" "Error" "Could not check 'Reset account lockout counter'. Error: $($_.Exception.Message)" "Ensure 'Reset account lockout counter after' is set to '15 or more minutes'" "Account Lockout Policy" "Medium" "Medium" "Ensure the reset account lockout counter is set to 15 or more minutes." "Review and update the reset account lockout counter settings."
}

try {
    # Ensure 'Access Credential Manager as a trusted caller' is set to 'No One'
    $credentialManager = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "AccessCredentialManager" -ErrorAction Stop
    if ($credentialManager.AccessCredentialManager -eq "NoOne") {
        Add-Result "2.2.1" "Pass" "Access Credential Manager as a trusted caller is set correctly." "Ensure 'Access Credential Manager as a trusted caller' is set to 'No One'" "User Rights Assignment" "High" "High" "Restrict access to the Credential Manager." "Review and update the setting to 'No One'."
    } elseif ($credentialManager -eq $null) {
        Add-Result "2.2.1" "Null" "Access Credential Manager setting is missing." "Ensure 'Access Credential Manager as a trusted caller' is set to 'No One'" "User Rights Assignment" "High" "High" "Restrict access to the Credential Manager." "Review and update the setting to 'No One'."
    } else {
        Add-Result "2.2.1" "Fail" "Access Credential Manager as a trusted caller is not set to 'No One'." "Ensure 'Access Credential Manager as a trusted caller' is set to 'No One'" "User Rights Assignment" "High" "High" "Restrict access to the Credential Manager." "Review and update the setting to 'No One'."
    }
} catch {
    Add-Result "2.2.1" "Error" "Could not check 'Access Credential Manager as a trusted caller'. Error: $($_.Exception.Message)" "Ensure 'Access Credential Manager as a trusted caller' is set to 'No One'" "User Rights Assignment" "High" "High" "Restrict access to the Credential Manager." "Review and update the setting to 'No One'."
}

try {
    # Ensure 'Access this computer from the network' is set to 'Administrators, Remote Desktop Users'
    $networkAccess = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "SeNetworkLogonRight" -ErrorAction Stop
    if ($networkAccess.SeNetworkLogonRight -contains "Administrators" -and $networkAccess.SeNetworkLogonRight -contains "Remote Desktop Users") {
        Add-Result "2.2.2" "Pass" "Access this computer from the network is set correctly." "Ensure 'Access this computer from the network' is set to 'Administrators, Remote Desktop Users'" "User Rights Assignment" "Medium" "Medium" "Restrict access to network login." "Review and ensure only 'Administrators, Remote Desktop Users' have this right."
    } elseif ($networkAccess -eq $null) {
        Add-Result "2.2.2" "Null" "Access this computer from the network setting is missing." "Ensure 'Access this computer from the network' is set to 'Administrators, Remote Desktop Users'" "User Rights Assignment" "Medium" "Medium" "Restrict access to network login." "Review and ensure only 'Administrators, Remote Desktop Users' have this right."
    } else {
        Add-Result "2.2.2" "Fail" "Access this computer from the network is not set correctly." "Ensure 'Access this computer from the network' is set to 'Administrators, Remote Desktop Users'" "User Rights Assignment" "Medium" "Medium" "Restrict access to network login." "Review and ensure only 'Administrators, Remote Desktop Users' have this right."
    }
} catch {
    Add-Result "2.2.2" "Error" "Could not check 'Access this computer from the network'. Error: $($_.Exception.Message)" "Ensure 'Access this computer from the network' is set to 'Administrators, Remote Desktop Users'" "User Rights Assignment" "Medium" "Medium" "Restrict access to network login." "Review and ensure only 'Administrators, Remote Desktop Users' have this right."
}

try {
    # Ensure 'Act as part of the operating system' is set to 'No One'
    $actAsOS = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "SeTcbPrivilege" -ErrorAction Stop
    if ($actAsOS.SeTcbPrivilege -eq "NoOne") {
        Add-Result "2.2.3" "Pass" "Act as part of the operating system is set correctly." "Ensure 'Act as part of the operating system' is set to 'No One'" "User Rights Assignment" "High" "High" "Restrict this highly privileged right." "Review and set to 'No One'."
    } elseif ($actAsOS -eq $null) {
        Add-Result "2.2.3" "Null" "Act as part of the operating system setting is missing." "Ensure 'Act as part of the operating system' is set to 'No One'" "User Rights Assignment" "High" "High" "Restrict this highly privileged right." "Review and set to 'No One'."
    } else {
        Add-Result "2.2.3" "Fail" "Act as part of the operating system is not set to 'No One'." "Ensure 'Act as part of the operating system' is set to 'No One'" "User Rights Assignment" "High" "High" "Restrict this highly privileged right." "Review and set to 'No One'."
    }
} catch {
    Add-Result "2.2.3" "Error" "Could not check 'Act as part of the operating system'. Error: $($_.Exception.Message)" "Ensure 'Act as part of the operating system' is set to 'No One'" "User Rights Assignment" "High" "High" "Restrict this highly privileged right." "Review and set to 'No One'."
}

try {
    # Ensure 'Adjust memory quotas for a process' is set to 'Administrators, LOCAL SERVICE, NETWORK SERVICE'
    $memoryQuotas = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "SeIncreaseQuotaPrivilege" -ErrorAction Stop
    if ($memoryQuotas.SeIncreaseQuotaPrivilege -contains "Administrators" -and $memoryQuotas.SeIncreaseQuotaPrivilege -contains "LOCAL SERVICE" -and $memoryQuotas.SeIncreaseQuotaPrivilege -contains "NETWORK SERVICE") {
        Add-Result "2.2.4" "Pass" "Adjust memory quotas for a process is set correctly." "Ensure 'Adjust memory quotas for a process' is set to 'Administrators, LOCAL SERVICE, NETWORK SERVICE'" "User Rights Assignment" "Medium" "Medium" "Limit the privileges for memory quotas adjustments." "Review and set to 'Administrators, LOCAL SERVICE, NETWORK SERVICE'."
    } elseif ($memoryQuotas -eq $null) {
        Add-Result "2.2.4" "Null" "Adjust memory quotas for a process setting is missing." "Ensure 'Adjust memory quotas for a process' is set to 'Administrators, LOCAL SERVICE, NETWORK SERVICE'" "User Rights Assignment" "Medium" "Medium" "Limit the privileges for memory quotas adjustments." "Review and set to 'Administrators, LOCAL SERVICE, NETWORK SERVICE'."
    } else {
        Add-Result "2.2.4" "Fail" "Adjust memory quotas for a process is not set correctly." "Ensure 'Adjust memory quotas for a process' is set to 'Administrators, LOCAL SERVICE, NETWORK SERVICE'" "User Rights Assignment" "Medium" "Medium" "Limit the privileges for memory quotas adjustments." "Review and set to 'Administrators, LOCAL SERVICE, NETWORK SERVICE'."
    }
} catch {
    Add-Result "2.2.4" "Error" "Could not check 'Adjust memory quotas for a process'. Error: $($_.Exception.Message)" "Ensure 'Adjust memory quotas for a process' is set to 'Administrators, LOCAL SERVICE, NETWORK SERVICE'" "User Rights Assignment" "Medium" "Medium" "Limit the privileges for memory quotas adjustments." "Review and set to 'Administrators, LOCAL SERVICE, NETWORK SERVICE'."
}

try {
    # Ensure 'Allow log on locally' is set to 'Administrators, Users'
    $localLogon = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "SeInteractiveLogonRight" -ErrorAction Stop
    if ($localLogon.SeInteractiveLogonRight -contains "Administrators" -and $localLogon.SeInteractiveLogonRight -contains "Users") {
        Add-Result "2.2.5" "Pass" "Allow log on locally is set correctly." "Ensure 'Allow log on locally' is set to 'Administrators, Users'" "User Rights Assignment" "Medium" "Medium" "Restrict local logon rights." "Review and set to 'Administrators, Users'."
    } elseif ($localLogon -eq $null) {
        Add-Result "2.2.5" "Null" "Allow log on locally setting is missing." "Ensure 'Allow log on locally' is set to 'Administrators, Users'" "User Rights Assignment" "Medium" "Medium" "Restrict local logon rights." "Review and set to 'Administrators, Users'."
    } else {
        Add-Result "2.2.5" "Fail" "Allow log on locally is not set correctly." "Ensure 'Allow log on locally' is set to 'Administrators, Users'" "User Rights Assignment" "Medium" "Medium" "Restrict local logon rights." "Review and set to 'Administrators, Users'."
    }
} catch {
    Add-Result "2.2.5" "Error" "Could not check 'Allow log on locally'. Error: $($_.Exception.Message)" "Ensure 'Allow log on locally' is set to 'Administrators, Users'" "User Rights Assignment" "Medium" "Medium" "Restrict local logon rights." "Review and set to 'Administrators, Users'."
}

try {
    # Ensure 'Allow log on through Remote Desktop Services' is set to 'Administrators, Remote Desktop Users'
    $remoteDesktopLogon = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "SeRemoteInteractiveLogonRight" -ErrorAction Stop
    if ($remoteDesktopLogon.SeRemoteInteractiveLogonRight -contains "Administrators" -and $remoteDesktopLogon.SeRemoteInteractiveLogonRight -contains "Remote Desktop Users") {
        Add-Result "2.2.6" "Pass" "Allow log on through Remote Desktop Services is set correctly." "Ensure 'Allow log on through Remote Desktop Services' is set to 'Administrators, Remote Desktop Users'" "User Rights Assignment" "Medium" "Medium" "Restrict Remote Desktop logon rights." "Review and ensure only 'Administrators, Remote Desktop Users' have this right."
    } elseif ($remoteDesktopLogon -eq $null) {
        Add-Result "2.2.6" "Null" "Allow log on through Remote Desktop Services setting is missing." "Ensure 'Allow log on through Remote Desktop Services' is set to 'Administrators, Remote Desktop Users'" "User Rights Assignment" "Medium" "Medium" "Restrict Remote Desktop logon rights." "Review and ensure only 'Administrators, Remote Desktop Users' have this right."
    } else {
        Add-Result "2.2.6" "Fail" "Allow log on through Remote Desktop Services is not set correctly." "Ensure 'Allow log on through Remote Desktop Services' is set to 'Administrators, Remote Desktop Users'" "User Rights Assignment" "Medium" "Medium" "Restrict Remote Desktop logon rights." "Review and ensure only 'Administrators, Remote Desktop Users' have this right."
    }
} catch {
    Add-Result "2.2.6" "Error" "Could not check 'Allow log on through Remote Desktop Services'. Error: $($_.Exception.Message)" "Ensure 'Allow log on through Remote Desktop Services' is set to 'Administrators, Remote Desktop Users'" "User Rights Assignment" "Medium" "Medium" "Restrict Remote Desktop logon rights." "Review and ensure only 'Administrators, Remote Desktop Users' have this right."
}

try {
    # Ensure 'Back up files and directories' is set to 'Administrators'
    $backupFiles = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "SeBackupPrivilege" -ErrorAction Stop
    if ($backupFiles.SeBackupPrivilege -eq "Administrators") {
        Add-Result "2.2.7" "Pass" "Back up files and directories is set correctly." "Ensure 'Back up files and directories' is set to 'Administrators'" "User Rights Assignment" "Medium" "Medium" "Restrict file backup rights." "Review and ensure only 'Administrators' have this right."
    } elseif ($backupFiles -eq $null) {
        Add-Result "2.2.7" "Null" "Back up files and directories setting is missing." "Ensure 'Back up files and directories' is set to 'Administrators'" "User Rights Assignment" "Medium" "Medium" "Restrict file backup rights." "Review and ensure only 'Administrators' have this right."
    } else {
        Add-Result "2.2.7" "Fail" "Back up files and directories is not set to 'Administrators'." "Ensure 'Back up files and directories' is set to 'Administrators'" "User Rights Assignment" "Medium" "Medium" "Restrict file backup rights." "Review and ensure only 'Administrators' have this right."
    }
} catch {
    Add-Result "2.2.7" "Error" "Could not check 'Back up files and directories'. Error: $($_.Exception.Message)" "Ensure 'Back up files and directories' is set to 'Administrators'" "User Rights Assignment" "Medium" "Medium" "Restrict file backup rights." "Review and ensure only 'Administrators' have this right."
}

try {
    # Ensure 'Change the system time' is set to 'Administrators, LOCAL SERVICE'
    $changeSystemTime = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "SeSystemTimePrivilege" -ErrorAction Stop
    if ($changeSystemTime.SeSystemTimePrivilege -contains "Administrators" -and $changeSystemTime.SeSystemTimePrivilege -contains "LOCAL SERVICE") {
        Add-Result "2.2.8" "Pass" "Change the system time is set correctly." "Ensure 'Change the system time' is set to 'Administrators, LOCAL SERVICE'" "User Rights Assignment" "Medium" "Medium" "Restrict privileges to change system time." "Review and ensure only 'Administrators, LOCAL SERVICE' have this right."
    } elseif ($changeSystemTime -eq $null) {
        Add-Result "2.2.8" "Null" "Change the system time setting is missing." "Ensure 'Change the system time' is set to 'Administrators, LOCAL SERVICE'" "User Rights Assignment" "Medium" "Medium" "Restrict privileges to change system time." "Review and ensure only 'Administrators, LOCAL SERVICE' have this right."
    } else {
        Add-Result "2.2.8" "Fail" "Change the system time is not set correctly." "Ensure 'Change the system time' is set to 'Administrators, LOCAL SERVICE'" "User Rights Assignment" "Medium" "Medium" "Restrict privileges to change system time." "Review and ensure only 'Administrators, LOCAL SERVICE' have this right."
    }
} catch {
    Add-Result "2.2.8" "Error" "Could not check 'Change the system time'. Error: $($_.Exception.Message)" "Ensure 'Change the system time' is set to 'Administrators, LOCAL SERVICE'" "User Rights Assignment" "Medium" "Medium" "Restrict privileges to change system time." "Review and ensure only 'Administrators, LOCAL SERVICE' have this right."
}

try {
    # Ensure 'Change the time zone' is set to 'Administrators, LOCAL SERVICE, Users'
    $changeTimeZone = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "SeTimeZonePrivilege" -ErrorAction Stop
    if ($changeTimeZone.SeTimeZonePrivilege -contains "Administrators" -and $changeTimeZone.SeTimeZonePrivilege -contains "LOCAL SERVICE" -and $changeTimeZone.SeTimeZonePrivilege -contains "Users") {
        Add-Result "2.2.9" "Pass" "Change the time zone is set correctly." "Ensure 'Change the time zone' is set to 'Administrators, LOCAL SERVICE, Users'" "User Rights Assignment" "Low" "Low" "Limit privileges for time zone adjustments." "Review and ensure only 'Administrators, LOCAL SERVICE, Users' have this right."
    } elseif ($changeTimeZone -eq $null) {
        Add-Result "2.2.9" "Null" "Change the time zone setting is missing." "Ensure 'Change the time zone' is set to 'Administrators, LOCAL SERVICE, Users'" "User Rights Assignment" "Low" "Low" "Limit privileges for time zone adjustments." "Review and ensure only 'Administrators, LOCAL SERVICE, Users' have this right."
    } else {
        Add-Result "2.2.9" "Fail" "Change the time zone is not set correctly." "Ensure 'Change the time zone' is set to 'Administrators, LOCAL SERVICE, Users'" "User Rights Assignment" "Low" "Low" "Limit privileges for time zone adjustments." "Review and ensure only 'Administrators, LOCAL SERVICE, Users' have this right."
    }
} catch {
    Add-Result "2.2.9" "Error" "Could not check 'Change the time zone'. Error: $($_.Exception.Message)" "Ensure 'Change the time zone' is set to 'Administrators, LOCAL SERVICE, Users'" "User Rights Assignment" "Low" "Low" "Limit privileges for time zone adjustments." "Review and ensure only 'Administrators, LOCAL SERVICE, Users' have this right."
}

try {
    # Ensure 'Create a pagefile' is set to 'Administrators'
    $createPagefile = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "SeCreatePagefilePrivilege" -ErrorAction Stop
    if ($createPagefile.SeCreatePagefilePrivilege -eq "Administrators") {
        Add-Result "2.2.10" "Pass" "Create a pagefile is set correctly." "Ensure 'Create a pagefile' is set to 'Administrators'" "User Rights Assignment" "Medium" "Medium" "Restrict privileges for pagefile creation." "Review and ensure only 'Administrators' have this right."
    } elseif ($createPagefile -eq $null) {
        Add-Result "2.2.10" "Null" "Create a pagefile setting is missing." "Ensure 'Create a pagefile' is set to 'Administrators'" "User Rights Assignment" "Medium" "Medium" "Restrict privileges for pagefile creation." "Review and ensure only 'Administrators' have this right."
    } else {
        Add-Result "2.2.10" "Fail" "Create a pagefile is not set to 'Administrators'." "Ensure 'Create a pagefile' is set to 'Administrators'" "User Rights Assignment" "Medium" "Medium" "Restrict privileges for pagefile creation." "Review and ensure only 'Administrators' have this right."
    }
} catch {
    Add-Result "2.2.10" "Error" "Could not check 'Create a pagefile'. Error: $($_.Exception.Message)" "Ensure 'Create a pagefile' is set to 'Administrators'" "User Rights Assignment" "Medium" "Medium" "Restrict privileges for pagefile creation." "Review and ensure only 'Administrators' have this right."
}

try {
    # Ensure 'Create a token object' is set to 'No One'
    $createTokenObject = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "SeCreateTokenPrivilege" -ErrorAction Stop
    if ($createTokenObject.SeCreateTokenPrivilege -eq "NoOne") {
        Add-Result "2.2.11" "Pass" "Create a token object is set correctly." "Ensure 'Create a token object' is set to 'No One'" "User Rights Assignment" "High" "High" "Restrict the ability to create token objects." "Review and set to 'No One'."
    } elseif ($createTokenObject -eq $null) {
        Add-Result "2.2.11" "Null" "Create a token object setting is missing." "Ensure 'Create a token object' is set to 'No One'" "User Rights Assignment" "High" "High" "Restrict the ability to create token objects." "Review and set to 'No One'."
    } else {
        Add-Result "2.2.11" "Fail" "Create a token object is not set to 'No One'." "Ensure 'Create a token object' is set to 'No One'" "User Rights Assignment" "High" "High" "Restrict the ability to create token objects." "Review and set to 'No One'."
    }
} catch {
    Add-Result "2.2.11" "Error" "Could not check 'Create a token object'. Error: $($_.Exception.Message)" "Ensure 'Create a token object' is set to 'No One'" "User Rights Assignment" "High" "High" "Restrict the ability to create token objects." "Review and set to 'No One'."
}

try {
    # Ensure 'Create global objects' is set to 'Administrators, LOCAL SERVICE, NETWORK SERVICE, SERVICE'
    $createGlobalObjects = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "SeCreateGlobalPrivilege" -ErrorAction Stop
    if ($createGlobalObjects.SeCreateGlobalPrivilege -contains "Administrators" -and $createGlobalObjects.SeCreateGlobalPrivilege -contains "LOCAL SERVICE" -and $createGlobalObjects.SeCreateGlobalPrivilege -contains "NETWORK SERVICE" -and $createGlobalObjects.SeCreateGlobalPrivilege -contains "SERVICE") {
        Add-Result "2.2.12" "Pass" "Create global objects is set correctly." "Ensure 'Create global objects' is set to 'Administrators, LOCAL SERVICE, NETWORK SERVICE, SERVICE'" "User Rights Assignment" "Medium" "Medium" "Restrict the ability to create global objects." "Review and set appropriately."
    } elseif ($createGlobalObjects -eq $null) {
        Add-Result "2.2.12" "Null" "Create global objects setting is missing." "Ensure 'Create global objects' is set to 'Administrators, LOCAL SERVICE, NETWORK SERVICE, SERVICE'" "User Rights Assignment" "Medium" "Medium" "Restrict the ability to create global objects." "Review and set appropriately."
    } else {
        Add-Result "2.2.12" "Fail" "Create global objects is not set correctly." "Ensure 'Create global objects' is set to 'Administrators, LOCAL SERVICE, NETWORK SERVICE, SERVICE'" "User Rights Assignment" "Medium" "Medium" "Restrict the ability to create global objects." "Review and set appropriately."
    }
} catch {
    Add-Result "2.2.12" "Error" "Could not check 'Create global objects'. Error: $($_.Exception.Message)" "Ensure 'Create global objects' is set to 'Administrators, LOCAL SERVICE, NETWORK SERVICE, SERVICE'" "User Rights Assignment" "Medium" "Medium" "Restrict the ability to create global objects." "Review and set appropriately."
}

try {
    # Ensure 'Create permanent shared objects' is set to 'No One'
    $createPermanentObjects = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "SeCreatePermanentPrivilege" -ErrorAction Stop
    if ($createPermanentObjects.SeCreatePermanentPrivilege -eq "NoOne") {
        Add-Result "2.2.13" "Pass" "Create permanent shared objects is set correctly." "Ensure 'Create permanent shared objects' is set to 'No One'" "User Rights Assignment" "High" "High" "Restrict the ability to create permanent shared objects." "Review and set to 'No One'."
    } elseif ($createPermanentObjects -eq $null) {
        Add-Result "2.2.13" "Null" "Create permanent shared objects setting is missing." "Ensure 'Create permanent shared objects' is set to 'No One'" "User Rights Assignment" "High" "High" "Restrict the ability to create permanent shared objects." "Review and set to 'No One'."
    } else {
        Add-Result "2.2.13" "Fail" "Create permanent shared objects is not set to 'No One'." "Ensure 'Create permanent shared objects' is set to 'No One'" "User Rights Assignment" "High" "High" "Restrict the ability to create permanent shared objects." "Review and set to 'No One'."
    }
} catch {
    Add-Result "2.2.13" "Error" "Could not check 'Create permanent shared objects'. Error: $($_.Exception.Message)" "Ensure 'Create permanent shared objects' is set to 'No One'" "User Rights Assignment" "High" "High" "Restrict the ability to create permanent shared objects." "Review and set to 'No One'."
}

try {
    # Configure 'Create symbolic links'
    $createSymbolicLinks = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "SeCreateSymbolicLinkPrivilege" -ErrorAction Stop
    if ($createSymbolicLinks -ne $null) {
        Add-Result "2.2.14" "Pass" "Create symbolic links is configured." "Configure 'Create symbolic links'" "User Rights Assignment" "Medium" "Medium" "Ensure symbolic link privileges are assigned appropriately." "Review and configure symbolic link permissions."
    } else {
        Add-Result "2.2.14" "Null" "Create symbolic links setting is missing." "Configure 'Create symbolic links'" "User Rights Assignment" "Medium" "Medium" "Ensure symbolic link privileges are assigned appropriately." "Review and configure symbolic link permissions."
    }
} catch {
    Add-Result "2.2.14" "Error" "Could not check 'Create symbolic links'. Error: $($_.Exception.Message)" "Configure 'Create symbolic links'" "User Rights Assignment" "Medium" "Medium" "Ensure symbolic link privileges are assigned appropriately." "Review and configure symbolic link permissions."
}

try {
    # Ensure 'Debug programs' is set to 'Administrators'
    $debugPrograms = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "SeDebugPrivilege" -ErrorAction Stop
    if ($debugPrograms.SeDebugPrivilege -eq "Administrators") {
        Add-Result "2.2.15" "Pass" "Debug programs is set correctly." "Ensure 'Debug programs' is set to 'Administrators'" "User Rights Assignment" "High" "High" "Restrict debugging privileges to Administrators only." "Review and ensure only Administrators have this right."
    } elseif ($debugPrograms -eq $null) {
        Add-Result "2.2.15" "Null" "Debug programs setting is missing." "Ensure 'Debug programs' is set to 'Administrators'" "User Rights Assignment" "High" "High" "Restrict debugging privileges to Administrators only." "Review and ensure only Administrators have this right."
    } else {
        Add-Result "2.2.15" "Fail" "Debug programs is not set to 'Administrators'." "Ensure 'Debug programs' is set to 'Administrators'" "User Rights Assignment" "High" "High" "Restrict debugging privileges to Administrators only." "Review and ensure only Administrators have this right."
    }
} catch {
    Add-Result "2.2.15" "Error" "Could not check 'Debug programs'. Error: $($_.Exception.Message)" "Ensure 'Debug programs' is set to 'Administrators'" "User Rights Assignment" "High" "High" "Restrict debugging privileges to Administrators only." "Review and ensure only Administrators have this right."
}

try {
    # Ensure 'Deny access to this computer from the network' includes 'Guests'
    $denyNetworkAccess = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "SeDenyNetworkLogonRight" -ErrorAction Stop
    if ($denyNetworkAccess.SeDenyNetworkLogonRight -contains "Guests") {
        Add-Result "2.2.16" "Pass" "Deny access to this computer from the network includes 'Guests'." "Ensure 'Deny access to this computer from the network' to include 'Guests'" "User Rights Assignment" "High" "High" "Restrict network access for 'Guests'." "Review and ensure 'Guests' are included in the policy."
    } elseif ($denyNetworkAccess -eq $null) {
        Add-Result "2.2.16" "Null" "Deny access to this computer from the network setting is missing." "Ensure 'Deny access to this computer from the network' to include 'Guests'" "User Rights Assignment" "High" "High" "Restrict network access for 'Guests'." "Review and ensure 'Guests' are included in the policy."
    } else {
        Add-Result "2.2.16" "Fail" "Deny access to this computer from the network does not include 'Guests'." "Ensure 'Deny access to this computer from the network' to include 'Guests'" "User Rights Assignment" "High" "High" "Restrict network access for 'Guests'." "Review and ensure 'Guests' are included in the policy."
    }
} catch {
    Add-Result "2.2.16" "Error" "Could not check 'Deny access to this computer from the network'. Error: $($_.Exception.Message)" "Ensure 'Deny access to this computer from the network' to include 'Guests'" "User Rights Assignment" "High" "High" "Restrict network access for 'Guests'." "Review and ensure 'Guests' are included in the policy."
}

try {
    # Ensure 'Deny log on as a batch job' includes 'Guests'
    $denyBatchJob = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "SeDenyBatchLogonRight" -ErrorAction Stop
    if ($denyBatchJob.SeDenyBatchLogonRight -contains "Guests") {
        Add-Result "2.2.17" "Pass" "Deny log on as a batch job includes 'Guests'." "Ensure 'Deny log on as a batch job' to include 'Guests'" "User Rights Assignment" "Medium" "Medium" "Restrict batch job logon for 'Guests'." "Review and ensure 'Guests' are included in the policy."
    } elseif ($denyBatchJob -eq $null) {
        Add-Result "2.2.17" "Null" "Deny log on as a batch job setting is missing." "Ensure 'Deny log on as a batch job' to include 'Guests'" "User Rights Assignment" "Medium" "Medium" "Restrict batch job logon for 'Guests'." "Review and ensure 'Guests' are included in the policy."
    } else {
        Add-Result "2.2.17" "Fail" "Deny log on as a batch job does not include 'Guests'." "Ensure 'Deny log on as a batch job' to include 'Guests'" "User Rights Assignment" "Medium" "Medium" "Restrict batch job logon for 'Guests'." "Review and ensure 'Guests' are included in the policy."
    }
} catch {
    Add-Result "2.2.17" "Error" "Could not check 'Deny log on as a batch job'. Error: $($_.Exception.Message)" "Ensure 'Deny log on as a batch job' to include 'Guests'" "User Rights Assignment" "Medium" "Medium" "Restrict batch job logon for 'Guests'." "Review and ensure 'Guests' are included in the policy."
}

try {
    # Ensure 'Deny log on as a service' includes 'Guests'
    $denyServiceLogon = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "SeDenyServiceLogonRight" -ErrorAction Stop
    if ($denyServiceLogon.SeDenyServiceLogonRight -contains "Guests") {
        Add-Result "2.2.18" "Pass" "Deny log on as a service includes 'Guests'." "Ensure 'Deny log on as a service' to include 'Guests'" "User Rights Assignment" "High" "High" "Restrict service logon for 'Guests'." "Review and ensure 'Guests' are included in the policy."
    } elseif ($denyServiceLogon -eq $null) {
        Add-Result "2.2.18" "Null" "Deny log on as a service setting is missing." "Ensure 'Deny log on as a service' to include 'Guests'" "User Rights Assignment" "High" "High" "Restrict service logon for 'Guests'." "Review and ensure 'Guests' are included in the policy."
    } else {
        Add-Result "2.2.18" "Fail" "Deny log on as a service does not include 'Guests'." "Ensure 'Deny log on as a service' to include 'Guests'" "User Rights Assignment" "High" "High" "Restrict service logon for 'Guests'." "Review and ensure 'Guests' are included in the policy."
    }
} catch {
    Add-Result "2.2.18" "Error" "Could not check 'Deny log on as a service'. Error: $($_.Exception.Message)" "Ensure 'Deny log on as a service' to include 'Guests'" "User Rights Assignment" "High" "High" "Restrict service logon for 'Guests'." "Review and ensure 'Guests' are included in the policy."
}

try {
    # Ensure 'Deny log on locally' includes 'Guests'
    $denyLocalLogon = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "SeDenyInteractiveLogonRight" -ErrorAction Stop
    if ($denyLocalLogon.SeDenyInteractiveLogonRight -contains "Guests") {
        Add-Result "2.2.19" "Pass" "Deny log on locally includes 'Guests'." "Ensure 'Deny log on locally' to include 'Guests'" "User Rights Assignment" "High" "High" "Restrict local logon for 'Guests'." "Review and ensure 'Guests' are included in the policy."
    } elseif ($denyLocalLogon -eq $null) {
        Add-Result "2.2.19" "Null" "Deny log on locally setting is missing." "Ensure 'Deny log on locally' to include 'Guests'" "User Rights Assignment" "High" "High" "Restrict local logon for 'Guests'." "Review and ensure 'Guests' are included in the policy."
    } else {
        Add-Result "2.2.19" "Fail" "Deny log on locally does not include 'Guests'." "Ensure 'Deny log on locally' to include 'Guests'" "User Rights Assignment" "High" "High" "Restrict local logon for 'Guests'." "Review and ensure 'Guests' are included in the policy."
    }
} catch {
    Add-Result "2.2.19" "Error" "Could not check 'Deny log on locally'. Error: $($_.Exception.Message)" "Ensure 'Deny log on locally' to include 'Guests'" "User Rights Assignment" "High" "High" "Restrict local logon for 'Guests'." "Review and ensure 'Guests' are included in the policy."
}

try {
    # Ensure 'Deny log on through Remote Desktop Services' includes 'Guests'
    $denyRemoteDesktop = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "SeDenyRemoteInteractiveLogonRight" -ErrorAction Stop
    if ($denyRemoteDesktop.SeDenyRemoteInteractiveLogonRight -contains "Guests") {
        Add-Result "2.2.20" "Pass" "Deny log on through Remote Desktop Services includes 'Guests'." "Ensure 'Deny log on through Remote Desktop Services' to include 'Guests'" "User Rights Assignment" "High" "High" "Restrict Remote Desktop logon for 'Guests'." "Review and ensure 'Guests' are included in the policy."
    } elseif ($denyRemoteDesktop -eq $null) {
        Add-Result "2.2.20" "Null" "Deny log on through Remote Desktop Services setting is missing." "Ensure 'Deny log on through Remote Desktop Services' to include 'Guests'" "User Rights Assignment" "High" "High" "Restrict Remote Desktop logon for 'Guests'." "Review and ensure 'Guests' are included in the policy."
    } else {
        Add-Result "2.2.20" "Fail" "Deny log on through Remote Desktop Services does not include 'Guests'." "Ensure 'Deny log on through Remote Desktop Services' to include 'Guests'" "User Rights Assignment" "High" "High" "Restrict Remote Desktop logon for 'Guests'." "Review and ensure 'Guests' are included in the policy."
    }
} catch {
    Add-Result "2.2.20" "Error" "Could not check 'Deny log on through Remote Desktop Services'. Error: $($_.Exception.Message)" "Ensure 'Deny log on through Remote Desktop Services' to include 'Guests'" "User Rights Assignment" "High" "High" "Restrict Remote Desktop logon for 'Guests'." "Review and ensure 'Guests' are included in the policy."
}

try {
    # Ensure 'Enable computer and user accounts to be trusted for delegation' is set to 'No One'
    $trustedForDelegation = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "SeEnableDelegationPrivilege" -ErrorAction Stop
    if ($trustedForDelegation.SeEnableDelegationPrivilege -eq "NoOne") {
        Add-Result "2.2.21" "Pass" "Enable computer and user accounts to be trusted for delegation is set correctly." "Ensure 'Enable computer and user accounts to be trusted for delegation' is set to 'No One'" "User Rights Assignment" "High" "High" "Restrict delegation privileges." "Review and ensure this is set to 'No One'."
    } elseif ($trustedForDelegation -eq $null) {
        Add-Result "2.2.21" "Null" "Enable computer and user accounts to be trusted for delegation setting is missing." "Ensure 'Enable computer and user accounts to be trusted for delegation' is set to 'No One'" "User Rights Assignment" "High" "High" "Restrict delegation privileges." "Review and ensure this is set to 'No One'."
    } else {
        Add-Result "2.2.21" "Fail" "Enable computer and user accounts to be trusted for delegation is not set to 'No One'." "Ensure 'Enable computer and user accounts to be trusted for delegation' is set to 'No One'" "User Rights Assignment" "High" "High" "Restrict delegation privileges." "Review and ensure this is set to 'No One'."
    }
} catch {
    Add-Result "2.2.21" "Error" "Could not check 'Enable computer and user accounts to be trusted for delegation'. Error: $($_.Exception.Message)" "Ensure 'Enable computer and user accounts to be trusted for delegation' is set to 'No One'" "User Rights Assignment" "High" "High" "Restrict delegation privileges." "Review and ensure this is set to 'No One'."
}

try {
    # Ensure 'Force shutdown from a remote system' is set to 'Administrators'
    $shutdownRemote = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "SeRemoteShutdownPrivilege" -ErrorAction Stop
    if ($shutdownRemote.SeRemoteShutdownPrivilege -eq "Administrators") {
        Add-Result "2.2.22" "Pass" "Force shutdown from a remote system is set correctly." "Ensure 'Force shutdown from a remote system' is set to 'Administrators'" "User Rights Assignment" "High" "High" "Restrict shutdown privileges to administrators." "Review and ensure this is set to 'Administrators'."
    } elseif ($shutdownRemote -eq $null) {
        Add-Result "2.2.22" "Null" "Force shutdown from a remote system setting is missing." "Ensure 'Force shutdown from a remote system' is set to 'Administrators'" "User Rights Assignment" "High" "High" "Restrict shutdown privileges to administrators." "Review and ensure this is set to 'Administrators'."
    } else {
        Add-Result "2.2.22" "Fail" "Force shutdown from a remote system is not set to 'Administrators'." "Ensure 'Force shutdown from a remote system' is set to 'Administrators'" "User Rights Assignment" "High" "High" "Restrict shutdown privileges to administrators." "Review and ensure this is set to 'Administrators'."
    }
} catch {
    Add-Result "2.2.22" "Error" "Could not check 'Force shutdown from a remote system'. Error: $($_.Exception.Message)" "Ensure 'Force shutdown from a remote system' is set to 'Administrators'" "User Rights Assignment" "High" "High" "Restrict shutdown privileges to administrators." "Review and ensure this is set to 'Administrators'."
}

try {
    # Ensure 'Generate security audits' is set to 'LOCAL SERVICE, NETWORK SERVICE'
    $securityAudits = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "SeAuditPrivilege" -ErrorAction Stop
    if ($securityAudits.SeAuditPrivilege -contains "LOCAL SERVICE" -and $securityAudits.SeAuditPrivilege -contains "NETWORK SERVICE") {
        Add-Result "2.2.23" "Pass" "Generate security audits is set correctly." "Ensure 'Generate security audits' is set to 'LOCAL SERVICE, NETWORK SERVICE'" "User Rights Assignment" "Medium" "Medium" "Restrict audit generation rights." "Review and ensure this is set to 'LOCAL SERVICE, NETWORK SERVICE'."
    } elseif ($securityAudits -eq $null) {
        Add-Result "2.2.23" "Null" "Generate security audits setting is missing." "Ensure 'Generate security audits' is set to 'LOCAL SERVICE, NETWORK SERVICE'" "User Rights Assignment" "Medium" "Medium" "Restrict audit generation rights." "Review and ensure this is set to 'LOCAL SERVICE, NETWORK SERVICE'."
    } else {
        Add-Result "2.2.23" "Fail" "Generate security audits is not set correctly." "Ensure 'Generate security audits' is set to 'LOCAL SERVICE, NETWORK SERVICE'" "User Rights Assignment" "Medium" "Medium" "Restrict audit generation rights." "Review and ensure this is set to 'LOCAL SERVICE, NETWORK SERVICE'."
    }
} catch {
    Add-Result "2.2.23" "Error" "Could not check 'Generate security audits'. Error: $($_.Exception.Message)" "Ensure 'Generate security audits' is set to 'LOCAL SERVICE, NETWORK SERVICE'" "User Rights Assignment" "Medium" "Medium" "Restrict audit generation rights." "Review and ensure this is set to 'LOCAL SERVICE, NETWORK SERVICE'."
}

try {
    # Ensure 'Impersonate a client after authentication' is set to 'Administrators, LOCAL SERVICE, NETWORK SERVICE, SERVICE'
    $impersonateClient = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "SeImpersonatePrivilege" -ErrorAction Stop
    if ($impersonateClient.SeImpersonatePrivilege -contains "Administrators" -and $impersonateClient.SeImpersonatePrivilege -contains "LOCAL SERVICE" -and $impersonateClient.SeImpersonatePrivilege -contains "NETWORK SERVICE" -and $impersonateClient.SeImpersonatePrivilege -contains "SERVICE") {
        Add-Result "2.2.24" "Pass" "Impersonate a client after authentication is set correctly." "Ensure 'Impersonate a client after authentication' is set to 'Administrators, LOCAL SERVICE, NETWORK SERVICE, SERVICE'" "User Rights Assignment" "Medium" "Medium" "Restrict impersonation privileges." "Review and ensure this is set to 'Administrators, LOCAL SERVICE, NETWORK SERVICE, SERVICE'."
    } elseif ($impersonateClient -eq $null) {
        Add-Result "2.2.24" "Null" "Impersonate a client after authentication setting is missing." "Ensure 'Impersonate a client after authentication' is set to 'Administrators, LOCAL SERVICE, NETWORK SERVICE, SERVICE'" "User Rights Assignment" "Medium" "Medium" "Restrict impersonation privileges." "Review and ensure this is set to 'Administrators, LOCAL SERVICE, NETWORK SERVICE, SERVICE'."
    } else {
        Add-Result "2.2.24" "Fail" "Impersonate a client after authentication is not set correctly." "Ensure 'Impersonate a client after authentication' is set to 'Administrators, LOCAL SERVICE, NETWORK SERVICE, SERVICE'" "User Rights Assignment" "Medium" "Medium" "Restrict impersonation privileges." "Review and ensure this is set to 'Administrators, LOCAL SERVICE, NETWORK SERVICE, SERVICE'."
    }
} catch {
    Add-Result "2.2.24" "Error" "Could not check 'Impersonate a client after authentication'. Error: $($_.Exception.Message)" "Ensure 'Impersonate a client after authentication' is set to 'Administrators, LOCAL SERVICE, NETWORK SERVICE, SERVICE'" "User Rights Assignment" "Medium" "Medium" "Restrict impersonation privileges." "Review and ensure this is set to 'Administrators, LOCAL SERVICE, NETWORK SERVICE, SERVICE'."
}

try {
    # Ensure 'Increase scheduling priority' is set to 'Administrators, Window Manager\Window Manager Group'
    $schedulingPriority = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "SeIncreaseBasePriorityPrivilege" -ErrorAction Stop
    if ($schedulingPriority.SeIncreaseBasePriorityPrivilege -contains "Administrators" -and $schedulingPriority.SeIncreaseBasePriorityPrivilege -contains "Window Manager\\Window Manager Group") {
        Add-Result "2.2.25" "Pass" "Increase scheduling priority is set correctly." "Ensure 'Increase scheduling priority' is set to 'Administrators, Window Manager\\Window Manager Group'" "User Rights Assignment" "Medium" "Medium" "Restrict priority adjustment privileges." "Review and ensure this is set to 'Administrators, Window Manager\\Window Manager Group'."
    } elseif ($schedulingPriority -eq $null) {
        Add-Result "2.2.25" "Null" "Increase scheduling priority setting is missing." "Ensure 'Increase scheduling priority' is set to 'Administrators, Window Manager\\Window Manager Group'" "User Rights Assignment" "Medium" "Medium" "Restrict priority adjustment privileges." "Review and ensure this is set to 'Administrators, Window Manager\\Window Manager Group'."
    } else {
        Add-Result "2.2.25" "Fail" "Increase scheduling priority is not set correctly." "Ensure 'Increase scheduling priority' is set to 'Administrators, Window Manager\\Window Manager Group'" "User Rights Assignment" "Medium" "Medium" "Restrict priority adjustment privileges." "Review and ensure this is set to 'Administrators, Window Manager\\Window Manager Group'."
    }
} catch {
    Add-Result "2.2.25" "Error" "Could not check 'Increase scheduling priority'. Error: $($_.Exception.Message)" "Ensure 'Increase scheduling priority' is set to 'Administrators, Window Manager\\Window Manager Group'" "User Rights Assignment" "Medium" "Medium" "Restrict priority adjustment privileges." "Review and ensure this is set to 'Administrators, Window Manager\\Window Manager Group'."
}

try {
    # Ensure 'Load and unload device drivers' is set to 'Administrators'
    $deviceDrivers = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "SeLoadDriverPrivilege" -ErrorAction Stop
    if ($deviceDrivers.SeLoadDriverPrivilege -eq "Administrators") {
        Add-Result "2.2.26" "Pass" "Load and unload device drivers is set correctly." "Ensure 'Load and unload device drivers' is set to 'Administrators'" "User Rights Assignment" "High" "High" "Restrict this right to Administrators only." "Review and ensure only 'Administrators' have this right."
    } elseif ($deviceDrivers -eq $null) {
        Add-Result "2.2.26" "Null" "Load and unload device drivers setting is missing." "Ensure 'Load and unload device drivers' is set to 'Administrators'" "User Rights Assignment" "High" "High" "Restrict this right to Administrators only." "Review and ensure only 'Administrators' have this right."
    } else {
        Add-Result "2.2.26" "Fail" "Load and unload device drivers is not set to 'Administrators'." "Ensure 'Load and unload device drivers' is set to 'Administrators'" "User Rights Assignment" "High" "High" "Restrict this right to Administrators only." "Review and ensure only 'Administrators' have this right."
    }
} catch {
    Add-Result "2.2.26" "Error" "Could not check 'Load and unload device drivers'. Error: $($_.Exception.Message)" "Ensure 'Load and unload device drivers' is set to 'Administrators'" "User Rights Assignment" "High" "High" "Restrict this right to Administrators only." "Review and ensure only 'Administrators' have this right."
}

try {
    # Ensure 'Lock pages in memory' is set to 'No One'
    $lockPages = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "SeLockMemoryPrivilege" -ErrorAction Stop
    if ($lockPages.SeLockMemoryPrivilege -eq "NoOne") {
        Add-Result "2.2.27" "Pass" "Lock pages in memory is set correctly." "Ensure 'Lock pages in memory' is set to 'No One'" "User Rights Assignment" "High" "High" "Restrict this right to no one." "Review and set to 'No One'."
    } elseif ($lockPages -eq $null) {
        Add-Result "2.2.27" "Null" "Lock pages in memory setting is missing." "Ensure 'Lock pages in memory' is set to 'No One'" "User Rights Assignment" "High" "High" "Restrict this right to no one." "Review and set to 'No One'."
    } else {
        Add-Result "2.2.27" "Fail" "Lock pages in memory is not set to 'No One'." "Ensure 'Lock pages in memory' is set to 'No One'" "User Rights Assignment" "High" "High" "Restrict this right to no one." "Review and set to 'No One'."
    }
} catch {
    Add-Result "2.2.27" "Error" "Could not check 'Lock pages in memory'. Error: $($_.Exception.Message)" "Ensure 'Lock pages in memory' is set to 'No One'" "User Rights Assignment" "High" "High" "Restrict this right to no one." "Review and set to 'No One'."
}

try {
    # Ensure 'Log on as a batch job' is set to 'Administrators'
    $batchJob = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "SeBatchLogonRight" -ErrorAction Stop
    if ($batchJob.SeBatchLogonRight -eq "Administrators") {
        Add-Result "2.2.28" "Pass" "Log on as a batch job is set correctly." "Ensure 'Log on as a batch job' is set to 'Administrators'" "User Rights Assignment" "Medium" "Medium" "Restrict batch job logon to Administrators." "Review and set to 'Administrators'."
    } elseif ($batchJob -eq $null) {
        Add-Result "2.2.28" "Null" "Log on as a batch job setting is missing." "Ensure 'Log on as a batch job' is set to 'Administrators'" "User Rights Assignment" "Medium" "Medium" "Restrict batch job logon to Administrators." "Review and set to 'Administrators'."
    } else {
        Add-Result "2.2.28" "Fail" "Log on as a batch job is not set to 'Administrators'." "Ensure 'Log on as a batch job' is set to 'Administrators'" "User Rights Assignment" "Medium" "Medium" "Restrict batch job logon to Administrators." "Review and set to 'Administrators'."
    }
} catch {
    Add-Result "2.2.28" "Error" "Could not check 'Log on as a batch job'. Error: $($_.Exception.Message)" "Ensure 'Log on as a batch job' is set to 'Administrators'" "User Rights Assignment" "Medium" "Medium" "Restrict batch job logon to Administrators." "Review and set to 'Administrators'."
}

try {
    # Configure 'Log on as a service'
    $serviceLogon = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "SeServiceLogonRight" -ErrorAction Stop
    if ($serviceLogon -ne $null) {
        Add-Result "2.2.29" "Pass" "Log on as a service is configured." "Configure 'Log on as a service'" "User Rights Assignment" "Medium" "Medium" "Ensure the setting aligns with organizational policy." "Review and configure as per requirements."
    } else {
        Add-Result "2.2.29" "Null" "Log on as a service setting is missing." "Configure 'Log on as a service'" "User Rights Assignment" "Medium" "Medium" "Ensure the setting aligns with organizational policy." "Review and configure as per requirements."
    }
} catch {
    Add-Result "2.2.29" "Error" "Could not check 'Log on as a service'. Error: $($_.Exception.Message)" "Configure 'Log on as a service'" "User Rights Assignment" "Medium" "Medium" "Ensure the setting aligns with organizational policy." "Review and configure as per requirements."
}

try {
    # Ensure 'Manage auditing and security log' is set to 'Administrators'
    $auditLog = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "SeSecurityPrivilege" -ErrorAction Stop
    if ($auditLog.SeSecurityPrivilege -eq "Administrators") {
        Add-Result "2.2.30" "Pass" "Manage auditing and security log is set correctly." "Ensure 'Manage auditing and security log' is set to 'Administrators'" "User Rights Assignment" "High" "High" "Restrict this right to Administrators." "Review and ensure only 'Administrators' have this right."
    } elseif ($auditLog -eq $null) {
        Add-Result "2.2.30" "Null" "Manage auditing and security log setting is missing." "Ensure 'Manage auditing and security log' is set to 'Administrators'" "User Rights Assignment" "High" "High" "Restrict this right to Administrators." "Review and ensure only 'Administrators' have this right."
    } else {
        Add-Result "2.2.30" "Fail" "Manage auditing and security log is not set to 'Administrators'." "Ensure 'Manage auditing and security log' is set to 'Administrators'" "User Rights Assignment" "High" "High" "Restrict this right to Administrators." "Review and ensure only 'Administrators' have this right."
    }
} catch {
    Add-Result "2.2.30" "Error" "Could not check 'Manage auditing and security log'. Error: $($_.Exception.Message)" "Ensure 'Manage auditing and security log' is set to 'Administrators'" "User Rights Assignment" "High" "High" "Restrict this right to Administrators." "Review and ensure only 'Administrators' have this right."
}

try {
    # Ensure 'Modify an object label' is set to 'No One'
    $objectLabel = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "SeRelabelPrivilege" -ErrorAction Stop
    if ($objectLabel.SeRelabelPrivilege -eq "NoOne") {
        Add-Result "2.2.31" "Pass" "Modify an object label is set correctly." "Ensure 'Modify an object label' is set to 'No One'" "User Rights Assignment" "High" "High" "Restrict the ability to modify object labels." "Review and update to 'No One'."
    } elseif ($objectLabel -eq $null) {
        Add-Result "2.2.31" "Null" "Modify an object label setting is missing." "Ensure 'Modify an object label' is set to 'No One'" "User Rights Assignment" "High" "High" "Restrict the ability to modify object labels." "Review and update to 'No One'."
    } else {
        Add-Result "2.2.31" "Fail" "Modify an object label is not set to 'No One'." "Ensure 'Modify an object label' is set to 'No One'" "User Rights Assignment" "High" "High" "Restrict the ability to modify object labels." "Review and update to 'No One'."
    }
} catch {
    Add-Result "2.2.31" "Error" "Could not check 'Modify an object label'. Error: $($_.Exception.Message)" "Ensure 'Modify an object label' is set to 'No One'" "User Rights Assignment" "High" "High" "Restrict the ability to modify object labels." "Review and update to 'No One'."
}

try {
    # Ensure 'Modify firmware environment values' is set to 'Administrators'
    $firmwareValues = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "SeSystemEnvironmentPrivilege" -ErrorAction Stop
    if ($firmwareValues.SeSystemEnvironmentPrivilege -eq "Administrators") {
        Add-Result "2.2.32" "Pass" "Modify firmware environment values is set correctly." "Ensure 'Modify firmware environment values' is set to 'Administrators'" "User Rights Assignment" "High" "High" "Restrict modification of firmware environment values." "Review and update to 'Administrators'."
    } elseif ($firmwareValues -eq $null) {
        Add-Result "2.2.32" "Null" "Modify firmware environment values setting is missing." "Ensure 'Modify firmware environment values' is set to 'Administrators'" "User Rights Assignment" "High" "High" "Restrict modification of firmware environment values." "Review and update to 'Administrators'."
    } else {
        Add-Result "2.2.32" "Fail" "Modify firmware environment values is not set to 'Administrators'." "Ensure 'Modify firmware environment values' is set to 'Administrators'" "User Rights Assignment" "High" "High" "Restrict modification of firmware environment values." "Review and update to 'Administrators'."
    }
} catch {
    Add-Result "2.2.32" "Error" "Could not check 'Modify firmware environment values'. Error: $($_.Exception.Message)" "Ensure 'Modify firmware environment values' is set to 'Administrators'" "User Rights Assignment" "High" "High" "Restrict modification of firmware environment values." "Review and update to 'Administrators'."
}

try {
    # Ensure 'Perform volume maintenance tasks' is set to 'Administrators'
    $volumeMaintenance = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "SeManageVolumePrivilege" -ErrorAction Stop
    if ($volumeMaintenance.SeManageVolumePrivilege -eq "Administrators") {
        Add-Result "2.2.33" "Pass" "Perform volume maintenance tasks is set correctly." "Ensure 'Perform volume maintenance tasks' is set to 'Administrators'" "User Rights Assignment" "High" "High" "Restrict volume maintenance tasks to administrators." "Review and update to 'Administrators'."
    } elseif ($volumeMaintenance -eq $null) {
        Add-Result "2.2.33" "Null" "Perform volume maintenance tasks setting is missing." "Ensure 'Perform volume maintenance tasks' is set to 'Administrators'" "User Rights Assignment" "High" "High" "Restrict volume maintenance tasks to administrators." "Review and update to 'Administrators'."
    } else {
        Add-Result "2.2.33" "Fail" "Perform volume maintenance tasks is not set to 'Administrators'." "Ensure 'Perform volume maintenance tasks' is set to 'Administrators'" "User Rights Assignment" "High" "High" "Restrict volume maintenance tasks to administrators." "Review and update to 'Administrators'."
    }
} catch {
    Add-Result "2.2.33" "Error" "Could not check 'Perform volume maintenance tasks'. Error: $($_.Exception.Message)" "Ensure 'Perform volume maintenance tasks' is set to 'Administrators'" "User Rights Assignment" "High" "High" "Restrict volume maintenance tasks to administrators." "Review and update to 'Administrators'."
}

try {
    # Ensure 'Profile single process' is set to 'Administrators'
    $profileProcess = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "SeProfileSingleProcessPrivilege" -ErrorAction Stop
    if ($profileProcess.SeProfileSingleProcessPrivilege -eq "Administrators") {
        Add-Result "2.2.34" "Pass" "Profile single process is set correctly." "Ensure 'Profile single process' is set to 'Administrators'" "User Rights Assignment" "Medium" "Medium" "Restrict process profiling to administrators." "Review and update to 'Administrators'."
    } elseif ($profileProcess -eq $null) {
        Add-Result "2.2.34" "Null" "Profile single process setting is missing." "Ensure 'Profile single process' is set to 'Administrators'" "User Rights Assignment" "Medium" "Medium" "Restrict process profiling to administrators." "Review and update to 'Administrators'."
    } else {
        Add-Result "2.2.34" "Fail" "Profile single process is not set to 'Administrators'." "Ensure 'Profile single process' is set to 'Administrators'" "User Rights Assignment" "Medium" "Medium" "Restrict process profiling to administrators." "Review and update to 'Administrators'."
    }
} catch {
    Add-Result "2.2.34" "Error" "Could not check 'Profile single process'. Error: $($_.Exception.Message)" "Ensure 'Profile single process' is set to 'Administrators'" "User Rights Assignment" "Medium" "Medium" "Restrict process profiling to administrators." "Review and update to 'Administrators'."
}

try {
    # Ensure 'Profile system performance' is set to 'Administrators, NT SERVICE\WdiServiceHost'
    $profilePerformance = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "SeSystemProfilePrivilege" -ErrorAction Stop
    if ($profilePerformance.SeSystemProfilePrivilege -contains "Administrators" -and $profilePerformance.SeSystemProfilePrivilege -contains "NT SERVICE\WdiServiceHost") {
        Add-Result "2.2.35" "Pass" "Profile system performance is set correctly." "Ensure 'Profile system performance' is set to 'Administrators, NT SERVICE\\WdiServiceHost'" "User Rights Assignment" "Medium" "Medium" "Restrict system performance profiling to administrators and WdiServiceHost." "Review and update to 'Administrators, NT SERVICE\\WdiServiceHost'."
    } elseif ($profilePerformance -eq $null) {
        Add-Result "2.2.35" "Null" "Profile system performance setting is missing." "Ensure 'Profile system performance' is set to 'Administrators, NT SERVICE\\WdiServiceHost'" "User Rights Assignment" "Medium" "Medium" "Restrict system performance profiling to administrators and WdiServiceHost." "Review and update to 'Administrators, NT SERVICE\\WdiServiceHost'."
    } else {
        Add-Result "2.2.35" "Fail" "Profile system performance is not set correctly." "Ensure 'Profile system performance' is set to 'Administrators, NT SERVICE\\WdiServiceHost'" "User Rights Assignment" "Medium" "Medium" "Restrict system performance profiling to administrators and WdiServiceHost." "Review and update to 'Administrators, NT SERVICE\\WdiServiceHost'."
    }
} catch {
    Add-Result "2.2.35" "Error" "Could not check 'Profile system performance'. Error: $($_.Exception.Message)" "Ensure 'Profile system performance' is set to 'Administrators, NT SERVICE\\WdiServiceHost'" "User Rights Assignment" "Medium" "Medium" "Restrict system performance profiling to administrators and WdiServiceHost." "Review and update to 'Administrators, NT SERVICE\\WdiServiceHost'."
}

try {
    # Ensure 'Replace a process level token' is set to 'LOCAL SERVICE, NETWORK SERVICE'
    $replaceToken = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "SeAssignPrimaryTokenPrivilege" -ErrorAction Stop
    if ($replaceToken.SeAssignPrimaryTokenPrivilege -contains "LOCAL SERVICE" -and $replaceToken.SeAssignPrimaryTokenPrivilege -contains "NETWORK SERVICE") {
        Add-Result "2.2.36" "Pass" "Replace a process level token is set correctly." "Ensure 'Replace a process level token' is set to 'LOCAL SERVICE, NETWORK SERVICE'" "User Rights Assignment" "Medium" "Medium" "Restrict the ability to replace process level tokens." "Review and set to 'LOCAL SERVICE, NETWORK SERVICE'."
    } elseif ($replaceToken -eq $null) {
        Add-Result "2.2.36" "Null" "Replace a process level token setting is missing." "Ensure 'Replace a process level token' is set to 'LOCAL SERVICE, NETWORK SERVICE'" "User Rights Assignment" "Medium" "Medium" "Restrict the ability to replace process level tokens." "Review and set to 'LOCAL SERVICE, NETWORK SERVICE'."
    } else {
        Add-Result "2.2.36" "Fail" "Replace a process level token is not set correctly." "Ensure 'Replace a process level token' is set to 'LOCAL SERVICE, NETWORK SERVICE'" "User Rights Assignment" "Medium" "Medium" "Restrict the ability to replace process level tokens." "Review and set to 'LOCAL SERVICE, NETWORK SERVICE'."
    }
} catch {
    Add-Result "2.2.36" "Error" "Could not check 'Replace a process level token'. Error: $($_.Exception.Message)" "Ensure 'Replace a process level token' is set to 'LOCAL SERVICE, NETWORK SERVICE'" "User Rights Assignment" "Medium" "Medium" "Restrict the ability to replace process level tokens." "Review and set to 'LOCAL SERVICE, NETWORK SERVICE'."
}

try {
    # Ensure 'Restore files and directories' is set to 'Administrators'
    $restoreFiles = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "SeRestorePrivilege" -ErrorAction Stop
    if ($restoreFiles.SeRestorePrivilege -eq "Administrators") {
        Add-Result "2.2.37" "Pass" "Restore files and directories is set correctly." "Ensure 'Restore files and directories' is set to 'Administrators'" "User Rights Assignment" "High" "High" "Restrict the ability to restore files and directories." "Review and set to 'Administrators'."
    } elseif ($restoreFiles -eq $null) {
        Add-Result "2.2.37" "Null" "Restore files and directories setting is missing." "Ensure 'Restore files and directories' is set to 'Administrators'" "User Rights Assignment" "High" "High" "Restrict the ability to restore files and directories." "Review and set to 'Administrators'."
    } else {
        Add-Result "2.2.37" "Fail" "Restore files and directories is not set to 'Administrators'." "Ensure 'Restore files and directories' is set to 'Administrators'" "User Rights Assignment" "High" "High" "Restrict the ability to restore files and directories." "Review and set to 'Administrators'."
    }
} catch {
    Add-Result "2.2.37" "Error" "Could not check 'Restore files and directories'. Error: $($_.Exception.Message)" "Ensure 'Restore files and directories' is set to 'Administrators'" "User Rights Assignment" "High" "High" "Restrict the ability to restore files and directories." "Review and set to 'Administrators'."
}

try {
    # Ensure 'Shut down the system' is set to 'Administrators, Users'
    $shutdownSystem = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "SeShutdownPrivilege" -ErrorAction Stop
    if ($shutdownSystem.SeShutdownPrivilege -contains "Administrators" -and $shutdownSystem.SeShutdownPrivilege -contains "Users") {
        Add-Result "2.2.38" "Pass" "Shut down the system is set correctly." "Ensure 'Shut down the system' is set to 'Administrators, Users'" "User Rights Assignment" "Medium" "Medium" "Restrict the ability to shut down the system." "Review and set to 'Administrators, Users'."
    } elseif ($shutdownSystem -eq $null) {
        Add-Result "2.2.38" "Null" "Shut down the system setting is missing." "Ensure 'Shut down the system' is set to 'Administrators, Users'" "User Rights Assignment" "Medium" "Medium" "Restrict the ability to shut down the system." "Review and set to 'Administrators, Users'."
    } else {
        Add-Result "2.2.38" "Fail" "Shut down the system is not set to 'Administrators, Users'." "Ensure 'Shut down the system' is set to 'Administrators, Users'" "User Rights Assignment" "Medium" "Medium" "Restrict the ability to shut down the system." "Review and set to 'Administrators, Users'."
    }
} catch {
    Add-Result "2.2.38" "Error" "Could not check 'Shut down the system'. Error: $($_.Exception.Message)" "Ensure 'Shut down the system' is set to 'Administrators, Users'" "User Rights Assignment" "Medium" "Medium" "Restrict the ability to shut down the system." "Review and set to 'Administrators, Users'."
}

try {
    # Ensure 'Take ownership of files or other objects' is set to 'Administrators'
    $takeOwnership = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "SeTakeOwnershipPrivilege" -ErrorAction Stop
    if ($takeOwnership.SeTakeOwnershipPrivilege -eq "Administrators") {
        Add-Result "2.2.39" "Pass" "Take ownership of files or other objects is set correctly." "Ensure 'Take ownership of files or other objects' is set to 'Administrators'" "User Rights Assignment" "High" "High" "Restrict the ability to take ownership of files or objects." "Review and set to 'Administrators'."
    } elseif ($takeOwnership -eq $null) {
        Add-Result "2.2.39" "Null" "Take ownership of files or other objects setting is missing." "Ensure 'Take ownership of files or other objects' is set to 'Administrators'" "User Rights Assignment" "High" "High" "Restrict the ability to take ownership of files or objects." "Review and set to 'Administrators'."
    } else {
        Add-Result "2.2.39" "Fail" "Take ownership of files or other objects is not set to 'Administrators'." "Ensure 'Take ownership of files or other objects' is set to 'Administrators'" "User Rights Assignment" "High" "High" "Restrict the ability to take ownership of files or objects." "Review and set to 'Administrators'."
    }
} catch {
    Add-Result "2.2.39" "Error" "Could not check 'Take ownership of files or other objects'. Error: $($_.Exception.Message)" "Ensure 'Take ownership of files or other objects' is set to 'Administrators'" "User Rights Assignment" "High" "High" "Restrict the ability to take ownership of files or objects." "Review and set to 'Administrators'."
}

try {
    # Ensure 'Accounts: Block Microsoft accounts' is set to 'Users can\'t add or log on with Microsoft accounts'
    $blockMSAccounts = Get-ItemProperty -Path "HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System" -Name "NoConnectedUser" -ErrorAction Stop
    if ($blockMSAccounts.NoConnectedUser -eq 3) {
        Add-Result "2.3.1.1" "Pass" "Accounts: Block Microsoft accounts is set correctly." "Ensure 'Accounts: Block Microsoft accounts' is set to 'Users can\'t add or log on with Microsoft accounts'" "Accounts" "High" "High" "Prevent use of Microsoft accounts." "Review and set the policy to 'Users can\'t add or log on with Microsoft accounts'."
    } elseif ($blockMSAccounts -eq $null) {
        Add-Result "2.3.1.1" "Null" "Accounts: Block Microsoft accounts setting is missing." "Ensure 'Accounts: Block Microsoft accounts' is set to 'Users can\'t add or log on with Microsoft accounts'" "Accounts" "High" "High" "Prevent use of Microsoft accounts." "Review and set the policy to 'Users can\'t add or log on with Microsoft accounts'."
    } else {
        Add-Result "2.3.1.1" "Fail" "Accounts: Block Microsoft accounts is not set correctly." "Ensure 'Accounts: Block Microsoft accounts' is set to 'Users can\'t add or log on with Microsoft accounts'" "Accounts" "High" "High" "Prevent use of Microsoft accounts." "Review and set the policy to 'Users can\'t add or log on with Microsoft accounts'."
    }
} catch {
    Add-Result "2.3.1.1" "Error" "Could not check 'Accounts: Block Microsoft accounts'. Error: $($_.Exception.Message)" "Ensure 'Accounts: Block Microsoft accounts' is set to 'Users can\'t add or log on with Microsoft accounts'" "Accounts" "High" "High" "Prevent use of Microsoft accounts." "Review and set the policy to 'Users can\'t add or log on with Microsoft accounts'."
}

try {
    # Ensure 'Accounts: Guest account status' is set to 'Disabled'
    $guestAccountStatus = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" -Name "RestrictNullSessAccess" -ErrorAction Stop
    if ($guestAccountStatus.RestrictNullSessAccess -eq 1) {
        Add-Result "2.3.1.2" "Pass" "Accounts: Guest account status is set to 'Disabled'." "Ensure 'Accounts: Guest account status' is set to 'Disabled'" "Accounts" "Medium" "Medium" "Disable the guest account." "Review and ensure the guest account is disabled."
    } elseif ($guestAccountStatus -eq $null) {
        Add-Result "2.3.1.2" "Null" "Accounts: Guest account status setting is missing." "Ensure 'Accounts: Guest account status' is set to 'Disabled'" "Accounts" "Medium" "Medium" "Disable the guest account." "Review and ensure the guest account is disabled."
    } else {
        Add-Result "2.3.1.2" "Fail" "Accounts: Guest account status is not set to 'Disabled'." "Ensure 'Accounts: Guest account status' is set to 'Disabled'" "Accounts" "Medium" "Medium" "Disable the guest account." "Review and ensure the guest account is disabled."
    }
} catch {
    Add-Result "2.3.1.2" "Error" "Could not check 'Accounts: Guest account status'. Error: $($_.Exception.Message)" "Ensure 'Accounts: Guest account status' is set to 'Disabled'" "Accounts" "Medium" "Medium" "Disable the guest account." "Review and ensure the guest account is disabled."
}

try {
    # Ensure 'Accounts: Limit local account use of blank passwords to console logon only' is set to 'Enabled'
    $limitBlankPasswords = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "LimitBlankPasswordUse" -ErrorAction Stop
    if ($limitBlankPasswords.LimitBlankPasswordUse -eq 1) {
        Add-Result "2.3.1.3" "Pass" "Accounts: Limit local account use of blank passwords to console logon only is set to 'Enabled'." "Ensure 'Accounts: Limit local account use of blank passwords to console logon only' is set to 'Enabled'" "Accounts" "High" "High" "Restrict use of blank passwords." "Review and ensure the policy is set to 'Enabled'."
    } elseif ($limitBlankPasswords -eq $null) {
        Add-Result "2.3.1.3" "Null" "Accounts: Limit local account use of blank passwords to console logon only setting is missing." "Ensure 'Accounts: Limit local account use of blank passwords to console logon only' is set to 'Enabled'" "Accounts" "High" "High" "Restrict use of blank passwords." "Review and ensure the policy is set to 'Enabled'."
    } else {
        Add-Result "2.3.1.3" "Fail" "Accounts: Limit local account use of blank passwords to console logon only is not set to 'Enabled'." "Ensure 'Accounts: Limit local account use of blank passwords to console logon only' is set to 'Enabled'" "Accounts" "High" "High" "Restrict use of blank passwords." "Review and ensure the policy is set to 'Enabled'."
    }
} catch {
    Add-Result "2.3.1.3" "Error" "Could not check 'Accounts: Limit local account use of blank passwords to console logon only'. Error: $($_.Exception.Message)" "Ensure 'Accounts: Limit local account use of blank passwords to console logon only' is set to 'Enabled'" "Accounts" "High" "High" "Restrict use of blank passwords." "Review and ensure the policy is set to 'Enabled'."
}

try {
    # Configure 'Accounts: Rename administrator account'
    $renameAdminAccount = Get-ItemProperty -Path "HKLM:\SAM\SAM\Domains\Account\Users\000001F4" -Name "F" -ErrorAction Stop
    if ($renameAdminAccount.F -ne "Administrator") {
        Add-Result "2.3.1.4" "Pass" "Accounts: Rename administrator account is set correctly." "Configure 'Accounts: Rename administrator account'" "Accounts" "High" "High" "Rename the default administrator account." "Review and ensure the administrator account is renamed."
    } elseif ($renameAdminAccount -eq $null) {
        Add-Result "2.3.1.4" "Null" "Accounts: Rename administrator account setting is missing." "Configure 'Accounts: Rename administrator account'" "Accounts" "High" "High" "Rename the default administrator account." "Review and ensure the administrator account is renamed."
    } else {
        Add-Result "2.3.1.4" "Fail" "Accounts: Rename administrator account is not set correctly." "Configure 'Accounts: Rename administrator account'" "Accounts" "High" "High" "Rename the default administrator account." "Review and ensure the administrator account is renamed."
    }
} catch {
    Add-Result "2.3.1.4" "Error" "Could not check 'Accounts: Rename administrator account'. Error: $($_.Exception.Message)" "Configure 'Accounts: Rename administrator account'" "Accounts" "High" "High" "Rename the default administrator account." "Review and ensure the administrator account is renamed."
}

try {
    # Configure 'Accounts: Rename guest account'
    $renameGuestAccount = Get-ItemProperty -Path "HKLM:\SAM\SAM\Domains\Account\Users\000001F5" -Name "F" -ErrorAction Stop
    if ($renameGuestAccount.F -ne "Guest") {
        Add-Result "2.3.1.5" "Pass" "Accounts: Rename guest account is set correctly." "Configure 'Accounts: Rename guest account'" "Accounts" "Medium" "Medium" "Rename the default guest account." "Review and ensure the guest account is renamed."
    } elseif ($renameGuestAccount -eq $null) {
        Add-Result "2.3.1.5" "Null" "Accounts: Rename guest account setting is missing." "Configure 'Accounts: Rename guest account'" "Accounts" "Medium" "Medium" "Rename the default guest account." "Review and ensure the guest account is renamed."
    } else {
        Add-Result "2.3.1.5" "Fail" "Accounts: Rename guest account is not set correctly." "Configure 'Accounts: Rename guest account'" "Accounts" "Medium" "Medium" "Rename the default guest account." "Review and ensure the guest account is renamed."
    }
} catch {
    Add-Result "2.3.1.5" "Error" "Could not check 'Accounts: Rename guest account'. Error: $($_.Exception.Message)" "Configure 'Accounts: Rename guest account'" "Accounts" "Medium" "Medium" "Rename the default guest account." "Review and ensure the guest account is renamed."
}

try {
    # Ensure 'Audit: Force audit policy subcategory settings (Windows Vista or later) to override audit policy category settings' is set to 'Enabled'
    $forceAuditSettings = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "SCENoApplyLegacyAuditPolicy" -ErrorAction Stop
    if ($forceAuditSettings.SCENoApplyLegacyAuditPolicy -eq 1) {
        Add-Result "2.3.2.1" "Pass" "Audit: Force audit policy subcategory settings to override audit policy category settings is set to 'Enabled'." "Ensure 'Audit: Force audit policy subcategory settings (Windows Vista or later) to override audit policy category settings' is set to 'Enabled'" "Audit" "High" "High" "Ensure detailed audit policies take precedence." "Review and set the policy to 'Enabled'."
    } elseif ($forceAuditSettings -eq $null) {
        Add-Result "2.3.2.1" "Null" "Audit: Force audit policy subcategory settings setting is missing." "Ensure 'Audit: Force audit policy subcategory settings (Windows Vista or later) to override audit policy category settings' is set to 'Enabled'" "Audit" "High" "High" "Ensure detailed audit policies take precedence." "Review and set the policy to 'Enabled'."
    } else {
        Add-Result "2.3.2.1" "Fail" "Audit: Force audit policy subcategory settings is not set to 'Enabled'." "Ensure 'Audit: Force audit policy subcategory settings (Windows Vista or later) to override audit policy category settings' is set to 'Enabled'" "Audit" "High" "High" "Ensure detailed audit policies take precedence." "Review and set the policy to 'Enabled'."
    }
} catch {
    Add-Result "2.3.2.1" "Error" "Could not check 'Audit: Force audit policy subcategory settings'. Error: $($_.Exception.Message)" "Ensure 'Audit: Force audit policy subcategory settings (Windows Vista or later) to override audit policy category settings' is set to 'Enabled'" "Audit" "High" "High" "Ensure detailed audit policies take precedence." "Review and set the policy to 'Enabled'."
}

try {
    # Ensure 'Audit: Shut down system immediately if unable to log security audits' is set to 'Disabled'
    $auditShutdown = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "CrashOnAuditFail" -ErrorAction Stop
    if ($auditShutdown.CrashOnAuditFail -eq 0) {
        Add-Result "2.3.2.2" "Pass" "Audit: Shut down system immediately if unable to log security audits is set to 'Disabled'." "Ensure 'Audit: Shut down system immediately if unable to log security audits' is set to 'Disabled'" "Audit" "Medium" "Medium" "Prevent system shutdowns due to audit failures." "Review and set the policy to 'Disabled'."
    } elseif ($auditShutdown -eq $null) {
        Add-Result "2.3.2.2" "Null" "Audit: Shut down system immediately if unable to log security audits setting is missing." "Ensure 'Audit: Shut down system immediately if unable to log security audits' is set to 'Disabled'" "Audit" "Medium" "Medium" "Prevent system shutdowns due to audit failures." "Review and set the policy to 'Disabled'."
    } else {
        Add-Result "2.3.2.2" "Fail" "Audit: Shut down system immediately if unable to log security audits is not set to 'Disabled'." "Ensure 'Audit: Shut down system immediately if unable to log security audits' is set to 'Disabled'" "Audit" "Medium" "Medium" "Prevent system shutdowns due to audit failures." "Review and set the policy to 'Disabled'."
    }
} catch {
    Add-Result "2.3.2.2" "Error" "Could not check 'Audit: Shut down system immediately if unable to log security audits'. Error: $($_.Exception.Message)" "Ensure 'Audit: Shut down system immediately if unable to log security audits' is set to 'Disabled'" "Audit" "Medium" "Medium" "Prevent system shutdowns due to audit failures." "Review and set the policy to 'Disabled'."
}

try {
    # Ensure 'Interactive logon: Do not require CTRL+ALT+DEL' is set to 'Disabled'
    $requireCtrlAltDel = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "DisableCAD" -ErrorAction Stop
    if ($requireCtrlAltDel.DisableCAD -eq 0) {
        Add-Result "2.3.7.1" "Pass" "Interactive logon: Do not require CTRL+ALT+DEL is set to 'Disabled'." "Ensure 'Interactive logon: Do not require CTRL+ALT+DEL' is set to 'Disabled'" "Interactive logon" "Medium" "Medium" "Require users to press CTRL+ALT+DEL before logging on." "Review and ensure the policy is set to 'Disabled'."
    } elseif ($requireCtrlAltDel -eq $null) {
        Add-Result "2.3.7.1" "Null" "Interactive logon: Do not require CTRL+ALT+DEL setting is missing." "Ensure 'Interactive logon: Do not require CTRL+ALT+DEL' is set to 'Disabled'" "Interactive logon" "Medium" "Medium" "Require users to press CTRL+ALT+DEL before logging on." "Review and ensure the policy is set to 'Disabled'."
    } else {
        Add-Result "2.3.7.1" "Fail" "Interactive logon: Do not require CTRL+ALT+DEL is not set to 'Disabled'." "Ensure 'Interactive logon: Do not require CTRL+ALT+DEL' is set to 'Disabled'" "Interactive logon" "Medium" "Medium" "Require users to press CTRL+ALT+DEL before logging on." "Review and ensure the policy is set to 'Disabled'."
    }
} catch {
    Add-Result "2.3.7.1" "Error" "Could not check 'Interactive logon: Do not require CTRL+ALT+DEL'. Error: $($_.Exception.Message)" "Ensure 'Interactive logon: Do not require CTRL+ALT+DEL' is set to 'Disabled'" "Interactive logon" "Medium" "Medium" "Require users to press CTRL+ALT+DEL before logging on." "Review and ensure the policy is set to 'Disabled'."
}

try {
    # Ensure 'Interactive logon: Don't display last signed-in' is set to 'Enabled'
    $dontDisplayLastSignedIn = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "DontDisplayLastUserName" -ErrorAction Stop
    if ($dontDisplayLastSignedIn.DontDisplayLastUserName -eq 1) {
        Add-Result "2.3.7.2" "Pass" "Interactive logon: Don't display last signed-in is set to 'Enabled'." "Ensure 'Interactive logon: Don't display last signed-in' is set to 'Enabled'" "Interactive logon" "Medium" "Medium" "Do not display the last signed-in username." "Review and ensure the policy is set to 'Enabled'."
    } elseif ($dontDisplayLastSignedIn -eq $null) {
        Add-Result "2.3.7.2" "Null" "Interactive logon: Don't display last signed-in setting is missing." "Ensure 'Interactive logon: Don't display last signed-in' is set to 'Enabled'" "Interactive logon" "Medium" "Medium" "Do not display the last signed-in username." "Review and ensure the policy is set to 'Enabled'."
    } else {
        Add-Result "2.3.7.2" "Fail" "Interactive logon: Don't display last signed-in is not set to 'Enabled'." "Ensure 'Interactive logon: Don't display last signed-in' is set to 'Enabled'" "Interactive logon" "Medium" "Medium" "Do not display the last signed-in username." "Review and ensure the policy is set to 'Enabled'."
    }
} catch {
    Add-Result "2.3.7.2" "Error" "Could not check 'Interactive logon: Don't display last signed-in'. Error: $($_.Exception.Message)" "Ensure 'Interactive logon: Don't display last signed-in' is set to 'Enabled'" "Interactive logon" "Medium" "Medium" "Do not display the last signed-in username." "Review and ensure the policy is set to 'Enabled'."
}

try {
    # Ensure 'Interactive logon: Machine account lockout threshold' is set to '10 or fewer invalid logon attempts, but not 0'
    $machineAccountLockout = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "MaxDevicePasswordFailedAttempts" -ErrorAction Stop
    if ($machineAccountLockout.MaxDevicePasswordFailedAttempts -le 10 -and $machineAccountLockout.MaxDevicePasswordFailedAttempts -gt 0) {
        Add-Result "2.3.7.3" "Pass" "Interactive logon: Machine account lockout threshold is set correctly." "Ensure 'Interactive logon: Machine account lockout threshold' is set to '10 or fewer invalid logon attempts, but not 0'" "Interactive logon" "High" "High" "Prevent unlimited invalid logon attempts." "Review and ensure the threshold is set correctly."
    } elseif ($machineAccountLockout -eq $null) {
        Add-Result "2.3.7.3" "Null" "Interactive logon: Machine account lockout threshold setting is missing." "Ensure 'Interactive logon: Machine account lockout threshold' is set to '10 or fewer invalid logon attempts, but not 0'" "Interactive logon" "High" "High" "Prevent unlimited invalid logon attempts." "Review and ensure the threshold is set correctly."
    } else {
        Add-Result "2.3.7.3" "Fail" "Interactive logon: Machine account lockout threshold is not set correctly." "Ensure 'Interactive logon: Machine account lockout threshold' is set to '10 or fewer invalid logon attempts, but not 0'" "Interactive logon" "High" "High" "Prevent unlimited invalid logon attempts." "Review and ensure the threshold is set correctly."
    }
} catch {
    Add-Result "2.3.7.3" "Error" "Could not check 'Interactive logon: Machine account lockout threshold'. Error: $($_.Exception.Message)" "Ensure 'Interactive logon: Machine account lockout threshold' is set to '10 or fewer invalid logon attempts, but not 0'" "Interactive logon" "High" "High" "Prevent unlimited invalid logon attempts." "Review and ensure the threshold is set correctly."
}

try {
    # Ensure 'Interactive logon: Machine inactivity limit' is set to '900 or fewer second(s), but not 0'
    $machineInactivityLimit = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "InactivityTimeoutSecs" -ErrorAction Stop
    if ($machineInactivityLimit.InactivityTimeoutSecs -le 900 -and $machineInactivityLimit.InactivityTimeoutSecs -gt 0) {
        Add-Result "2.3.7.4" "Pass" "Interactive logon: Machine inactivity limit is set correctly." "Ensure 'Interactive logon: Machine inactivity limit' is set to '900 or fewer second(s), but not 0'" "Interactive logon" "Medium" "Medium" "Limit the time a machine can remain inactive." "Review and ensure the limit is set correctly."
    } elseif ($machineInactivityLimit -eq $null) {
        Add-Result "2.3.7.4" "Null" "Interactive logon: Machine inactivity limit setting is missing." "Ensure 'Interactive logon: Machine inactivity limit' is set to '900 or fewer second(s), but not 0'" "Interactive logon" "Medium" "Medium" "Limit the time a machine can remain inactive." "Review and ensure the limit is set correctly."
    } else {
        Add-Result "2.3.7.4" "Fail" "Interactive logon: Machine inactivity limit is not set correctly." "Ensure 'Interactive logon: Machine inactivity limit' is set to '900 or fewer second(s), but not 0'" "Interactive logon" "Medium" "Medium" "Limit the time a machine can remain inactive." "Review and ensure the limit is set correctly."
    }
} catch {
    Add-Result "2.3.7.4" "Error" "Could not check 'Interactive logon: Machine inactivity limit'. Error: $($_.Exception.Message)" "Ensure 'Interactive logon: Machine inactivity limit' is set to '900 or fewer second(s), but not 0'" "Interactive logon" "Medium" "Medium" "Limit the time a machine can remain inactive." "Review and ensure the limit is set correctly."
}

try {
    # Configure 'Interactive logon: Message text for users attempting to log on'
    $logonMessageText = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "LegalNoticeText" -ErrorAction Stop
    if ($logonMessageText.LegalNoticeText -ne "") {
        Add-Result "2.3.7.5" "Pass" "Interactive logon: Message text for users attempting to log on is configured." "Configure 'Interactive logon: Message text for users attempting to log on'" "Interactive logon" "Low" "Low" "Display a message for users attempting to log on." "Review and ensure the message text is configured."
    } elseif ($logonMessageText -eq $null) {
        Add-Result "2.3.7.5" "Null" "Interactive logon: Message text for users attempting to log on setting is missing." "Configure 'Interactive logon: Message text for users attempting to log on'" "Interactive logon" "Low" "Low" "Display a message for users attempting to log on." "Review and ensure the message text is configured."
    } else {
        Add-Result "2.3.7.5" "Fail" "Interactive logon: Message text for users attempting to log on is not configured." "Configure 'Interactive logon: Message text for users attempting to log on'" "Interactive logon" "Low" "Low" "Display a message for users attempting to log on." "Review and ensure the message text is configured."
    }
} catch {
    Add-Result "2.3.7.5" "Error" "Could not check 'Interactive logon: Message text for users attempting to log on'. Error: $($_.Exception.Message)" "Configure 'Interactive logon: Message text for users attempting to log on'" "Interactive logon" "Low" "Low" "Display a message for users attempting to log on." "Review and ensure the message text is configured."
}

try {
    # Configure 'Interactive logon: Message title for users attempting to log on'
    $logonMessageTitle = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "LegalNoticeCaption" -ErrorAction Stop
    if ($logonMessageTitle.LegalNoticeCaption -ne "") {
        Add-Result "2.3.7.6" "Pass" "Interactive logon: Message title for users attempting to log on is configured." "Configure 'Interactive logon: Message title for users attempting to log on'" "Interactive logon" "Low" "Low" "Display a title for the message shown during logon." "Review and ensure the message title is configured."
    } elseif ($logonMessageTitle -eq $null) {
        Add-Result "2.3.7.6" "Null" "Interactive logon: Message title for users attempting to log on setting is missing." "Configure 'Interactive logon: Message title for users attempting to log on'" "Interactive logon" "Low" "Low" "Display a title for the message shown during logon." "Review and ensure the message title is configured."
    } else {
        Add-Result "2.3.7.6" "Fail" "Interactive logon: Message title for users attempting to log on is not configured." "Configure 'Interactive logon: Message title for users attempting to log on'" "Interactive logon" "Low" "Low" "Display a title for the message shown during logon." "Review and ensure the message title is configured."
    }
} catch {
    Add-Result "2.3.7.6" "Error" "Could not check 'Interactive logon: Message title for users attempting to log on'. Error: $($_.Exception.Message)" "Configure 'Interactive logon: Message title for users attempting to log on'" "Interactive logon" "Low" "Low" "Display a title for the message shown during logon." "Review and ensure the message title is configured."
}

try {
    # Ensure 'Interactive logon: Prompt user to change password before expiration' is set to 'between 5 and 14 days'
    $promptChangePassword = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "PromptPasswordExpiryDays" -ErrorAction Stop
    if ($promptChangePassword.PromptPasswordExpiryDays -ge 5 -and $promptChangePassword.PromptPasswordExpiryDays -le 14) {
        Add-Result "2.3.7.7" "Pass" "Interactive logon: Prompt user to change password before expiration is set correctly." "Ensure 'Interactive logon: Prompt user to change password before expiration' is set to 'between 5 and 14 days'" "Interactive logon" "Medium" "Medium" "Prompt users to change their password before expiration." "Review and ensure the setting is between 5 and 14 days."
    } elseif ($promptChangePassword -eq $null) {
        Add-Result "2.3.7.7" "Null" "Interactive logon: Prompt user to change password before expiration setting is missing." "Ensure 'Interactive logon: Prompt user to change password before expiration' is set to 'between 5 and 14 days'" "Interactive logon" "Medium" "Medium" "Prompt users to change their password before expiration." "Review and ensure the setting is between 5 and 14 days."
    } else {
        Add-Result "2.3.7.7" "Fail" "Interactive logon: Prompt user to change password before expiration is not set correctly." "Ensure 'Interactive logon: Prompt user to change password before expiration' is set to 'between 5 and 14 days'" "Interactive logon" "Medium" "Medium" "Prompt users to change their password before expiration." "Review and ensure the setting is between 5 and 14 days."
    }
} catch {
    Add-Result "2.3.7.7" "Error" "Could not check 'Interactive logon: Prompt user to change password before expiration'. Error: $($_.Exception.Message)" "Ensure 'Interactive logon: Prompt user to change password before expiration' is set to 'between 5 and 14 days'" "Interactive logon" "Medium" "Medium" "Prompt users to change their password before expiration." "Review and ensure the setting is between 5 and 14 days."
}

try {
    # Ensure 'Interactive logon: Smart card removal behavior' is set to 'Lock Workstation' or higher
    $smartCardRemoval = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "ScRemoveOption" -ErrorAction Stop
    if ($smartCardRemoval.ScRemoveOption -ge 1) {
        Add-Result "2.3.7.8" "Pass" "Interactive logon: Smart card removal behavior is set to 'Lock Workstation' or higher." "Ensure 'Interactive logon: Smart card removal behavior' is set to 'Lock Workstation' or higher" "Interactive logon" "High" "High" "Specify the action to take on smart card removal." "Review and ensure the setting is set to 'Lock Workstation' or higher."
    } elseif ($smartCardRemoval -eq $null) {
        Add-Result "2.3.7.8" "Null" "Interactive logon: Smart card removal behavior setting is missing." "Ensure 'Interactive logon: Smart card removal behavior' is set to 'Lock Workstation' or higher" "Interactive logon" "High" "High" "Specify the action to take on smart card removal." "Review and ensure the setting is set to 'Lock Workstation' or higher."
    } else {
        Add-Result "2.3.7.8" "Fail" "Interactive logon: Smart card removal behavior is not set to 'Lock Workstation' or higher." "Ensure 'Interactive logon: Smart card removal behavior' is set to 'Lock Workstation' or higher" "Interactive logon" "High" "High" "Specify the action to take on smart card removal." "Review and ensure the setting is set to 'Lock Workstation' or higher."
    }
} catch {
    Add-Result "2.3.7.8" "Error" "Could not check 'Interactive logon: Smart card removal behavior'. Error: $($_.Exception.Message)" "Ensure 'Interactive logon: Smart card removal behavior' is set to 'Lock Workstation' or higher" "Interactive logon" "High" "High" "Specify the action to take on smart card removal." "Review and ensure the setting is set to 'Lock Workstation' or higher."
}

try {
    # Ensure 'Microsoft network client: Digitally sign communications (always)' is set to 'Enabled'
    $networkClientSignAlways = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation\Parameters" -Name "RequireSecuritySignature" -ErrorAction Stop
    if ($networkClientSignAlways.RequireSecuritySignature -eq 1) {
        Add-Result "2.3.8.1" "Pass" "Microsoft network client: Digitally sign communications (always) is set to 'Enabled'." "Ensure 'Microsoft network client: Digitally sign communications (always)' is set to 'Enabled'" "Microsoft network client" "High" "High" "Ensure communications are digitally signed." "Review and ensure the policy is set to 'Enabled'."
    } elseif ($networkClientSignAlways -eq $null) {
        Add-Result "2.3.8.1" "Null" "Microsoft network client: Digitally sign communications (always) setting is missing." "Ensure 'Microsoft network client: Digitally sign communications (always)' is set to 'Enabled'" "Microsoft network client" "High" "High" "Ensure communications are digitally signed." "Review and ensure the policy is set to 'Enabled'."
    } else {
        Add-Result "2.3.8.1" "Fail" "Microsoft network client: Digitally sign communications (always) is not set to 'Enabled'." "Ensure 'Microsoft network client: Digitally sign communications (always)' is set to 'Enabled'" "Microsoft network client" "High" "High" "Ensure communications are digitally signed." "Review and ensure the policy is set to 'Enabled'."
    }
} catch {
    Add-Result "2.3.8.1" "Error" "Could not check 'Microsoft network client: Digitally sign communications (always)'. Error: $($_.Exception.Message)" "Ensure 'Microsoft network client: Digitally sign communications (always)' is set to 'Enabled'" "Microsoft network client" "High" "High" "Ensure communications are digitally signed." "Review and ensure the policy is set to 'Enabled'."
}

try {
    # Ensure 'Microsoft network client: Digitally sign communications (if server agrees)' is set to 'Enabled'
    $networkClientSignIfServerAgrees = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation\Parameters" -Name "EnableSecuritySignature" -ErrorAction Stop
    if ($networkClientSignIfServerAgrees.EnableSecuritySignature -eq 1) {
        Add-Result "2.3.8.2" "Pass" "Microsoft network client: Digitally sign communications (if server agrees) is set to 'Enabled'." "Ensure 'Microsoft network client: Digitally sign communications (if server agrees)' is set to 'Enabled'" "Microsoft network client" "Medium" "Medium" "Ensure communications are digitally signed if the server agrees." "Review and ensure the policy is set to 'Enabled'."
    } elseif ($networkClientSignIfServerAgrees -eq $null) {
        Add-Result "2.3.8.2" "Null" "Microsoft network client: Digitally sign communications (if server agrees) setting is missing." "Ensure 'Microsoft network client: Digitally sign communications (if server agrees)' is set to 'Enabled'" "Microsoft network client" "Medium" "Medium" "Ensure communications are digitally signed if the server agrees." "Review and ensure the policy is set to 'Enabled'."
    } else {
        Add-Result "2.3.8.2" "Fail" "Microsoft network client: Digitally sign communications (if server agrees) is not set to 'Enabled'." "Ensure 'Microsoft network client: Digitally sign communications (if server agrees)' is set to 'Enabled'" "Microsoft network client" "Medium" "Medium" "Ensure communications are digitally signed if the server agrees." "Review and ensure the policy is set to 'Enabled'."
    }
} catch {
    Add-Result "2.3.8.2" "Error" "Could not check 'Microsoft network client: Digitally sign communications (if server agrees)'. Error: $($_.Exception.Message)" "Ensure 'Microsoft network client: Digitally sign communications (if server agrees)' is set to 'Enabled'" "Microsoft network client" "Medium" "Medium" "Ensure communications are digitally signed if the server agrees." "Review and ensure the policy is set to 'Enabled'."
}

try {
    # Ensure 'Microsoft network client: Send unencrypted password to third-party SMB servers' is set to 'Disabled'
    $sendUnencryptedPassword = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation\Parameters" -Name "EnablePlainTextPassword" -ErrorAction Stop
    if ($sendUnencryptedPassword.EnablePlainTextPassword -eq 0) {
        Add-Result "2.3.8.3" "Pass" "Microsoft network client: Send unencrypted password to third-party SMB servers is set to 'Disabled'." "Ensure 'Microsoft network client: Send unencrypted password to third-party SMB servers' is set to 'Disabled'" "Microsoft network client" "High" "High" "Protect passwords by disallowing plaintext passwords." "Review and ensure the policy is set to 'Disabled'."
    } elseif ($sendUnencryptedPassword -eq $null) {
        Add-Result "2.3.8.3" "Null" "Microsoft network client: Send unencrypted password to third-party SMB servers setting is missing." "Ensure 'Microsoft network client: Send unencrypted password to third-party SMB servers' is set to 'Disabled'" "Microsoft network client" "High" "High" "Protect passwords by disallowing plaintext passwords." "Review and ensure the policy is set to 'Disabled'."
    } else {
        Add-Result "2.3.8.3" "Fail" "Microsoft network client: Send unencrypted password to third-party SMB servers is not set to 'Disabled'." "Ensure 'Microsoft network client: Send unencrypted password to third-party SMB servers' is set to 'Disabled'" "Microsoft network client" "High" "High" "Protect passwords by disallowing plaintext passwords." "Review and ensure the policy is set to 'Disabled'."
    }
} catch {
    Add-Result "2.3.8.3" "Error" "Could not check 'Microsoft network client: Send unencrypted password to third-party SMB servers'. Error: $($_.Exception.Message)" "Ensure 'Microsoft network client: Send unencrypted password to third-party SMB servers' is set to 'Disabled'" "Microsoft network client" "High" "High" "Protect passwords by disallowing plaintext passwords." "Review and ensure the policy is set to 'Disabled'."
}

try {
    # Ensure 'Microsoft network server: Amount of idle time required before suspending session' is set to '15 or fewer minute(s)'
    $idleTime = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" -Name "AutoDisconnect" -ErrorAction Stop
    if ($idleTime.AutoDisconnect -le 15) {
        Add-Result "2.3.9.1" "Pass" "Microsoft network server: Amount of idle time required before suspending session is set to '15 or fewer minute(s)'." "Ensure 'Microsoft network server: Amount of idle time required before suspending session' is set to '15 or fewer minute(s)'" "Microsoft network server" "Medium" "Medium" "Reduce idle session duration to improve security." "Review and ensure the policy is set to '15 or fewer minute(s)'."
    } elseif ($idleTime -eq $null) {
        Add-Result "2.3.9.1" "Null" "Microsoft network server: Amount of idle time required before suspending session setting is missing." "Ensure 'Microsoft network server: Amount of idle time required before suspending session' is set to '15 or fewer minute(s)'" "Microsoft network server" "Medium" "Medium" "Reduce idle session duration to improve security." "Review and ensure the policy is set to '15 or fewer minute(s)'."
    } else {
        Add-Result "2.3.9.1" "Fail" "Microsoft network server: Amount of idle time required before suspending session is not set to '15 or fewer minute(s)'." "Ensure 'Microsoft network server: Amount of idle time required before suspending session' is set to '15 or fewer minute(s)'" "Microsoft network server" "Medium" "Medium" "Reduce idle session duration to improve security." "Review and ensure the policy is set to '15 or fewer minute(s)'."
    }
} catch {
    Add-Result "2.3.9.1" "Error" "Could not check 'Microsoft network server: Amount of idle time required before suspending session'. Error: $($_.Exception.Message)" "Ensure 'Microsoft network server: Amount of idle time required before suspending session' is set to '15 or fewer minute(s)'" "Microsoft network server" "Medium" "Medium" "Reduce idle session duration to improve security." "Review and ensure the policy is set to '15 or fewer minute(s)'."
}

try {
    # Ensure 'Microsoft network server: Digitally sign communications (always)' is set to 'Enabled'
    $serverSignAlways = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" -Name "RequireSecuritySignature" -ErrorAction Stop
    if ($serverSignAlways.RequireSecuritySignature -eq 1) {
        Add-Result "2.3.9.2" "Pass" "Microsoft network server: Digitally sign communications (always) is set to 'Enabled'." "Ensure 'Microsoft network server: Digitally sign communications (always)' is set to 'Enabled'" "Microsoft network server" "High" "High" "Ensure communications are digitally signed." "Review and ensure the policy is set to 'Enabled'."
    } elseif ($serverSignAlways -eq $null) {
        Add-Result "2.3.9.2" "Null" "Microsoft network server: Digitally sign communications (always) setting is missing." "Ensure 'Microsoft network server: Digitally sign communications (always)' is set to 'Enabled'" "Microsoft network server" "High" "High" "Ensure communications are digitally signed." "Review and ensure the policy is set to 'Enabled'."
    } else {
        Add-Result "2.3.9.2" "Fail" "Microsoft network server: Digitally sign communications (always) is not set to 'Enabled'." "Ensure 'Microsoft network server: Digitally sign communications (always)' is set to 'Enabled'" "Microsoft network server" "High" "High" "Ensure communications are digitally signed." "Review and ensure the policy is set to 'Enabled'."
    }
} catch {
    Add-Result "2.3.9.2" "Error" "Could not check 'Microsoft network server: Digitally sign communications (always)'. Error: $($_.Exception.Message)" "Ensure 'Microsoft network server: Digitally sign communications (always)' is set to 'Enabled'" "Microsoft network server" "High" "High" "Ensure communications are digitally signed." "Review and ensure the policy is set to 'Enabled'."
}

try {
    # Ensure 'Microsoft network server: Digitally sign communications (if client agrees)' is set to 'Enabled'
    $serverSignIfClientAgrees = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" -Name "EnableSecuritySignature" -ErrorAction Stop
    if ($serverSignIfClientAgrees.EnableSecuritySignature -eq 1) {
        Add-Result "2.3.9.3" "Pass" "Microsoft network server: Digitally sign communications (if client agrees) is set to 'Enabled'." "Ensure 'Microsoft network server: Digitally sign communications (if client agrees)' is set to 'Enabled'" "Microsoft network server" "Medium" "Medium" "Ensure communications are digitally signed if the client agrees." "Review and ensure the policy is set to 'Enabled'."
    } elseif ($serverSignIfClientAgrees -eq $null) {
        Add-Result "2.3.9.3" "Null" "Microsoft network server: Digitally sign communications (if client agrees) setting is missing." "Ensure 'Microsoft network server: Digitally sign communications (if client agrees)' is set to 'Enabled'" "Microsoft network server" "Medium" "Medium" "Ensure communications are digitally signed if the client agrees." "Review and ensure the policy is set to 'Enabled'."
    } else {
        Add-Result "2.3.9.3" "Fail" "Microsoft network server: Digitally sign communications (if client agrees) is not set to 'Enabled'." "Ensure 'Microsoft network server: Digitally sign communications (if client agrees)' is set to 'Enabled'" "Microsoft network server" "Medium" "Medium" "Ensure communications are digitally signed if the client agrees." "Review and ensure the policy is set to 'Enabled'."
    }
} catch {
    Add-Result "2.3.9.3" "Error" "Could not check 'Microsoft network server: Digitally sign communications (if client agrees)'. Error: $($_.Exception.Message)" "Ensure 'Microsoft network server: Digitally sign communications (if client agrees)' is set to 'Enabled'" "Microsoft network server" "Medium" "Medium" "Ensure communications are digitally signed if the client agrees." "Review and ensure the policy is set to 'Enabled'."
}

try {
    # Ensure 'Microsoft network server: Disconnect clients when logon hours expire' is set to 'Enabled'
    $disconnectClients = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" -Name "EnableForcedLogOff" -ErrorAction Stop
    if ($disconnectClients.EnableForcedLogOff -eq 1) {
        Add-Result "2.3.9.4" "Pass" "Microsoft network server: Disconnect clients when logon hours expire is set to 'Enabled'." "Ensure 'Microsoft network server: Disconnect clients when logon hours expire' is set to 'Enabled'" "Microsoft network server" "Medium" "Medium" "Ensure clients are disconnected when logon hours expire." "Review and ensure the policy is set to 'Enabled'."
    } elseif ($disconnectClients -eq $null) {
        Add-Result "2.3.9.4" "Null" "Microsoft network server: Disconnect clients when logon hours expire setting is missing." "Ensure 'Microsoft network server: Disconnect clients when logon hours expire' is set to 'Enabled'" "Microsoft network server" "Medium" "Medium" "Ensure clients are disconnected when logon hours expire." "Review and ensure the policy is set to 'Enabled'."
    } else {
        Add-Result "2.3.9.4" "Fail" "Microsoft network server: Disconnect clients when logon hours expire is not set to 'Enabled'." "Ensure 'Microsoft network server: Disconnect clients when logon hours expire' is set to 'Enabled'" "Microsoft network server" "Medium" "Medium" "Ensure clients are disconnected when logon hours expire." "Review and ensure the policy is set to 'Enabled'."
    }
} catch {
    Add-Result "2.3.9.4" "Error" "Could not check 'Microsoft network server: Disconnect clients when logon hours expire'. Error: $($_.Exception.Message)" "Ensure 'Microsoft network server: Disconnect clients when logon hours expire' is set to 'Enabled'" "Microsoft network server" "Medium" "Medium" "Ensure clients are disconnected when logon hours expire." "Review and ensure the policy is set to 'Enabled'."
}

try {
    # Ensure 'Microsoft network server: Server SPN target name validation level' is set to 'Accept if provided by client' or higher
    $spnTargetValidation = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" -Name "SmbServerNameHardeningLevel" -ErrorAction Stop
    if ($spnTargetValidation.SmbServerNameHardeningLevel -ge 1) {
        Add-Result "2.3.9.5" "Pass" "Microsoft network server: Server SPN target name validation level is set to 'Accept if provided by client' or higher." "Ensure 'Microsoft network server: Server SPN target name validation level' is set to 'Accept if provided by client' or higher" "Microsoft network server" "High" "High" "Ensure secure SPN validation." "Review and ensure the policy is set to 'Accept if provided by client' or higher."
    } elseif ($spnTargetValidation -eq $null) {
        Add-Result "2.3.9.5" "Null" "Microsoft network server: Server SPN target name validation level setting is missing." "Ensure 'Microsoft network server: Server SPN target name validation level' is set to 'Accept if provided by client' or higher" "Microsoft network server" "High" "High" "Ensure secure SPN validation." "Review and ensure the policy is set to 'Accept if provided by client' or higher."
    } else {
        Add-Result "2.3.9.5" "Fail" "Microsoft network server: Server SPN target name validation level is not set to 'Accept if provided by client' or higher." "Ensure 'Microsoft network server: Server SPN target name validation level' is set to 'Accept if provided by client' or higher" "Microsoft network server" "High" "High" "Ensure secure SPN validation." "Review and ensure the policy is set to 'Accept if provided by client' or higher."
    }
} catch {
    Add-Result "2.3.9.5" "Error" "Could not check 'Microsoft network server: Server SPN target name validation level'. Error: $($_.Exception.Message)" "Ensure 'Microsoft network server: Server SPN target name validation level' is set to 'Accept if provided by client' or higher" "Microsoft network server" "High" "High" "Ensure secure SPN validation." "Review and ensure the policy is set to 'Accept if provided by client' or higher."
}

try {
    # Ensure 'Network access: Allow anonymous SID/Name translation' is set to 'Disabled'
    $allowAnonymousSIDNameTranslation = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "AllowAnonymousSIDNameTranslation" -ErrorAction Stop
    if ($allowAnonymousSIDNameTranslation.AllowAnonymousSIDNameTranslation -eq 0) {
        Add-Result "2.3.10.1" "Pass" "Network access: Allow anonymous SID/Name translation is set to 'Disabled'." "Ensure 'Network access: Allow anonymous SID/Name translation' is set to 'Disabled'" "Network access" "High" "High" "Prevent anonymous translation of SIDs to names." "Review and ensure the policy is set to 'Disabled'."
    } elseif ($allowAnonymousSIDNameTranslation -eq $null) {
        Add-Result "2.3.10.1" "Null" "Network access: Allow anonymous SID/Name translation setting is missing." "Ensure 'Network access: Allow anonymous SID/Name translation' is set to 'Disabled'" "Network access" "High" "High" "Prevent anonymous translation of SIDs to names." "Review and ensure the policy is set to 'Disabled'."
    } else {
        Add-Result "2.3.10.1" "Fail" "Network access: Allow anonymous SID/Name translation is not set to 'Disabled'." "Ensure 'Network access: Allow anonymous SID/Name translation' is set to 'Disabled'" "Network access" "High" "High" "Prevent anonymous translation of SIDs to names." "Review and ensure the policy is set to 'Disabled'."
    }
} catch {
    Add-Result "2.3.10.1" "Error" "Could not check 'Network access: Allow anonymous SID/Name translation'. Error: $($_.Exception.Message)" "Ensure 'Network access: Allow anonymous SID/Name translation' is set to 'Disabled'" "Network access" "High" "High" "Prevent anonymous translation of SIDs to names." "Review and ensure the policy is set to 'Disabled'."
}

try {
    # Ensure 'Network access: Do not allow anonymous enumeration of SAM accounts' is set to 'Enabled'
    $doNotAllowAnonymousSAMAccounts = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "RestrictAnonymousSAM" -ErrorAction Stop
    if ($doNotAllowAnonymousSAMAccounts.RestrictAnonymousSAM -eq 1) {
        Add-Result "2.3.10.2" "Pass" "Network access: Do not allow anonymous enumeration of SAM accounts is set to 'Enabled'." "Ensure 'Network access: Do not allow anonymous enumeration of SAM accounts' is set to 'Enabled'" "Network access" "High" "High" "Prevent anonymous enumeration of SAM accounts." "Review and ensure the policy is set to 'Enabled'."
    } elseif ($doNotAllowAnonymousSAMAccounts -eq $null) {
        Add-Result "2.3.10.2" "Null" "Network access: Do not allow anonymous enumeration of SAM accounts setting is missing." "Ensure 'Network access: Do not allow anonymous enumeration of SAM accounts' is set to 'Enabled'" "Network access" "High" "High" "Prevent anonymous enumeration of SAM accounts." "Review and ensure the policy is set to 'Enabled'."
    } else {
        Add-Result "2.3.10.2" "Fail" "Network access: Do not allow anonymous enumeration of SAM accounts is not set to 'Enabled'." "Ensure 'Network access: Do not allow anonymous enumeration of SAM accounts' is set to 'Enabled'" "Network access" "High" "High" "Prevent anonymous enumeration of SAM accounts." "Review and ensure the policy is set to 'Enabled'."
    }
} catch {
    Add-Result "2.3.10.2" "Error" "Could not check 'Network access: Do not allow anonymous enumeration of SAM accounts'. Error: $($_.Exception.Message)" "Ensure 'Network access: Do not allow anonymous enumeration of SAM accounts' is set to 'Enabled'" "Network access" "High" "High" "Prevent anonymous enumeration of SAM accounts." "Review and ensure the policy is set to 'Enabled'."
}

try {
    # Ensure 'Network access: Do not allow anonymous enumeration of SAM accounts and shares' is set to 'Enabled'
    $doNotAllowAnonymousSAMAccountsShares = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "RestrictAnonymous" -ErrorAction Stop
    if ($doNotAllowAnonymousSAMAccountsShares.RestrictAnonymous -eq 1) {
        Add-Result "2.3.10.3" "Pass" "Network access: Do not allow anonymous enumeration of SAM accounts and shares is set to 'Enabled'." "Ensure 'Network access: Do not allow anonymous enumeration of SAM accounts and shares' is set to 'Enabled'" "Network access" "High" "High" "Prevent anonymous enumeration of SAM accounts and shares." "Review and ensure the policy is set to 'Enabled'."
    } elseif ($doNotAllowAnonymousSAMAccountsShares -eq $null) {
        Add-Result "2.3.10.3" "Null" "Network access: Do not allow anonymous enumeration of SAM accounts and shares setting is missing." "Ensure 'Network access: Do not allow anonymous enumeration of SAM accounts and shares' is set to 'Enabled'" "Network access" "High" "High" "Prevent anonymous enumeration of SAM accounts and shares." "Review and ensure the policy is set to 'Enabled'."
    } else {
        Add-Result "2.3.10.3" "Fail" "Network access: Do not allow anonymous enumeration of SAM accounts and shares is not set to 'Enabled'." "Ensure 'Network access: Do not allow anonymous enumeration of SAM accounts and shares' is set to 'Enabled'" "Network access" "High" "High" "Prevent anonymous enumeration of SAM accounts and shares." "Review and ensure the policy is set to 'Enabled'."
    }
} catch {
    Add-Result "2.3.10.3" "Error" "Could not check 'Network access: Do not allow anonymous enumeration of SAM accounts and shares'. Error: $($_.Exception.Message)" "Ensure 'Network access: Do not allow anonymous enumeration of SAM accounts and shares' is set to 'Enabled'" "Network access" "High" "High" "Prevent anonymous enumeration of SAM accounts and shares." "Review and ensure the policy is set to 'Enabled'."
}

try {
    # Ensure 'Network access: Do not allow storage of passwords and credentials for network authentication' is set to 'Enabled'
    $doNotAllowCredentialStorage = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "DisableDomainCreds" -ErrorAction Stop
    if ($doNotAllowCredentialStorage.DisableDomainCreds -eq 1) {
        Add-Result "2.3.10.4" "Pass" "Network access: Do not allow storage of passwords and credentials for network authentication is set to 'Enabled'." "Ensure 'Network access: Do not allow storage of passwords and credentials for network authentication' is set to 'Enabled'" "Network access" "High" "High" "Prevent storage of network credentials locally." "Review and ensure the policy is set to 'Enabled'."
    } elseif ($doNotAllowCredentialStorage -eq $null) {
        Add-Result "2.3.10.4" "Null" "Network access: Do not allow storage of passwords and credentials for network authentication setting is missing." "Ensure 'Network access: Do not allow storage of passwords and credentials for network authentication' is set to 'Enabled'" "Network access" "High" "High" "Prevent storage of network credentials locally." "Review and ensure the policy is set to 'Enabled'."
    } else {
        Add-Result "2.3.10.4" "Fail" "Network access: Do not allow storage of passwords and credentials for network authentication is not set to 'Enabled'." "Ensure 'Network access: Do not allow storage of passwords and credentials for network authentication' is set to 'Enabled'" "Network access" "High" "High" "Prevent storage of network credentials locally." "Review and ensure the policy is set to 'Enabled'."
    }
} catch {
    Add-Result "2.3.10.4" "Error" "Could not check 'Network access: Do not allow storage of passwords and credentials for network authentication'. Error: $($_.Exception.Message)" "Ensure 'Network access: Do not allow storage of passwords and credentials for network authentication' is set to 'Enabled'" "Network access" "High" "High" "Prevent storage of network credentials locally." "Review and ensure the policy is set to 'Enabled'."
}

try {
    # Ensure 'Network access: Let Everyone permissions apply to anonymous users' is set to 'Disabled'
    $everyonePermissionsAnonymous = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "EveryoneIncludesAnonymous" -ErrorAction Stop
    if ($everyonePermissionsAnonymous.EveryoneIncludesAnonymous -eq 0) {
        Add-Result "2.3.10.5" "Pass" "Network access: Let Everyone permissions apply to anonymous users is set to 'Disabled'." "Ensure 'Network access: Let Everyone permissions apply to anonymous users' is set to 'Disabled'" "Network access" "Medium" "Medium" "Restrict permissions for anonymous users." "Review and ensure the policy is set to 'Disabled'."
    } elseif ($everyonePermissionsAnonymous -eq $null) {
        Add-Result "2.3.10.5" "Null" "Network access: Let Everyone permissions apply to anonymous users setting is missing." "Ensure 'Network access: Let Everyone permissions apply to anonymous users' is set to 'Disabled'" "Network access" "Medium" "Medium" "Restrict permissions for anonymous users." "Review and ensure the policy is set to 'Disabled'."
    } else {
        Add-Result "2.3.10.5" "Fail" "Network access: Let Everyone permissions apply to anonymous users is not set to 'Disabled'." "Ensure 'Network access: Let Everyone permissions apply to anonymous users' is set to 'Disabled'" "Network access" "Medium" "Medium" "Restrict permissions for anonymous users." "Review and ensure the policy is set to 'Disabled'."
    }
} catch {
    Add-Result "2.3.10.5" "Error" "Could not check 'Network access: Let Everyone permissions apply to anonymous users'. Error: $($_.Exception.Message)" "Ensure 'Network access: Let Everyone permissions apply to anonymous users' is set to 'Disabled'" "Network access" "Medium" "Medium" "Restrict permissions for anonymous users." "Review and ensure the policy is set to 'Disabled'."
}

try {
    # Ensure 'Network access: Named Pipes that can be accessed anonymously' is set to 'None'
    $namedPipesAnonymous = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" -Name "NullSessionPipes" -ErrorAction Stop
    if ($namedPipesAnonymous.NullSessionPipes -eq "") {
        Add-Result "2.3.10.6" "Pass" "Network access: Named Pipes that can be accessed anonymously is set to 'None'." "Ensure 'Network access: Named Pipes that can be accessed anonymously' is set to 'None'" "Network access" "High" "High" "Restrict access to named pipes anonymously." "Review and ensure the policy is set to 'None'."
    } elseif ($namedPipesAnonymous -eq $null) {
        Add-Result "2.3.10.6" "Null" "Network access: Named Pipes that can be accessed anonymously setting is missing." "Ensure 'Network access: Named Pipes that can be accessed anonymously' is set to 'None'" "Network access" "High" "High" "Restrict access to named pipes anonymously." "Review and ensure the policy is set to 'None'."
    } else {
        Add-Result "2.3.10.6" "Fail" "Network access: Named Pipes that can be accessed anonymously is not set to 'None'." "Ensure 'Network access: Named Pipes that can be accessed anonymously' is set to 'None'" "Network access" "High" "High" "Restrict access to named pipes anonymously." "Review and ensure the policy is set to 'None'."
    }
} catch {
    Add-Result "2.3.10.6" "Error" "Could not check 'Network access: Named Pipes that can be accessed anonymously'. Error: $($_.Exception.Message)" "Ensure 'Network access: Named Pipes that can be accessed anonymously' is set to 'None'" "Network access" "High" "High" "Restrict access to named pipes anonymously." "Review and ensure the policy is set to 'None'."
}

try {
    # Ensure 'Network access: Remotely accessible registry paths' is configured
    $registryPaths = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\SecurePipeServers\winreg" -Name "AllowedPaths" -ErrorAction Stop
    if ($registryPaths.AllowedPaths -ne $null) {
        Add-Result "2.3.10.7" "Pass" "Network access: Remotely accessible registry paths is configured." "Ensure 'Network access: Remotely accessible registry paths' is configured" "Network access" "Medium" "Medium" "Secure remotely accessible registry paths." "Review and ensure the policy is configured."
    } else {
        Add-Result "2.3.10.7" "Fail" "Network access: Remotely accessible registry paths is not configured." "Ensure 'Network access: Remotely accessible registry paths' is configured" "Network access" "Medium" "Medium" "Secure remotely accessible registry paths." "Review and ensure the policy is configured."
    }
} catch {
    Add-Result "2.3.10.7" "Error" "Could not check 'Network access: Remotely accessible registry paths'. Error: $($_.Exception.Message)" "Ensure 'Network access: Remotely accessible registry paths' is configured" "Network access" "Medium" "Medium" "Secure remotely accessible registry paths." "Review and ensure the policy is configured."
}

try {
    # Ensure 'Network access: Remotely accessible registry paths and sub-paths' is configured
    $registrySubPaths = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\SecurePipeServers\winreg" -Name "AllowedPaths\Machine" -ErrorAction Stop
    if ($registrySubPaths.Machine -ne $null) {
        Add-Result "2.3.10.8" "Pass" "Network access: Remotely accessible registry paths and sub-paths is configured." "Ensure 'Network access: Remotely accessible registry paths and sub-paths' is configured" "Network access" "Medium" "Medium" "Secure remotely accessible registry paths and sub-paths." "Review and ensure the policy is configured."
    } else {
        Add-Result "2.3.10.8" "Fail" "Network access: Remotely accessible registry paths and sub-paths is not configured." "Ensure 'Network access: Remotely accessible registry paths and sub-paths' is configured" "Network access" "Medium" "Medium" "Secure remotely accessible registry paths and sub-paths." "Review and ensure the policy is configured."
    }
} catch {
    Add-Result "2.3.10.8" "Error" "Could not check 'Network access: Remotely accessible registry paths and sub-paths'. Error: $($_.Exception.Message)" "Ensure 'Network access: Remotely accessible registry paths and sub-paths' is configured" "Network access" "Medium" "Medium" "Secure remotely accessible registry paths and sub-paths." "Review and ensure the policy is configured."
}

try {
    # Ensure 'Network access: Restrict clients allowed to make remote calls to SAM' is set to 'Administrators: Remote Access: Allow'
    $restrictRemoteCallsToSAM = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "RestrictRemoteSAM" -ErrorAction Stop
    if ($restrictRemoteCallsToSAM.RestrictRemoteSAM -eq "Administrators: Remote Access: Allow") {
        Add-Result "2.3.10.10" "Pass" "Network access: Restrict clients allowed to make remote calls to SAM is set correctly." "Ensure 'Network access: Restrict clients allowed to make remote calls to SAM' is set to 'Administrators: Remote Access: Allow'" "Network access" "High" "High" "Restrict remote SAM calls to administrators." "Review and ensure the policy is set to 'Administrators: Remote Access: Allow'."
    } elseif ($restrictRemoteCallsToSAM -eq $null) {
        Add-Result "2.3.10.10" "Null" "Network access: Restrict clients allowed to make remote calls to SAM setting is missing." "Ensure 'Network access: Restrict clients allowed to make remote calls to SAM' is set to 'Administrators: Remote Access: Allow'" "Network access" "High" "High" "Restrict remote SAM calls to administrators." "Review and ensure the policy is set to 'Administrators: Remote Access: Allow'."
    } else {
        Add-Result "2.3.10.10" "Fail" "Network access: Restrict clients allowed to make remote calls to SAM is not set correctly." "Ensure 'Network access: Restrict clients allowed to make remote calls to SAM' is set to 'Administrators: Remote Access: Allow'" "Network access" "High" "High" "Restrict remote SAM calls to administrators." "Review and ensure the policy is set to 'Administrators: Remote Access: Allow'."
    }
} catch {
    Add-Result "2.3.10.10" "Error" "Could not check 'Network access: Restrict clients allowed to make remote calls to SAM'. Error: $($_.Exception.Message)" "Ensure 'Network access: Restrict clients allowed to make remote calls to SAM' is set to 'Administrators: Remote Access: Allow'" "Network access" "High" "High" "Restrict remote SAM calls to administrators." "Review and ensure the policy is set to 'Administrators: Remote Access: Allow'."
}

try {
    # Ensure 'Network access: Shares that can be accessed anonymously' is set to 'None'
    $anonymousShares = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" -Name "NullSessionShares" -ErrorAction Stop
    if ($anonymousShares.NullSessionShares -eq "") {
        Add-Result "2.3.10.11" "Pass" "Network access: Shares that can be accessed anonymously is set to 'None'." "Ensure 'Network access: Shares that can be accessed anonymously' is set to 'None'" "Network access" "High" "High" "Restrict anonymous access to shared resources." "Review and ensure the policy is set to 'None'."
    } elseif ($anonymousShares -eq $null) {
        Add-Result "2.3.10.11" "Null" "Network access: Shares that can be accessed anonymously setting is missing." "Ensure 'Network access: Shares that can be accessed anonymously' is set to 'None'" "Network access" "High" "High" "Restrict anonymous access to shared resources." "Review and ensure the policy is set to 'None'."
    } else {
        Add-Result "2.3.10.11" "Fail" "Network access: Shares that can be accessed anonymously is not set to 'None'." "Ensure 'Network access: Shares that can be accessed anonymously' is set to 'None'" "Network access" "High" "High" "Restrict anonymous access to shared resources." "Review and ensure the policy is set to 'None'."
    }
} catch {
    Add-Result "2.3.10.11" "Error" "Could not check 'Network access: Shares that can be accessed anonymously'. Error: $($_.Exception.Message)" "Ensure 'Network access: Shares that can be accessed anonymously' is set to 'None'" "Network access" "High" "High" "Restrict anonymous access to shared resources." "Review and ensure the policy is set to 'None'."
}

try {
    # Ensure 'Network access: Sharing and security model for local accounts' is set to 'Classic - local users authenticate as themselves'
    $localAccountSharingModel = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "ForceGuest" -ErrorAction Stop
    if ($localAccountSharingModel.ForceGuest -eq 0) {
        Add-Result "2.3.10.12" "Pass" "Network access: Sharing and security model for local accounts is set to 'Classic - local users authenticate as themselves'." "Ensure 'Network access: Sharing and security model for local accounts' is set to 'Classic - local users authenticate as themselves'" "Network access" "Medium" "Medium" "Secure sharing and security for local accounts." "Review and ensure the policy is set to 'Classic - local users authenticate as themselves'."
    } elseif ($localAccountSharingModel -eq $null) {
        Add-Result "2.3.10.12" "Null" "Network access: Sharing and security model for local accounts setting is missing." "Ensure 'Network access: Sharing and security model for local accounts' is set to 'Classic - local users authenticate as themselves'" "Network access" "Medium" "Medium" "Secure sharing and security for local accounts." "Review and ensure the policy is set to 'Classic - local users authenticate as themselves'."
    } else {
        Add-Result "2.3.10.12" "Fail" "Network access: Sharing and security model for local accounts is not set to 'Classic - local users authenticate as themselves'." "Ensure 'Network access: Sharing and security model for local accounts' is set to 'Classic - local users authenticate as themselves'" "Network access" "Medium" "Medium" "Secure sharing and security for local accounts." "Review and ensure the policy is set to 'Classic - local users authenticate as themselves'."
    }
} catch {
    Add-Result "2.3.10.12" "Error" "Could not check 'Network access: Sharing and security model for local accounts'. Error: $($_.Exception.Message)" "Ensure 'Network access: Sharing and security model for local accounts' is set to 'Classic - local users authenticate as themselves'" "Network access" "Medium" "Medium" "Secure sharing and security for local accounts." "Review and ensure the policy is set to 'Classic - local users authenticate as themselves'."
}

try {
    # Ensure 'Network security: Allow Local System to use computer identity for NTLM' is set to 'Enabled'
    $allowLocalSystemIdentity = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "UseMachineIdentity" -ErrorAction Stop
    if ($allowLocalSystemIdentity.UseMachineIdentity -eq 1) {
        Add-Result "2.3.11.1" "Pass" "Network security: Allow Local System to use computer identity for NTLM is set to 'Enabled'." "Ensure 'Network security: Allow Local System to use computer identity for NTLM' is set to 'Enabled'" "Network security" "Medium" "Medium" "Allow Local System to use the computer identity for NTLM." "Review and ensure the policy is set to 'Enabled'."
    } elseif ($allowLocalSystemIdentity -eq $null) {
        Add-Result "2.3.11.1" "Null" "Network security: Allow Local System to use computer identity for NTLM setting is missing." "Ensure 'Network security: Allow Local System to use computer identity for NTLM' is set to 'Enabled'" "Network security" "Medium" "Medium" "Allow Local System to use the computer identity for NTLM." "Review and ensure the policy is set to 'Enabled'."
    } else {
        Add-Result "2.3.11.1" "Fail" "Network security: Allow Local System to use computer identity for NTLM is not set to 'Enabled'." "Ensure 'Network security: Allow Local System to use computer identity for NTLM' is set to 'Enabled'" "Network security" "Medium" "Medium" "Allow Local System to use the computer identity for NTLM." "Review and ensure the policy is set to 'Enabled'."
    }
} catch {
    Add-Result "2.3.11.1" "Error" "Could not check 'Network security: Allow Local System to use computer identity for NTLM'. Error: $($_.Exception.Message)" "Ensure 'Network security: Allow Local System to use computer identity for NTLM' is set to 'Enabled'" "Network security" "Medium" "Medium" "Allow Local System to use the computer identity for NTLM." "Review and ensure the policy is set to 'Enabled'."
}

try {
    # Ensure 'Network security: Allow LocalSystem NULL session fallback' is set to 'Disabled'
    $allowNullSessionFallback = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "EnableLocalSystemNullSessionFallback" -ErrorAction Stop
    if ($allowNullSessionFallback.EnableLocalSystemNullSessionFallback -eq 0) {
        Add-Result "2.3.11.2" "Pass" "Network security: Allow LocalSystem NULL session fallback is set to 'Disabled'." "Ensure 'Network security: Allow LocalSystem NULL session fallback' is set to 'Disabled'" "Network security" "High" "High" "Disallow LocalSystem NULL session fallback." "Review and ensure the policy is set to 'Disabled'."
    } elseif ($allowNullSessionFallback -eq $null) {
        Add-Result "2.3.11.2" "Null" "Network security: Allow LocalSystem NULL session fallback setting is missing." "Ensure 'Network security: Allow LocalSystem NULL session fallback' is set to 'Disabled'" "Network security" "High" "High" "Disallow LocalSystem NULL session fallback." "Review and ensure the policy is set to 'Disabled'."
    } else {
        Add-Result "2.3.11.2" "Fail" "Network security: Allow LocalSystem NULL session fallback is not set to 'Disabled'." "Ensure 'Network security: Allow LocalSystem NULL session fallback' is set to 'Disabled'" "Network security" "High" "High" "Disallow LocalSystem NULL session fallback." "Review and ensure the policy is set to 'Disabled'."
    }
} catch {
    Add-Result "2.3.11.2" "Error" "Could not check 'Network security: Allow LocalSystem NULL session fallback'. Error: $($_.Exception.Message)" "Ensure 'Network security: Allow LocalSystem NULL session fallback' is set to 'Disabled'" "Network security" "High" "High" "Disallow LocalSystem NULL session fallback." "Review and ensure the policy is set to 'Disabled'."
}

try {
    # Ensure 'Network Security: Allow PKU2U authentication requests to this computer to use online identities' is set to 'Disabled'
    $allowPKU2UAuthentication = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\pku2u" -Name "AllowOnlineID" -ErrorAction Stop
    if ($allowPKU2UAuthentication.AllowOnlineID -eq 0) {
        Add-Result "2.3.11.3" "Pass" "Network Security: Allow PKU2U authentication requests to this computer to use online identities is set to 'Disabled'." "Ensure 'Network Security: Allow PKU2U authentication requests to this computer to use online identities' is set to 'Disabled'" "Network security" "High" "High" "Disallow PKU2U authentication requests with online identities." "Review and ensure the policy is set to 'Disabled'."
    } elseif ($allowPKU2UAuthentication -eq $null) {
        Add-Result "2.3.11.3" "Null" "Network Security: Allow PKU2U authentication requests to this computer to use online identities setting is missing." "Ensure 'Network Security: Allow PKU2U authentication requests to this computer to use online identities' is set to 'Disabled'" "Network security" "High" "High" "Disallow PKU2U authentication requests with online identities." "Review and ensure the policy is set to 'Disabled'."
    } else {
        Add-Result "2.3.11.3" "Fail" "Network Security: Allow PKU2U authentication requests to this computer to use online identities is not set to 'Disabled'." "Ensure 'Network Security: Allow PKU2U authentication requests to this computer to use online identities' is set to 'Disabled'" "Network security" "High" "High" "Disallow PKU2U authentication requests with online identities." "Review and ensure the policy is set to 'Disabled'."
    }
} catch {
    Add-Result "2.3.11.3" "Error" "Could not check 'Network Security: Allow PKU2U authentication requests to this computer to use online identities'. Error: $($_.Exception.Message)" "Ensure 'Network Security: Allow PKU2U authentication requests to this computer to use online identities' is set to 'Disabled'" "Network security" "High" "High" "Disallow PKU2U authentication requests with online identities." "Review and ensure the policy is set to 'Disabled'."
}

try {
    # Ensure 'Network security: Configure encryption types allowed for Kerberos' is set to 'AES128_HMAC_SHA1, AES256_HMAC_SHA1, Future encryption types'
    $kerberosEncryptionTypes = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\Kerberos\Parameters" -Name "SupportedEncryptionTypes" -ErrorAction Stop
    if ($kerberosEncryptionTypes.SupportedEncryptionTypes -eq 2147483640) {
        Add-Result "2.3.11.4" "Pass" "Network security: Configure encryption types allowed for Kerberos is set to 'AES128_HMAC_SHA1, AES256_HMAC_SHA1, Future encryption types'." "Ensure 'Network security: Configure encryption types allowed for Kerberos' is set to 'AES128_HMAC_SHA1, AES256_HMAC_SHA1, Future encryption types'" "Network security" "High" "High" "Ensure Kerberos encryption types are secure." "Review and ensure the policy is set correctly."
    } elseif ($kerberosEncryptionTypes -eq $null) {
        Add-Result "2.3.11.4" "Null" "Network security: Configure encryption types allowed for Kerberos setting is missing." "Ensure 'Network security: Configure encryption types allowed for Kerberos' is set to 'AES128_HMAC_SHA1, AES256_HMAC_SHA1, Future encryption types'" "Network security" "High" "High" "Ensure Kerberos encryption types are secure." "Review and ensure the policy is set correctly."
    } else {
        Add-Result "2.3.11.4" "Fail" "Network security: Configure encryption types allowed for Kerberos is not set correctly." "Ensure 'Network security: Configure encryption types allowed for Kerberos' is set to 'AES128_HMAC_SHA1, AES256_HMAC_SHA1, Future encryption types'" "Network security" "High" "High" "Ensure Kerberos encryption types are secure." "Review and ensure the policy is set correctly."
    }
} catch {
    Add-Result "2.3.11.4" "Error" "Could not check 'Network security: Configure encryption types allowed for Kerberos'. Error: $($_.Exception.Message)" "Ensure 'Network security: Configure encryption types allowed for Kerberos' is set to 'AES128_HMAC_SHA1, AES256_HMAC_SHA1, Future encryption types'" "Network security" "High" "High" "Ensure Kerberos encryption types are secure." "Review and ensure the policy is set correctly."
}

try {
    # Ensure 'Network security: Do not store LAN Manager hash value on next password change' is set to 'Enabled'
    $noLanManHash = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "NoLMHash" -ErrorAction Stop
    if ($noLanManHash.NoLMHash -eq 1) {
        Add-Result "2.3.11.5" "Pass" "Network security: Do not store LAN Manager hash value on next password change is set to 'Enabled'." "Ensure 'Network security: Do not store LAN Manager hash value on next password change' is set to 'Enabled'" "Network security" "High" "High" "Prevent LAN Manager hash storage for improved security." "Review and ensure the policy is set to 'Enabled'."
    } elseif ($noLanManHash -eq $null) {
        Add-Result "2.3.11.5" "Null" "Network security: Do not store LAN Manager hash value on next password change setting is missing." "Ensure 'Network security: Do not store LAN Manager hash value on next password change' is set to 'Enabled'" "Network security" "High" "High" "Prevent LAN Manager hash storage for improved security." "Review and ensure the policy is set to 'Enabled'."
    } else {
        Add-Result "2.3.11.5" "Fail" "Network security: Do not store LAN Manager hash value on next password change is not set to 'Enabled'." "Ensure 'Network security: Do not store LAN Manager hash value on next password change' is set to 'Enabled'" "Network security" "High" "High" "Prevent LAN Manager hash storage for improved security." "Review and ensure the policy is set to 'Enabled'."
    }
} catch {
    Add-Result "2.3.11.5" "Error" "Could not check 'Network security: Do not store LAN Manager hash value on next password change'. Error: $($_.Exception.Message)" "Ensure 'Network security: Do not store LAN Manager hash value on next password change' is set to 'Enabled'" "Network security" "High" "High" "Prevent LAN Manager hash storage for improved security." "Review and ensure the policy is set to 'Enabled'."
}

try {
    # Ensure 'Network security: Force logoff when logon hours expire' is set to 'Enabled'
    $forceLogoff = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "ForceLogoffWhenHourExpire" -ErrorAction Stop
    if ($forceLogoff.ForceLogoffWhenHourExpire -eq 1) {
        Add-Result "2.3.11.6" "Pass" "Network security: Force logoff when logon hours expire is set to 'Enabled'." "Ensure 'Network security: Force logoff when logon hours expire' is set to 'Enabled'" "Network security" "Medium" "Medium" "Force logoff when logon hours expire." "Review and ensure the policy is set to 'Enabled'."
    } elseif ($forceLogoff -eq $null) {
        Add-Result "2.3.11.6" "Null" "Network security: Force logoff when logon hours expire setting is missing." "Ensure 'Network security: Force logoff when logon hours expire' is set to 'Enabled'" "Network security" "Medium" "Medium" "Force logoff when logon hours expire." "Review and ensure the policy is set to 'Enabled'."
    } else {
        Add-Result "2.3.11.6" "Fail" "Network security: Force logoff when logon hours expire is not set to 'Enabled'." "Ensure 'Network security: Force logoff when logon hours expire' is set to 'Enabled'" "Network security" "Medium" "Medium" "Force logoff when logon hours expire." "Review and ensure the policy is set to 'Enabled'."
    }
} catch {
    Add-Result "2.3.11.6" "Error" "Could not check 'Network security: Force logoff when logon hours expire'. Error: $($_.Exception.Message)" "Ensure 'Network security: Force logoff when logon hours expire' is set to 'Enabled'" "Network security" "Medium" "Medium" "Force logoff when logon hours expire." "Review and ensure the policy is set to 'Enabled'."
}

try {
    # Ensure 'Network security: LAN Manager authentication level' is set to 'Send NTLMv2 response only. Refuse LM & NTLM'
    $lanManagerLevel = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "LmCompatibilityLevel" -ErrorAction Stop
    if ($lanManagerLevel.LmCompatibilityLevel -eq 5) {
        Add-Result "2.3.11.7" "Pass" "Network security: LAN Manager authentication level is set to 'Send NTLMv2 response only. Refuse LM & NTLM'." "Ensure 'Network security: LAN Manager authentication level' is set to 'Send NTLMv2 response only. Refuse LM & NTLM'" "Network security" "High" "High" "Ensure secure LAN Manager authentication level." "Review and ensure the policy is set correctly."
    } elseif ($lanManagerLevel -eq $null) {
        Add-Result "2.3.11.7" "Null" "Network security: LAN Manager authentication level setting is missing." "Ensure 'Network security: LAN Manager authentication level' is set to 'Send NTLMv2 response only. Refuse LM & NTLM'" "Network security" "High" "High" "Ensure secure LAN Manager authentication level." "Review and ensure the policy is set correctly."
    } else {
        Add-Result "2.3.11.7" "Fail" "Network security: LAN Manager authentication level is not set to 'Send NTLMv2 response only. Refuse LM & NTLM'." "Ensure 'Network security: LAN Manager authentication level' is set to 'Send NTLMv2 response only. Refuse LM & NTLM'" "Network security" "High" "High" "Ensure secure LAN Manager authentication level." "Review and ensure the policy is set correctly."
    }
} catch {
    Add-Result "2.3.11.7" "Error" "Could not check 'Network security: LAN Manager authentication level'. Error: $($_.Exception.Message)" "Ensure 'Network security: LAN Manager authentication level' is set to 'Send NTLMv2 response only. Refuse LM & NTLM'" "Network security" "High" "High" "Ensure secure LAN Manager authentication level." "Review and ensure the policy is set correctly."
}

try {
    # Ensure 'Network security: LDAP client signing requirements' is set to 'Negotiate signing' or higher
    $ldapSigningRequirements = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LDAP" -Name "LDAPClientIntegrity" -ErrorAction Stop
    if ($ldapSigningRequirements.LDAPClientIntegrity -ge 1) {
        Add-Result "2.3.11.8" "Pass" "Network security: LDAP client signing requirements is set to 'Negotiate signing' or higher." "Ensure 'Network security: LDAP client signing requirements' is set to 'Negotiate signing' or higher" "Network security" "High" "High" "Ensure secure LDAP signing requirements." "Review and ensure the policy is set correctly."
    } elseif ($ldapSigningRequirements -eq $null) {
        Add-Result "2.3.11.8" "Null" "Network security: LDAP client signing requirements setting is missing." "Ensure 'Network security: LDAP client signing requirements' is set to 'Negotiate signing' or higher" "Network security" "High" "High" "Ensure secure LDAP signing requirements." "Review and ensure the policy is set correctly."
    } else {
        Add-Result "2.3.11.8" "Fail" "Network security: LDAP client signing requirements is not set to 'Negotiate signing' or higher." "Ensure 'Network security: LDAP client signing requirements' is set to 'Negotiate signing' or higher" "Network security" "High" "High" "Ensure secure LDAP signing requirements." "Review and ensure the policy is set correctly."
    }
} catch {
    Add-Result "2.3.11.8" "Error" "Could not check 'Network security: LDAP client signing requirements'. Error: $($_.Exception.Message)" "Ensure 'Network security: LDAP client signing requirements' is set to 'Negotiate signing' or higher" "Network security" "High" "High" "Ensure secure LDAP signing requirements." "Review and ensure the policy is set correctly."
}

try {
    # Ensure 'Network security: Minimum session security for NTLM SSP based (including secure RPC) clients' is set to 'Require NTLMv2 session security, Require 128-bit encryption'
    $ntlmClientSessionSecurity = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\MSV1_0" -Name "NTLMMinClientSec" -ErrorAction Stop
    if ($ntlmClientSessionSecurity.NTLMMinClientSec -eq 3) {
        Add-Result "2.3.11.9" "Pass" "Network security: Minimum session security for NTLM SSP based (including secure RPC) clients is set to 'Require NTLMv2 session security, Require 128-bit encryption'." "Ensure 'Network security: Minimum session security for NTLM SSP based (including secure RPC) clients' is set to 'Require NTLMv2 session security, Require 128-bit encryption'" "Network security" "High" "High" "Ensure secure NTLM session security for clients." "Review and ensure the policy is set correctly."
    } elseif ($ntlmClientSessionSecurity -eq $null) {
        Add-Result "2.3.11.9" "Null" "Network security: Minimum session security for NTLM SSP based (including secure RPC) clients setting is missing." "Ensure 'Network security: Minimum session security for NTLM SSP based (including secure RPC) clients' is set to 'Require NTLMv2 session security, Require 128-bit encryption'" "Network security" "High" "High" "Ensure secure NTLM session security for clients." "Review and ensure the policy is set correctly."
    } else {
        Add-Result "2.3.11.9" "Fail" "Network security: Minimum session security for NTLM SSP based (including secure RPC) clients is not set correctly." "Ensure 'Network security: Minimum session security for NTLM SSP based (including secure RPC) clients' is set to 'Require NTLMv2 session security, Require 128-bit encryption'" "Network security" "High" "High" "Ensure secure NTLM session security for clients." "Review and ensure the policy is set correctly."
    }
} catch {
    Add-Result "2.3.11.9" "Error" "Could not check 'Network security: Minimum session security for NTLM SSP based (including secure RPC) clients'. Error: $($_.Exception.Message)" "Ensure 'Network security: Minimum session security for NTLM SSP based (including secure RPC) clients' is set to 'Require NTLMv2 session security, Require 128-bit encryption'" "Network security" "High" "High" "Ensure secure NTLM session security for clients." "Review and ensure the policy is set correctly."
}

try {
    # Ensure 'Network security: Minimum session security for NTLM SSP based (including secure RPC) servers' is set to 'Require NTLMv2 session security, Require 128-bit encryption'
    $ntlmServerSessionSecurity = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\MSV1_0" -Name "NTLMMinServerSec" -ErrorAction Stop
    if ($ntlmServerSessionSecurity.NTLMMinServerSec -eq 3) {
        Add-Result "2.3.11.10" "Pass" "Network security: Minimum session security for NTLM SSP based (including secure RPC) servers is set to 'Require NTLMv2 session security, Require 128-bit encryption'." "Ensure 'Network security: Minimum session security for NTLM SSP based (including secure RPC) servers' is set to 'Require NTLMv2 session security, Require 128-bit encryption'" "Network security" "High" "High" "Ensure secure NTLM session security for servers." "Review and ensure the policy is set correctly."
    } elseif ($ntlmServerSessionSecurity -eq $null) {
        Add-Result "2.3.11.10" "Null" "Network security: Minimum session security for NTLM SSP based (including secure RPC) servers setting is missing." "Ensure 'Network security: Minimum session security for NTLM SSP based (including secure RPC) servers' is set to 'Require NTLMv2 session security, Require 128-bit encryption'" "Network security" "High" "High" "Ensure secure NTLM session security for servers." "Review and ensure the policy is set correctly."
    } else {
        Add-Result "2.3.11.10" "Fail" "Network security: Minimum session security for NTLM SSP based (including secure RPC) servers is not set correctly." "Ensure 'Network security: Minimum session security for NTLM SSP based (including secure RPC) servers' is set to 'Require NTLMv2 session security, Require 128-bit encryption'" "Network security" "High" "High" "Ensure secure NTLM session security for servers." "Review and ensure the policy is set correctly."
    }
} catch {
    Add-Result "2.3.11.10" "Error" "Could not check 'Network security: Minimum session security for NTLM SSP based (including secure RPC) servers'. Error: $($_.Exception.Message)" "Ensure 'Network security: Minimum session security for NTLM SSP based (including secure RPC) servers' is set to 'Require NTLMv2 session security, Require 128-bit encryption'" "Network security" "High" "High" "Ensure secure NTLM session security for servers." "Review and ensure the policy is set correctly."
}

try {
    # Ensure 'Network security: Restrict NTLM: Audit Incoming NTLM Traffic' is set to 'Enable auditing for all accounts'
    $auditIncomingNTLM = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\MSV1_0" -Name "AuditReceivingNTLM" -ErrorAction Stop
    if ($auditIncomingNTLM.AuditReceivingNTLM -eq 2) {
        Add-Result "2.3.11.11" "Pass" "Network security: Restrict NTLM: Audit Incoming NTLM Traffic is set to 'Enable auditing for all accounts'." "Ensure 'Network security: Restrict NTLM: Audit Incoming NTLM Traffic' is set to 'Enable auditing for all accounts'" "Network security" "Medium" "Medium" "Enable auditing for incoming NTLM traffic." "Review and ensure the policy is set to 'Enable auditing for all accounts'."
    } elseif ($auditIncomingNTLM -eq $null) {
        Add-Result "2.3.11.11" "Null" "Network security: Restrict NTLM: Audit Incoming NTLM Traffic setting is missing." "Ensure 'Network security: Restrict NTLM: Audit Incoming NTLM Traffic' is set to 'Enable auditing for all accounts'" "Network security" "Medium" "Medium" "Enable auditing for incoming NTLM traffic." "Review and ensure the policy is set to 'Enable auditing for all accounts'."
    } else {
        Add-Result "2.3.11.11" "Fail" "Network security: Restrict NTLM: Audit Incoming NTLM Traffic is not set to 'Enable auditing for all accounts'." "Ensure 'Network security: Restrict NTLM: Audit Incoming NTLM Traffic' is set to 'Enable auditing for all accounts'" "Network security" "Medium" "Medium" "Enable auditing for incoming NTLM traffic." "Review and ensure the policy is set to 'Enable auditing for all accounts'."
    }
} catch {
    Add-Result "2.3.11.11" "Error" "Could not check 'Network security: Restrict NTLM: Audit Incoming NTLM Traffic'. Error: $($_.Exception.Message)" "Ensure 'Network security: Restrict NTLM: Audit Incoming NTLM Traffic' is set to 'Enable auditing for all accounts'" "Network security" "Medium" "Medium" "Enable auditing for incoming NTLM traffic." "Review and ensure the policy is set to 'Enable auditing for all accounts'."
}

try {
    # Ensure 'Network security: Restrict NTLM: Outgoing NTLM traffic to remote servers' is set to 'Audit all' or higher
    $outgoingNTLMTraffic = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\MSV1_0" -Name "RestrictSendingNTLM" -ErrorAction Stop
    if ($outgoingNTLMTraffic.RestrictSendingNTLM -eq 2) {
        Add-Result "2.3.11.12" "Pass" "Network security: Restrict NTLM: Outgoing NTLM traffic to remote servers is set to 'Audit all' or higher." "Ensure 'Network security: Restrict NTLM: Outgoing NTLM traffic to remote servers' is set to 'Audit all' or higher" "Network security" "High" "High" "Audit outgoing NTLM traffic to remote servers." "Review and ensure the policy is set to 'Audit all' or higher."
    } elseif ($outgoingNTLMTraffic -eq $null) {
        Add-Result "2.3.11.12" "Null" "Network security: Restrict NTLM: Outgoing NTLM traffic to remote servers setting is missing." "Ensure 'Network security: Restrict NTLM: Outgoing NTLM traffic to remote servers' is set to 'Audit all' or higher" "Network security" "High" "High" "Audit outgoing NTLM traffic to remote servers." "Review and ensure the policy is set to 'Audit all' or higher."
    } else {
        Add-Result "2.3.11.12" "Fail" "Network security: Restrict NTLM: Outgoing NTLM traffic to remote servers is not set to 'Audit all' or higher." "Ensure 'Network security: Restrict NTLM: Outgoing NTLM traffic to remote servers' is set to 'Audit all' or higher" "Network security" "High" "High" "Audit outgoing NTLM traffic to remote servers." "Review and ensure the policy is set to 'Audit all' or higher."
    }
} catch {
    Add-Result "2.3.11.12" "Error" "Could not check 'Network security: Restrict NTLM: Outgoing NTLM traffic to remote servers'. Error: $($_.Exception.Message)" "Ensure 'Network security: Restrict NTLM: Outgoing NTLM traffic to remote servers' is set to 'Audit all' or higher" "Network security" "High" "High" "Audit outgoing NTLM traffic to remote servers." "Review and ensure the policy is set to 'Audit all' or higher."
}

try {
    # Ensure 'System cryptography: Force strong key protection for user keys stored on the computer' is set to 'User is prompted when the key is first used' or higher
    $strongKeyProtection = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Cryptography" -Name "ForceKeyProtection" -ErrorAction Stop
    if ($strongKeyProtection.ForceKeyProtection -ge 1) {
        Add-Result "2.3.14.1" "Pass" "System cryptography: Force strong key protection for user keys stored on the computer is set to 'User is prompted when the key is first used' or higher." "Ensure 'System cryptography: Force strong key protection for user keys stored on the computer' is set to 'User is prompted when the key is first used' or higher" "System cryptography" "Medium" "Medium" "Ensure strong key protection is enforced." "Review and ensure the policy is set to 'User is prompted when the key is first used' or higher."
    } elseif ($strongKeyProtection -eq $null) {
        Add-Result "2.3.14.1" "Null" "System cryptography: Force strong key protection for user keys stored on the computer setting is missing." "Ensure 'System cryptography: Force strong key protection for user keys stored on the computer' is set to 'User is prompted when the key is first used' or higher" "System cryptography" "Medium" "Medium" "Ensure strong key protection is enforced." "Review and ensure the policy is set to 'User is prompted when the key is first used' or higher."
    } else {
        Add-Result "2.3.14.1" "Fail" "System cryptography: Force strong key protection for user keys stored on the computer is not set to 'User is prompted when the key is first used' or higher." "Ensure 'System cryptography: Force strong key protection for user keys stored on the computer' is set to 'User is prompted when the key is first used' or higher" "System cryptography" "Medium" "Medium" "Ensure strong key protection is enforced." "Review and ensure the policy is set to 'User is prompted when the key is first used' or higher."
    }
} catch {
    Add-Result "2.3.14.1" "Error" "Could not check 'System cryptography: Force strong key protection for user keys stored on the computer'. Error: $($_.Exception.Message)" "Ensure 'System cryptography: Force strong key protection for user keys stored on the computer' is set to 'User is prompted when the key is first used' or higher" "System cryptography" "Medium" "Medium" "Ensure strong key protection is enforced." "Review and ensure the policy is set to 'User is prompted when the key is first used' or higher."
}

try {
    # Ensure 'System objects: Require case insensitivity for non-Windows subsystems' is set to 'Enabled'
    $caseInsensitivity = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Kernel" -Name "ObCaseInsensitive" -ErrorAction Stop
    if ($caseInsensitivity.ObCaseInsensitive -eq 1) {
        Add-Result "2.3.15.1" "Pass" "System objects: Require case insensitivity for non-Windows subsystems is set to 'Enabled'." "Ensure 'System objects: Require case insensitivity for non-Windows subsystems' is set to 'Enabled'" "System objects" "Medium" "Medium" "Ensure case insensitivity is enforced for non-Windows subsystems." "Review and ensure the policy is set to 'Enabled'."
    } elseif ($caseInsensitivity -eq $null) {
        Add-Result "2.3.15.1" "Null" "System objects: Require case insensitivity for non-Windows subsystems setting is missing." "Ensure 'System objects: Require case insensitivity for non-Windows subsystems' is set to 'Enabled'" "System objects" "Medium" "Medium" "Ensure case insensitivity is enforced for non-Windows subsystems." "Review and ensure the policy is set to 'Enabled'."
    } else {
        Add-Result "2.3.15.1" "Fail" "System objects: Require case insensitivity for non-Windows subsystems is not set to 'Enabled'." "Ensure 'System objects: Require case insensitivity for non-Windows subsystems' is set to 'Enabled'" "System objects" "Medium" "Medium" "Ensure case insensitivity is enforced for non-Windows subsystems." "Review and ensure the policy is set to 'Enabled'."
    }
} catch {
    Add-Result "2.3.15.1" "Error" "Could not check 'System objects: Require case insensitivity for non-Windows subsystems'. Error: $($_.Exception.Message)" "Ensure 'System objects: Require case insensitivity for non-Windows subsystems' is set to 'Enabled'" "System objects" "Medium" "Medium" "Ensure case insensitivity is enforced for non-Windows subsystems." "Review and ensure the policy is set to 'Enabled'."
}

try {
    # Ensure 'System objects: Strengthen default permissions of internal system objects (e.g. Symbolic Links)' is set to 'Enabled'
    $strengthenPermissions = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager" -Name "ProtectionMode" -ErrorAction Stop
    if ($strengthenPermissions.ProtectionMode -eq 1) {
        Add-Result "2.3.15.2" "Pass" "System objects: Strengthen default permissions of internal system objects (e.g. Symbolic Links) is set to 'Enabled'." "Ensure 'System objects: Strengthen default permissions of internal system objects (e.g. Symbolic Links)' is set to 'Enabled'" "System objects" "Medium" "Medium" "Ensure default permissions of system objects are strengthened." "Review and ensure the policy is set to 'Enabled'."
    } elseif ($strengthenPermissions -eq $null) {
        Add-Result "2.3.15.2" "Null" "System objects: Strengthen default permissions of internal system objects (e.g. Symbolic Links) setting is missing." "Ensure 'System objects: Strengthen default permissions of internal system objects (e.g. Symbolic Links)' is set to 'Enabled'" "System objects" "Medium" "Medium" "Ensure default permissions of system objects are strengthened." "Review and ensure the policy is set to 'Enabled'."
    } else {
        Add-Result "2.3.15.2" "Fail" "System objects: Strengthen default permissions of internal system objects (e.g. Symbolic Links) is not set to 'Enabled'." "Ensure 'System objects: Strengthen default permissions of internal system objects (e.g. Symbolic Links)' is set to 'Enabled'" "System objects" "Medium" "Medium" "Ensure default permissions of system objects are strengthened." "Review and ensure the policy is set to 'Enabled'."
    }
} catch {
    Add-Result "2.3.15.2" "Error" "Could not check 'System objects: Strengthen default permissions of internal system objects (e.g. Symbolic Links)'. Error: $($_.Exception.Message)" "Ensure 'System objects: Strengthen default permissions of internal system objects (e.g. Symbolic Links)' is set to 'Enabled'" "System objects" "Medium" "Medium" "Ensure default permissions of system objects are strengthened." "Review and ensure the policy is set to 'Enabled'."
}

try {
    # Ensure 'User Account Control: Admin Approval Mode for the Built-in Administrator account' is set to 'Enabled'
    $adminApprovalMode = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "FilterAdministratorToken" -ErrorAction Stop
    if ($adminApprovalMode.FilterAdministratorToken -eq 1) {
        Add-Result "2.3.17.1" "Pass" "User Account Control: Admin Approval Mode for the Built-in Administrator account is set to 'Enabled'." "Ensure 'User Account Control: Admin Approval Mode for the Built-in Administrator account' is set to 'Enabled'" "User Account Control" "High" "High" "Ensure Admin Approval Mode is enabled for the built-in Administrator account." "Review and ensure the policy is set to 'Enabled'."
    } elseif ($adminApprovalMode -eq $null) {
        Add-Result "2.3.17.1" "Null" "User Account Control: Admin Approval Mode for the Built-in Administrator account setting is missing." "Ensure 'User Account Control: Admin Approval Mode for the Built-in Administrator account' is set to 'Enabled'" "User Account Control" "High" "High" "Ensure Admin Approval Mode is enabled for the built-in Administrator account." "Review and ensure the policy is set to 'Enabled'."
    } else {
        Add-Result "2.3.17.1" "Fail" "User Account Control: Admin Approval Mode for the Built-in Administrator account is not set to 'Enabled'." "Ensure 'User Account Control: Admin Approval Mode for the Built-in Administrator account' is set to 'Enabled'" "User Account Control" "High" "High" "Ensure Admin Approval Mode is enabled for the built-in Administrator account." "Review and ensure the policy is set to 'Enabled'."
    }
} catch {
    Add-Result "2.3.17.1" "Error" "Could not check 'User Account Control: Admin Approval Mode for the Built-in Administrator account'. Error: $($_.Exception.Message)" "Ensure 'User Account Control: Admin Approval Mode for the Built-in Administrator account' is set to 'Enabled'" "User Account Control" "High" "High" "Ensure Admin Approval Mode is enabled for the built-in Administrator account." "Review and ensure the policy is set to 'Enabled'."
}

try {
    # Ensure 'User Account Control: Behavior of the elevation prompt for administrators in Admin Approval Mode' is set to 'Prompt for consent on the secure desktop' or higher
    $adminElevationPrompt = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "ConsentPromptBehaviorAdmin" -ErrorAction Stop
    if ($adminElevationPrompt.ConsentPromptBehaviorAdmin -eq 2) {
        Add-Result "2.3.17.2" "Pass" "User Account Control: Behavior of the elevation prompt for administrators in Admin Approval Mode is set to 'Prompt for consent on the secure desktop' or higher." "Ensure 'User Account Control: Behavior of the elevation prompt for administrators in Admin Approval Mode' is set to 'Prompt for consent on the secure desktop' or higher" "User Account Control" "High" "High" "Ensure secure elevation prompt behavior for administrators." "Review and ensure the policy is set correctly."
    } elseif ($adminElevationPrompt -eq $null) {
        Add-Result "2.3.17.2" "Null" "User Account Control: Behavior of the elevation prompt for administrators in Admin Approval Mode setting is missing." "Ensure 'User Account Control: Behavior of the elevation prompt for administrators in Admin Approval Mode' is set to 'Prompt for consent on the secure desktop' or higher" "User Account Control" "High" "High" "Ensure secure elevation prompt behavior for administrators." "Review and ensure the policy is set correctly."
    } else {
        Add-Result "2.3.17.2" "Fail" "User Account Control: Behavior of the elevation prompt for administrators in Admin Approval Mode is not set to 'Prompt for consent on the secure desktop' or higher." "Ensure 'User Account Control: Behavior of the elevation prompt for administrators in Admin Approval Mode' is set to 'Prompt for consent on the secure desktop' or higher" "User Account Control" "High" "High" "Ensure secure elevation prompt behavior for administrators." "Review and ensure the policy is set correctly."
    }
} catch {
    Add-Result "2.3.17.2" "Error" "Could not check 'User Account Control: Behavior of the elevation prompt for administrators in Admin Approval Mode'. Error: $($_.Exception.Message)" "Ensure 'User Account Control: Behavior of the elevation prompt for administrators in Admin Approval Mode' is set to 'Prompt for consent on the secure desktop' or higher" "User Account Control" "High" "High" "Ensure secure elevation prompt behavior for administrators." "Review and ensure the policy is set correctly."
}

try {
    # Ensure 'User Account Control: Behavior of the elevation prompt for standard users' is set to 'Automatically deny elevation requests'
    $standardUserElevationPrompt = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "ConsentPromptBehaviorUser" -ErrorAction Stop
    if ($standardUserElevationPrompt.ConsentPromptBehaviorUser -eq 0) {
        Add-Result "2.3.17.3" "Pass" "User Account Control: Behavior of the elevation prompt for standard users is set to 'Automatically deny elevation requests'." "Ensure 'User Account Control: Behavior of the elevation prompt for standard users' is set to 'Automatically deny elevation requests'" "User Account Control" "High" "High" "Ensure elevation requests for standard users are denied automatically." "Review and ensure the policy is set to 'Automatically deny elevation requests'."
    } elseif ($standardUserElevationPrompt -eq $null) {
        Add-Result "2.3.17.3" "Null" "User Account Control: Behavior of the elevation prompt for standard users setting is missing." "Ensure 'User Account Control: Behavior of the elevation prompt for standard users' is set to 'Automatically deny elevation requests'" "User Account Control" "High" "High" "Ensure elevation requests for standard users are denied automatically." "Review and ensure the policy is set to 'Automatically deny elevation requests'."
    } else {
        Add-Result "2.3.17.3" "Fail" "User Account Control: Behavior of the elevation prompt for standard users is not set to 'Automatically deny elevation requests'." "Ensure 'User Account Control: Behavior of the elevation prompt for standard users' is set to 'Automatically deny elevation requests'" "User Account Control" "High" "High" "Ensure elevation requests for standard users are denied automatically." "Review and ensure the policy is set to 'Automatically deny elevation requests'."
    }
} catch {
    Add-Result "2.3.17.3" "Error" "Could not check 'User Account Control: Behavior of the elevation prompt for standard users'. Error: $($_.Exception.Message)" "Ensure 'User Account Control: Behavior of the elevation prompt for standard users' is set to 'Automatically deny elevation requests'" "User Account Control" "High" "High" "Ensure elevation requests for standard users are denied automatically." "Review and ensure the policy is set to 'Automatically deny elevation requests'."
}

try {
    # Ensure 'User Account Control: Detect application installations and prompt for elevation' is set to 'Enabled'
    $detectAppInstallation = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "EnableInstallerDetection" -ErrorAction Stop
    if ($detectAppInstallation.EnableInstallerDetection -eq 1) {
        Add-Result "2.3.17.4" "Pass" "User Account Control: Detect application installations and prompt for elevation is set to 'Enabled'." "Ensure 'User Account Control: Detect application installations and prompt for elevation' is set to 'Enabled'" "User Account Control" "Medium" "Medium" "Ensure application installations are detected and prompt for elevation." "Review and ensure the policy is set to 'Enabled'."
    } elseif ($detectAppInstallation -eq $null) {
        Add-Result "2.3.17.4" "Null" "User Account Control: Detect application installations and prompt for elevation setting is missing." "Ensure 'User Account Control: Detect application installations and prompt for elevation' is set to 'Enabled'" "User Account Control" "Medium" "Medium" "Ensure application installations are detected and prompt for elevation." "Review and ensure the policy is set to 'Enabled'."
    } else {
        Add-Result "2.3.17.4" "Fail" "User Account Control: Detect application installations and prompt for elevation is not set to 'Enabled'." "Ensure 'User Account Control: Detect application installations and prompt for elevation' is set to 'Enabled'" "User Account Control" "Medium" "Medium" "Ensure application installations are detected and prompt for elevation." "Review and ensure the policy is set to 'Enabled'."
    }
} catch {
    Add-Result "2.3.17.4" "Error" "Could not check 'User Account Control: Detect application installations and prompt for elevation'. Error: $($_.Exception.Message)" "Ensure 'User Account Control: Detect application installations and prompt for elevation' is set to 'Enabled'" "User Account Control" "Medium" "Medium" "Ensure application installations are detected and prompt for elevation." "Review and ensure the policy is set to 'Enabled'."
}

try {
    # Ensure 'User Account Control: Only elevate UIAccess applications that are installed in secure locations' is set to 'Enabled'
    $elevateUIAccess = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "EnableSecureUIAPaths" -ErrorAction Stop
    if ($elevateUIAccess.EnableSecureUIAPaths -eq 1) {
        Add-Result "2.3.17.5" "Pass" "User Account Control: Only elevate UIAccess applications that are installed in secure locations is set to 'Enabled'." "Ensure 'User Account Control: Only elevate UIAccess applications that are installed in secure locations' is set to 'Enabled'" "User Account Control" "Medium" "Medium" "Ensure UIAccess applications are elevated only if installed in secure locations." "Review and ensure the policy is set to 'Enabled'."
    } elseif ($elevateUIAccess -eq $null) {
        Add-Result "2.3.17.5" "Null" "User Account Control: Only elevate UIAccess applications that are installed in secure locations setting is missing." "Ensure 'User Account Control: Only elevate UIAccess applications that are installed in secure locations' is set to 'Enabled'" "User Account Control" "Medium" "Medium" "Ensure UIAccess applications are elevated only if installed in secure locations." "Review and ensure the policy is set to 'Enabled'."
    } else {
        Add-Result "2.3.17.5" "Fail" "User Account Control: Only elevate UIAccess applications that are installed in secure locations is not set to 'Enabled'." "Ensure 'User Account Control: Only elevate UIAccess applications that are installed in secure locations' is set to 'Enabled'" "User Account Control" "Medium" "Medium" "Ensure UIAccess applications are elevated only if installed in secure locations." "Review and ensure the policy is set to 'Enabled'."
    }
} catch {
    Add-Result "2.3.17.5" "Error" "Could not check 'User Account Control: Only elevate UIAccess applications that are installed in secure locations'. Error: $($_.Exception.Message)" "Ensure 'User Account Control: Only elevate UIAccess applications that are installed in secure locations' is set to 'Enabled'" "User Account Control" "Medium" "Medium" "Ensure UIAccess applications are elevated only if installed in secure locations." "Review and ensure the policy is set to 'Enabled'."
}

try {
    # Ensure 'User Account Control: Run all administrators in Admin Approval Mode' is set to 'Enabled'
    $runAdminApprovalMode = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "EnableLUA" -ErrorAction Stop
    if ($runAdminApprovalMode.EnableLUA -eq 1) {
        Add-Result "2.3.17.6" "Pass" "User Account Control: Run all administrators in Admin Approval Mode is set to 'Enabled'." "Ensure 'User Account Control: Run all administrators in Admin Approval Mode' is set to 'Enabled'" "User Account Control" "High" "High" "Ensure administrators run in Admin Approval Mode." "Review and ensure the policy is set to 'Enabled'."
    } elseif ($runAdminApprovalMode -eq $null) {
        Add-Result "2.3.17.6" "Null" "User Account Control: Run all administrators in Admin Approval Mode setting is missing." "Ensure 'User Account Control: Run all administrators in Admin Approval Mode' is set to 'Enabled'" "User Account Control" "High" "High" "Ensure administrators run in Admin Approval Mode." "Review and ensure the policy is set to 'Enabled'."
    } else {
        Add-Result "2.3.17.6" "Fail" "User Account Control: Run all administrators in Admin Approval Mode is not set to 'Enabled'." "Ensure 'User Account Control: Run all administrators in Admin Approval Mode' is set to 'Enabled'" "User Account Control" "High" "High" "Ensure administrators run in Admin Approval Mode." "Review and ensure the policy is set to 'Enabled'."
    }
} catch {
    Add-Result "2.3.17.6" "Error" "Could not check 'User Account Control: Run all administrators in Admin Approval Mode'. Error: $($_.Exception.Message)" "Ensure 'User Account Control: Run all administrators in Admin Approval Mode' is set to 'Enabled'" "User Account Control" "High" "High" "Ensure administrators run in Admin Approval Mode." "Review and ensure the policy is set to 'Enabled'."
}

try {
    # Ensure 'User Account Control: Switch to the secure desktop when prompting for elevation' is set to 'Enabled'
    $secureDesktopElevation = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "PromptOnSecureDesktop" -ErrorAction Stop
    if ($secureDesktopElevation.PromptOnSecureDesktop -eq 1) {
        Add-Result "2.3.17.7" "Pass" "User Account Control: Switch to the secure desktop when prompting for elevation is set to 'Enabled'." "Ensure 'User Account Control: Switch to the secure desktop when prompting for elevation' is set to 'Enabled'" "User Account Control" "High" "High" "Ensure elevation prompts occur on a secure desktop." "Review and ensure the policy is set to 'Enabled'."
    } elseif ($secureDesktopElevation -eq $null) {
        Add-Result "2.3.17.7" "Null" "User Account Control: Switch to the secure desktop when prompting for elevation setting is missing." "Ensure 'User Account Control: Switch to the secure desktop when prompting for elevation' is set to 'Enabled'" "User Account Control" "High" "High" "Ensure elevation prompts occur on a secure desktop." "Review and ensure the policy is set to 'Enabled'."
    } else {
        Add-Result "2.3.17.7" "Fail" "User Account Control: Switch to the secure desktop when prompting for elevation is not set to 'Enabled'." "Ensure 'User Account Control: Switch to the secure desktop when prompting for elevation' is set to 'Enabled'" "User Account Control" "High" "High" "Ensure elevation prompts occur on a secure desktop." "Review and ensure the policy is set to 'Enabled'."
    }
} catch {
    Add-Result "2.3.17.7" "Error" "Could not check 'User Account Control: Switch to the secure desktop when prompting for elevation'. Error: $($_.Exception.Message)" "Ensure 'User Account Control: Switch to the secure desktop when prompting for elevation' is set to 'Enabled'" "User Account Control" "High" "High" "Ensure elevation prompts occur on a secure desktop." "Review and ensure the policy is set to 'Enabled'."
}

try {
    # Ensure 'User Account Control: Virtualize file and registry write failures to per-user locations' is set to 'Enabled'
    $virtualizeWriteFailures = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "EnableVirtualization" -ErrorAction Stop
    if ($virtualizeWriteFailures.EnableVirtualization -eq 1) {
        Add-Result "2.3.17.8" "Pass" "User Account Control: Virtualize file and registry write failures to per-user locations is set to 'Enabled'." "Ensure 'User Account Control: Virtualize file and registry write failures to per-user locations' is set to 'Enabled'" "User Account Control" "Medium" "Medium" "Ensure file and registry write failures are virtualized to per-user locations." "Review and ensure the policy is set to 'Enabled'."
    } elseif ($virtualizeWriteFailures -eq $null) {
        Add-Result "2.3.17.8" "Null" "User Account Control: Virtualize file and registry write failures to per-user locations setting is missing." "Ensure 'User Account Control: Virtualize file and registry write failures to per-user locations' is set to 'Enabled'" "User Account Control" "Medium" "Medium" "Ensure file and registry write failures are virtualized to per-user locations." "Review and ensure the policy is set to 'Enabled'."
    } else {
        Add-Result "2.3.17.8" "Fail" "User Account Control: Virtualize file and registry write failures to per-user locations is not set to 'Enabled'." "Ensure 'User Account Control: Virtualize file and registry write failures to per-user locations' is set to 'Enabled'" "User Account Control" "Medium" "Medium" "Ensure file and registry write failures are virtualized to per-user locations." "Review and ensure the policy is set to 'Enabled'."
    }
} catch {
    Add-Result "2.3.17.8" "Error" "Could not check 'User Account Control: Virtualize file and registry write failures to per-user locations'. Error: $($_.Exception.Message)" "Ensure 'User Account Control: Virtualize file and registry write failures to per-user locations' is set to 'Enabled'" "User Account Control" "Medium" "Medium" "Ensure file and registry write failures are virtualized to per-user locations." "Review and ensure the policy is set to 'Enabled'."
}


# 5th

try {
    # Ensure 'Bluetooth Audio Gateway Service (BTAGService)' is set to 'Disabled'
    $BTAGService = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\BTAGService" -Name "Start" -ErrorAction Stop
    if ($BTAGService.Start -eq 4) {
        Add-Result "5.1" "Pass" "Bluetooth Audio Gateway Service is set to Disabled." "Ensure 'Bluetooth Audio Gateway Service (BTAGService)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Bluetooth Audio Gateway Service is disabled to enhance security." "Review and disable the service if enabled."
    } elseif ($BTAGService.Start -eq $null) {
        Add-Result "5.1" "Null" "Bluetooth Audio Gateway Service setting is missing." "Ensure 'Bluetooth Audio Gateway Service (BTAGService)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Bluetooth Audio Gateway Service is disabled to enhance security." "Review and disable the service if enabled."
    } else {
        Add-Result "5.1" "Fail" "Bluetooth Audio Gateway Service is not set to Disabled." "Ensure 'Bluetooth Audio Gateway Service (BTAGService)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Bluetooth Audio Gateway Service is disabled to enhance security." "Review and disable the service if enabled."
    }
} catch {
    Add-Result "5.1" "Error" "Could not check 'Bluetooth Audio Gateway Service'. Error: $($_.Exception.Message)" "Ensure 'Bluetooth Audio Gateway Service (BTAGService)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Bluetooth Audio Gateway Service is disabled to enhance security." "Review and disable the service if enabled."
}

try {
    # Ensure 'Bluetooth Support Service (bthserv)' is set to 'Disabled'
    $bthserv = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\bthserv" -Name "Start" -ErrorAction Stop
    if ($bthserv.Start -eq 4) {
        Add-Result "5.2" "Pass" "Bluetooth Support Service is set to Disabled." "Ensure 'Bluetooth Support Service (bthserv)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Bluetooth Support Service is disabled to enhance security." "Review and disable the service if enabled."
    } elseif ($bthserv.Start -eq $null) {
        Add-Result "5.2" "Null" "Bluetooth Support Service setting is missing." "Ensure 'Bluetooth Support Service (bthserv)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Bluetooth Support Service is disabled to enhance security." "Review and disable the service if enabled."
    } else {
        Add-Result "5.2" "Fail" "Bluetooth Support Service is not set to Disabled." "Ensure 'Bluetooth Support Service (bthserv)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Bluetooth Support Service is disabled to enhance security." "Review and disable the service if enabled."
    }
} catch {
    Add-Result "5.2" "Error" "Could not check 'Bluetooth Support Service'. Error: $($_.Exception.Message)" "Ensure 'Bluetooth Support Service (bthserv)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Bluetooth Support Service is disabled to enhance security." "Review and disable the service if enabled."
}

try {
    # Ensure 'Computer Browser (Browser)' is set to 'Disabled' or 'Not Installed'
    $Browser = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Browser" -Name "Start" -ErrorAction Stop
    if ($Browser.Start -eq 4) {
        Add-Result "5.3" "Pass" "Computer Browser Service is set to Disabled." "Ensure 'Computer Browser (Browser)' is set to 'Disabled' or 'Not Installed'" "System Services" "Medium" "Medium" "Ensure the Computer Browser Service is disabled or removed to enhance security." "Review and remove or disable the service if present."
    } elseif ($Browser.Start -eq $null) {
        Add-Result "5.3" "Null" "Computer Browser Service setting is missing." "Ensure 'Computer Browser (Browser)' is set to 'Disabled' or 'Not Installed'" "System Services" "Medium" "Medium" "Ensure the Computer Browser Service is disabled or removed to enhance security." "Review and remove or disable the service if present."
    } else {
        Add-Result "5.3" "Fail" "Computer Browser Service is not set to Disabled or removed." "Ensure 'Computer Browser (Browser)' is set to 'Disabled' or 'Not Installed'" "System Services" "Medium" "Medium" "Ensure the Computer Browser Service is disabled or removed to enhance security." "Review and remove or disable the service if present."
    }
} catch {
    Add-Result "5.3" "Error" "Could not check 'Computer Browser Service'. Error: $($_.Exception.Message)" "Ensure 'Computer Browser (Browser)' is set to 'Disabled' or 'Not Installed'" "System Services" "Medium" "Medium" "Ensure the Computer Browser Service is disabled or removed to enhance security." "Review and remove or disable the service if present."
}

try {
    # Ensure 'Downloaded Maps Manager (MapsBroker)' is set to 'Disabled'
    $MapsBroker = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\MapsBroker" -Name "Start" -ErrorAction Stop
    if ($MapsBroker.Start -eq 4) {
        Add-Result "5.4" "Pass" "Downloaded Maps Manager is set to Disabled." "Ensure 'Downloaded Maps Manager (MapsBroker)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Downloaded Maps Manager service is disabled to enhance security." "Review and disable the service if enabled."
    } elseif ($MapsBroker.Start -eq $null) {
        Add-Result "5.4" "Null" "Downloaded Maps Manager setting is missing." "Ensure 'Downloaded Maps Manager (MapsBroker)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Downloaded Maps Manager service is disabled to enhance security." "Review and disable the service if enabled."
    } else {
        Add-Result "5.4" "Fail" "Downloaded Maps Manager is not set to Disabled." "Ensure 'Downloaded Maps Manager (MapsBroker)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Downloaded Maps Manager service is disabled to enhance security." "Review and disable the service if enabled."
    }
} catch {
    Add-Result "5.4" "Error" "Could not check 'Downloaded Maps Manager'. Error: $($_.Exception.Message)" "Ensure 'Downloaded Maps Manager (MapsBroker)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Downloaded Maps Manager service is disabled to enhance security." "Review and disable the service if enabled."
}


try {
    # Ensure 'Geolocation Service (lfsvc)' is set to 'Disabled'
    $lfsvc = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\lfsvc" -Name "Start" -ErrorAction Stop
    if ($lfsvc.Start -eq 4) {
        Add-Result "5.5" "Pass" "Geolocation Service is set to Disabled." "Ensure 'Geolocation Service (lfsvc)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Geolocation Service is disabled to enhance security." "Review and disable the service if enabled."
    } elseif ($lfsvc.Start -eq $null) {
        Add-Result "5.5" "Null" "Geolocation Service setting is missing." "Ensure 'Geolocation Service (lfsvc)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Geolocation Service is disabled to enhance security." "Review and disable the service if enabled."
    } else {
        Add-Result "5.5" "Fail" "Geolocation Service is not set to Disabled." "Ensure 'Geolocation Service (lfsvc)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Geolocation Service is disabled to enhance security." "Review and disable the service if enabled."
    }
} catch {
    Add-Result "5.5" "Error" "Could not check 'Geolocation Service'. Error: $($_.Exception.Message)" "Ensure 'Geolocation Service (lfsvc)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Geolocation Service is disabled to enhance security." "Review and disable the service if enabled."
}

try {
    # Ensure 'IIS Admin Service (IISADMIN)' is set to 'Disabled' or 'Not Installed'
    $IISADMIN = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\IISADMIN" -Name "Start" -ErrorAction SilentlyContinue
    if ($IISADMIN -eq $null) {
        Add-Result "5.6" "Pass" "IIS Admin Service is not installed." "Ensure 'IIS Admin Service (IISADMIN)' is set to 'Disabled' or 'Not Installed'" "System Services" "Medium" "Medium" "Ensure the IIS Admin Service is disabled or removed to enhance security." "Review and remove or disable the service if present."
    } elseif ($IISADMIN.Start -eq 4) {
        Add-Result "5.6" "Pass" "IIS Admin Service is set to Disabled." "Ensure 'IIS Admin Service (IISADMIN)' is set to 'Disabled' or 'Not Installed'" "System Services" "Medium" "Medium" "Ensure the IIS Admin Service is disabled or removed to enhance security." "Review and remove or disable the service if present."
    } else {
        Add-Result "5.6" "Fail" "IIS Admin Service is not set to Disabled or removed." "Ensure 'IIS Admin Service (IISADMIN)' is set to 'Disabled' or 'Not Installed'" "System Services" "Medium" "Medium" "Ensure the IIS Admin Service is disabled or removed to enhance security." "Review and remove or disable the service if present."
    }
} catch {
    Add-Result "5.6" "Error" "Could not check 'IIS Admin Service'. Error: $($_.Exception.Message)" "Ensure 'IIS Admin Service (IISADMIN)' is set to 'Disabled' or 'Not Installed'" "System Services" "Medium" "Medium" "Ensure the IIS Admin Service is disabled or removed to enhance security." "Review and remove or disable the service if present."
}

try {
    # Ensure 'Infrared monitor service (irmon)' is set to 'Disabled' or 'Not Installed'
    $irmon = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\irmon" -Name "Start" -ErrorAction SilentlyContinue
    if ($irmon -eq $null) {
        Add-Result "5.7" "Pass" "Infrared monitor service is not installed." "Ensure 'Infrared monitor service (irmon)' is set to 'Disabled' or 'Not Installed'" "System Services" "Medium" "Medium" "Ensure the Infrared monitor service is disabled or removed to enhance security." "Review and remove or disable the service if present."
    } elseif ($irmon.Start -eq 4) {
        Add-Result "5.7" "Pass" "Infrared monitor service is set to Disabled." "Ensure 'Infrared monitor service (irmon)' is set to 'Disabled' or 'Not Installed'" "System Services" "Medium" "Medium" "Ensure the Infrared monitor service is disabled or removed to enhance security." "Review and remove or disable the service if present."
    } else {
        Add-Result "5.7" "Fail" "Infrared monitor service is not set to Disabled or removed." "Ensure 'Infrared monitor service (irmon)' is set to 'Disabled' or 'Not Installed'" "System Services" "Medium" "Medium" "Ensure the Infrared monitor service is disabled or removed to enhance security." "Review and remove or disable the service if present."
    }
} catch {
    Add-Result "5.7" "Error" "Could not check 'Infrared monitor service'. Error: $($_.Exception.Message)" "Ensure 'Infrared monitor service (irmon)' is set to 'Disabled' or 'Not Installed'" "System Services" "Medium" "Medium" "Ensure the Infrared monitor service is disabled or removed to enhance security." "Review and remove or disable the service if present."
}

try {
    # Ensure 'Link-Layer Topology Discovery Mapper (lltdsvc)' is set to 'Disabled'
    $lltdsvc = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\lltdsvc" -Name "Start" -ErrorAction Stop
    if ($lltdsvc.Start -eq 4) {
        Add-Result "5.8" "Pass" "Link-Layer Topology Discovery Mapper is set to Disabled." "Ensure 'Link-Layer Topology Discovery Mapper (lltdsvc)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Link-Layer Topology Discovery Mapper is disabled to enhance security." "Review and disable the service if enabled."
    } elseif ($lltdsvc.Start -eq $null) {
        Add-Result "5.8" "Null" "Link-Layer Topology Discovery Mapper setting is missing." "Ensure 'Link-Layer Topology Discovery Mapper (lltdsvc)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Link-Layer Topology Discovery Mapper is disabled to enhance security." "Review and disable the service if enabled."
    } else {
        Add-Result "5.8" "Fail" "Link-Layer Topology Discovery Mapper is not set to Disabled." "Ensure 'Link-Layer Topology Discovery Mapper (lltdsvc)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Link-Layer Topology Discovery Mapper is disabled to enhance security." "Review and disable the service if enabled."
    }
} catch {
    Add-Result "5.8" "Error" "Could not check 'Link-Layer Topology Discovery Mapper'. Error: $($_.Exception.Message)" "Ensure 'Link-Layer Topology Discovery Mapper (lltdsvc)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Link-Layer Topology Discovery Mapper is disabled to enhance security." "Review and disable the service if enabled."
}

try {
    # Ensure 'LxssManager (LxssManager)' is set to 'Disabled' or 'Not Installed'
    $LxssManager = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LxssManager" -Name "Start" -ErrorAction SilentlyContinue
    if ($LxssManager -eq $null) {
        Add-Result "5.9" "Pass" "LxssManager service is not installed." "Ensure 'LxssManager (LxssManager)' is set to 'Disabled' or 'Not Installed'" "System Services" "Medium" "Medium" "Ensure the LxssManager service is disabled or removed to enhance security." "Review and remove or disable the service if present."
    } elseif ($LxssManager.Start -eq 4) {
        Add-Result "5.9" "Pass" "LxssManager service is set to Disabled." "Ensure 'LxssManager (LxssManager)' is set to 'Disabled' or 'Not Installed'" "System Services" "Medium" "Medium" "Ensure the LxssManager service is disabled or removed to enhance security." "Review and remove or disable the service if present."
    } else {
        Add-Result "5.9" "Fail" "LxssManager service is not set to Disabled or removed." "Ensure 'LxssManager (LxssManager)' is set to 'Disabled' or 'Not Installed'" "System Services" "Medium" "Medium" "Ensure the LxssManager service is disabled or removed to enhance security." "Review and remove or disable the service if present."
    }
} catch {
    Add-Result "5.9" "Error" "Could not check 'LxssManager service'. Error: $($_.Exception.Message)" "Ensure 'LxssManager (LxssManager)' is set to 'Disabled' or 'Not Installed'" "System Services" "Medium" "Medium" "Ensure the LxssManager service is disabled or removed to enhance security." "Review and remove or disable the service if present."
}


try {
    # Ensure 'Microsoft FTP Service (FTPSVC)' is set to 'Disabled' or 'Not Installed'
    $FTPSVC = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\FTPSVC" -Name "Start" -ErrorAction SilentlyContinue
    if ($FTPSVC -eq $null) {
        Add-Result "5.10" "Pass" "Microsoft FTP Service is not installed." "Ensure 'Microsoft FTP Service (FTPSVC)' is set to 'Disabled' or 'Not Installed'" "System Services" "Medium" "Medium" "Ensure the Microsoft FTP Service is disabled or removed to enhance security." "Review and remove or disable the service if present."
    } elseif ($FTPSVC.Start -eq 4) {
        Add-Result "5.10" "Pass" "Microsoft FTP Service is set to Disabled." "Ensure 'Microsoft FTP Service (FTPSVC)' is set to 'Disabled' or 'Not Installed'" "System Services" "Medium" "Medium" "Ensure the Microsoft FTP Service is disabled or removed to enhance security." "Review and remove or disable the service if present."
    } else {
        Add-Result "5.10" "Fail" "Microsoft FTP Service is not set to Disabled or removed." "Ensure 'Microsoft FTP Service (FTPSVC)' is set to 'Disabled' or 'Not Installed'" "System Services" "Medium" "Medium" "Ensure the Microsoft FTP Service is disabled or removed to enhance security." "Review and remove or disable the service if present."
    }
} catch {
    Add-Result "5.10" "Error" "Could not check 'Microsoft FTP Service'. Error: $($_.Exception.Message)" "Ensure 'Microsoft FTP Service (FTPSVC)' is set to 'Disabled' or 'Not Installed'" "System Services" "Medium" "Medium" "Ensure the Microsoft FTP Service is disabled or removed to enhance security." "Review and remove or disable the service if present."
}

try {
    # Ensure 'Microsoft iSCSI Initiator Service (MSiSCSI)' is set to 'Disabled'
    $MSiSCSI = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\MSiSCSI" -Name "Start" -ErrorAction Stop
    if ($MSiSCSI.Start -eq 4) {
        Add-Result "5.11" "Pass" "Microsoft iSCSI Initiator Service is set to Disabled." "Ensure 'Microsoft iSCSI Initiator Service (MSiSCSI)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Microsoft iSCSI Initiator Service is disabled to enhance security." "Review and disable the service if enabled."
    } elseif ($MSiSCSI.Start -eq $null) {
        Add-Result "5.11" "Null" "Microsoft iSCSI Initiator Service setting is missing." "Ensure 'Microsoft iSCSI Initiator Service (MSiSCSI)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Microsoft iSCSI Initiator Service is disabled to enhance security." "Review and disable the service if enabled."
    } else {
        Add-Result "5.11" "Fail" "Microsoft iSCSI Initiator Service is not set to Disabled." "Ensure 'Microsoft iSCSI Initiator Service (MSiSCSI)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Microsoft iSCSI Initiator Service is disabled to enhance security." "Review and disable the service if enabled."
    }
} catch {
    Add-Result "5.11" "Error" "Could not check 'Microsoft iSCSI Initiator Service'. Error: $($_.Exception.Message)" "Ensure 'Microsoft iSCSI Initiator Service (MSiSCSI)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Microsoft iSCSI Initiator Service is disabled to enhance security." "Review and disable the service if enabled."
}

try {
    # Ensure 'OpenSSH SSH Server (sshd)' is set to 'Disabled' or 'Not Installed'
    $sshd = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\sshd" -Name "Start" -ErrorAction SilentlyContinue
    if ($sshd -eq $null) {
        Add-Result "5.12" "Pass" "OpenSSH SSH Server is not installed." "Ensure 'OpenSSH SSH Server (sshd)' is set to 'Disabled' or 'Not Installed'" "System Services" "Medium" "Medium" "Ensure the OpenSSH SSH Server is disabled or removed to enhance security." "Review and remove or disable the service if present."
    } elseif ($sshd.Start -eq 4) {
        Add-Result "5.12" "Pass" "OpenSSH SSH Server is set to Disabled." "Ensure 'OpenSSH SSH Server (sshd)' is set to 'Disabled' or 'Not Installed'" "System Services" "Medium" "Medium" "Ensure the OpenSSH SSH Server is disabled or removed to enhance security." "Review and remove or disable the service if present."
    } else {
        Add-Result "5.12" "Fail" "OpenSSH SSH Server is not set to Disabled or removed." "Ensure 'OpenSSH SSH Server (sshd)' is set to 'Disabled' or 'Not Installed'" "System Services" "Medium" "Medium" "Ensure the OpenSSH SSH Server is disabled or removed to enhance security." "Review and remove or disable the service if present."
    }
} catch {
    Add-Result "5.12" "Error" "Could not check 'OpenSSH SSH Server'. Error: $($_.Exception.Message)" "Ensure 'OpenSSH SSH Server (sshd)' is set to 'Disabled' or 'Not Installed'" "System Services" "Medium" "Medium" "Ensure the OpenSSH SSH Server is disabled or removed to enhance security." "Review and remove or disable the service if present."
}

try {
    # Ensure 'Peer Name Resolution Protocol (PNRPsvc)' is set to 'Disabled'
    $PNRPsvc = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\PNRPsvc" -Name "Start" -ErrorAction Stop
    if ($PNRPsvc.Start -eq 4) {
        Add-Result "5.13" "Pass" "Peer Name Resolution Protocol is set to Disabled." "Ensure 'Peer Name Resolution Protocol (PNRPsvc)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Peer Name Resolution Protocol is disabled to enhance security." "Review and disable the service if enabled."
    } else {
        Add-Result "5.13" "Fail" "Peer Name Resolution Protocol is not set to Disabled." "Ensure 'Peer Name Resolution Protocol (PNRPsvc)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Peer Name Resolution Protocol is disabled to enhance security." "Review and disable the service if enabled."
    }
} catch {
    Add-Result "5.13" "Error" "Could not check 'Peer Name Resolution Protocol'. Error: $($_.Exception.Message)" "Ensure 'Peer Name Resolution Protocol (PNRPsvc)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Peer Name Resolution Protocol is disabled to enhance security." "Review and disable the service if enabled."
}

try {
    # Ensure 'Peer Networking Grouping (p2psvc)' is set to 'Disabled'
    $p2psvc = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\p2psvc" -Name "Start" -ErrorAction Stop
    if ($p2psvc.Start -eq 4) {
        Add-Result "5.14" "Pass" "Peer Networking Grouping is set to Disabled." "Ensure 'Peer Networking Grouping (p2psvc)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Peer Networking Grouping is disabled to enhance security." "Review and disable the service if enabled."
    } else {
        Add-Result "5.14" "Fail" "Peer Networking Grouping is not set to Disabled." "Ensure 'Peer Networking Grouping (p2psvc)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Peer Networking Grouping is disabled to enhance security." "Review and disable the service if enabled."
    }
} catch {
    Add-Result "5.14" "Error" "Could not check 'Peer Networking Grouping'. Error: $($_.Exception.Message)" "Ensure 'Peer Networking Grouping (p2psvc)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Peer Networking Grouping is disabled to enhance security." "Review and disable the service if enabled."
}

try {
    # Ensure 'Peer Networking Identity Manager (p2pimsvc)' is set to 'Disabled'
    $p2pimsvc = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\p2pimsvc" -Name "Start" -ErrorAction Stop
    if ($p2pimsvc.Start -eq 4) {
        Add-Result "5.15" "Pass" "Peer Networking Identity Manager is set to Disabled." "Ensure 'Peer Networking Identity Manager (p2pimsvc)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Peer Networking Identity Manager is disabled to enhance security." "Review and disable the service if enabled."
    } else {
        Add-Result "5.15" "Fail" "Peer Networking Identity Manager is not set to Disabled." "Ensure 'Peer Networking Identity Manager (p2pimsvc)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Peer Networking Identity Manager is disabled to enhance security." "Review and disable the service if enabled."
    }
} catch {
    Add-Result "5.15" "Error" "Could not check 'Peer Networking Identity Manager'. Error: $($_.Exception.Message)" "Ensure 'Peer Networking Identity Manager (p2pimsvc)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Peer Networking Identity Manager is disabled to enhance security." "Review and disable the service if enabled."
}

try {
    # Ensure 'PNRP Machine Name Publication Service (PNRPAutoReg)' is set to 'Disabled'
    $PNRPAutoReg = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\PNRPAutoReg" -Name "Start" -ErrorAction Stop
    if ($PNRPAutoReg.Start -eq 4) {
        Add-Result "5.16" "Pass" "PNRP Machine Name Publication Service is set to Disabled." "Ensure 'PNRP Machine Name Publication Service (PNRPAutoReg)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the PNRP Machine Name Publication Service is disabled to enhance security." "Review and disable the service if enabled."
    } else {
        Add-Result "5.16" "Fail" "PNRP Machine Name Publication Service is not set to Disabled." "Ensure 'PNRP Machine Name Publication Service (PNRPAutoReg)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the PNRP Machine Name Publication Service is disabled to enhance security." "Review and disable the service if enabled."
    }
} catch {
    Add-Result "5.16" "Error" "Could not check 'PNRP Machine Name Publication Service'. Error: $($_.Exception.Message)" "Ensure 'PNRP Machine Name Publication Service (PNRPAutoReg)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the PNRP Machine Name Publication Service is disabled to enhance security." "Review and disable the service if enabled."
}

try {
    # Ensure 'Print Spooler (Spooler)' is set to 'Disabled'
    $Spooler = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Spooler" -Name "Start" -ErrorAction Stop
    if ($Spooler.Start -eq 4) {
        Add-Result "5.17" "Pass" "Print Spooler is set to Disabled." "Ensure 'Print Spooler (Spooler)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Print Spooler is disabled to enhance security." "Review and disable the service if enabled."
    } else {
        Add-Result "5.17" "Fail" "Print Spooler is not set to Disabled." "Ensure 'Print Spooler (Spooler)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Print Spooler is disabled to enhance security." "Review and disable the service if enabled."
    }
} catch {
    Add-Result "5.17" "Error" "Could not check 'Print Spooler'. Error: $($_.Exception.Message)" "Ensure 'Print Spooler (Spooler)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Print Spooler is disabled to enhance security." "Review and disable the service if enabled."
}

try {
    # Ensure 'Problem Reports and Solutions Control Panel Support (wercplsupport)' is set to 'Disabled'
    $wercplsupport = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\wercplsupport" -Name "Start" -ErrorAction Stop
    if ($wercplsupport.Start -eq 4) {
        Add-Result "5.18" "Pass" "Problem Reports and Solutions Control Panel Support is set to Disabled." "Ensure 'Problem Reports and Solutions Control Panel Support (wercplsupport)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Problem Reports and Solutions Control Panel Support is disabled to enhance security." "Review and disable the service if enabled."
    } else {
        Add-Result "5.18" "Fail" "Problem Reports and Solutions Control Panel Support is not set to Disabled." "Ensure 'Problem Reports and Solutions Control Panel Support (wercplsupport)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Problem Reports and Solutions Control Panel Support is disabled to enhance security." "Review and disable the service if enabled."
    }
} catch {
    Add-Result "5.18" "Error" "Could not check 'Problem Reports and Solutions Control Panel Support'. Error: $($_.Exception.Message)" "Ensure 'Problem Reports and Solutions Control Panel Support (wercplsupport)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Problem Reports and Solutions Control Panel Support is disabled to enhance security." "Review and disable the service if enabled."
}

try {
    # Ensure 'Remote Access Auto Connection Manager (RasAuto)' is set to 'Disabled'
    $RasAuto = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\RasAuto" -Name "Start" -ErrorAction Stop
    if ($RasAuto.Start -eq 4) {
        Add-Result "5.19" "Pass" "Remote Access Auto Connection Manager is set to Disabled." "Ensure 'Remote Access Auto Connection Manager (RasAuto)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Remote Access Auto Connection Manager is disabled to enhance security." "Review and disable the service if enabled."
    } else {
        Add-Result "5.19" "Fail" "Remote Access Auto Connection Manager is not set to Disabled." "Ensure 'Remote Access Auto Connection Manager (RasAuto)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Remote Access Auto Connection Manager is disabled to enhance security." "Review and disable the service if enabled."
    }
} catch {
    Add-Result "5.19" "Error" "Could not check 'Remote Access Auto Connection Manager'. Error: $($_.Exception.Message)" "Ensure 'Remote Access Auto Connection Manager (RasAuto)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Remote Access Auto Connection Manager is disabled to enhance security." "Review and disable the service if enabled."
}

try {
    # Ensure 'Remote Desktop Configuration (SessionEnv)' is set to 'Disabled'
    $SessionEnv = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\SessionEnv" -Name "Start" -ErrorAction Stop
    if ($SessionEnv.Start -eq 4) {
        Add-Result "5.20" "Pass" "Remote Desktop Configuration is set to Disabled." "Ensure 'Remote Desktop Configuration (SessionEnv)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Remote Desktop Configuration is disabled to enhance security." "Review and disable the service if enabled."
    } else {
        Add-Result "5.20" "Fail" "Remote Desktop Configuration is not set to Disabled." "Ensure 'Remote Desktop Configuration (SessionEnv)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Remote Desktop Configuration is disabled to enhance security." "Review and disable the service if enabled."
    }
} catch {
    Add-Result "5.20" "Error" "Could not check 'Remote Desktop Configuration'. Error: $($_.Exception.Message)" "Ensure 'Remote Desktop Configuration (SessionEnv)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Remote Desktop Configuration is disabled to enhance security." "Review and disable the service if enabled."
}

try {
    # Ensure 'Remote Desktop Services (TermService)' is set to 'Disabled'
    $TermService = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\TermService" -Name "Start" -ErrorAction Stop
    if ($TermService.Start -eq 4) {
        Add-Result "5.21" "Pass" "Remote Desktop Services is set to Disabled." "Ensure 'Remote Desktop Services (TermService)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Remote Desktop Services is disabled to enhance security." "Review and disable the service if enabled."
    } else {
        Add-Result "5.21" "Fail" "Remote Desktop Services is not set to Disabled." "Ensure 'Remote Desktop Services (TermService)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Remote Desktop Services is disabled to enhance security." "Review and disable the service if enabled."
    }
} catch {
    Add-Result "5.21" "Error" "Could not check 'Remote Desktop Services'. Error: $($_.Exception.Message)" "Ensure 'Remote Desktop Services (TermService)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Remote Desktop Services is disabled to enhance security." "Review and disable the service if enabled."
}

try {
    # Ensure 'Remote Desktop Services UserMode Port Redirector (UmRdpService)' is set to 'Disabled'
    $UmRdpService = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\UmRdpService" -Name "Start" -ErrorAction Stop
    if ($UmRdpService.Start -eq 4) {
        Add-Result "5.22" "Pass" "Remote Desktop Services UserMode Port Redirector is set to Disabled." "Ensure 'Remote Desktop Services UserMode Port Redirector (UmRdpService)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Remote Desktop Services UserMode Port Redirector is disabled to enhance security." "Review and disable the service if enabled."
    } else {
        Add-Result "5.22" "Fail" "Remote Desktop Services UserMode Port Redirector is not set to Disabled." "Ensure 'Remote Desktop Services UserMode Port Redirector (UmRdpService)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Remote Desktop Services UserMode Port Redirector is disabled to enhance security." "Review and disable the service if enabled."
    }
} catch {
    Add-Result "5.22" "Error" "Could not check 'Remote Desktop Services UserMode Port Redirector'. Error: $($_.Exception.Message)" "Ensure 'Remote Desktop Services UserMode Port Redirector (UmRdpService)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Remote Desktop Services UserMode Port Redirector is disabled to enhance security." "Review and disable the service if enabled."
}

try {
    # Ensure 'Remote Procedure Call (RPC) Locator (RpcLocator)' is set to 'Disabled'
    $RpcLocator = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\RpcLocator" -Name "Start" -ErrorAction Stop
    if ($RpcLocator.Start -eq 4) {
        Add-Result "5.23" "Pass" "Remote Procedure Call Locator is set to Disabled." "Ensure 'Remote Procedure Call (RPC) Locator (RpcLocator)' is set to 'Disabled'" "System Services" "Medium" "Medium" "Ensure the Remote Procedure Call Locator is disabled to enhance security." "Review and disable the service if enabled."
    } else {
        Add-Result "5.23" "Fail" "Remote Procedure Call Locator is not set to Disabled." "Ensure 'Remote Procedure Call (RPC) Locator (RpcLocator)' is set to 'Disabled'" "System Services" "Medium" "Medium" "Ensure the Remote Procedure Call Locator is disabled to enhance security." "Review and disable the service if enabled."
    }
} catch {
    Add-Result "5.23" "Error" "Could not check 'Remote Procedure Call Locator'. Error: $($_.Exception.Message)" "Ensure 'Remote Procedure Call (RPC) Locator (RpcLocator)' is set to 'Disabled'" "System Services" "Medium" "Medium" "Ensure the Remote Procedure Call Locator is disabled to enhance security." "Review and disable the service if enabled."
}

try {
    # Ensure 'Remote Registry (RemoteRegistry)' is set to 'Disabled'
    $RemoteRegistry = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\RemoteRegistry" -Name "Start" -ErrorAction Stop
    if ($RemoteRegistry.Start -eq 4) {
        Add-Result "5.24" "Pass" "Remote Registry is set to Disabled." "Ensure 'Remote Registry (RemoteRegistry)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Remote Registry is disabled to enhance security." "Review and disable the service if enabled."
    } else {
        Add-Result "5.24" "Fail" "Remote Registry is not set to Disabled." "Ensure 'Remote Registry (RemoteRegistry)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Remote Registry is disabled to enhance security." "Review and disable the service if enabled."
    }
} catch {
    Add-Result "5.24" "Error" "Could not check 'Remote Registry'. Error: $($_.Exception.Message)" "Ensure 'Remote Registry (RemoteRegistry)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Remote Registry is disabled to enhance security." "Review and disable the service if enabled."
}

try {
    # Ensure 'Routing and Remote Access (RemoteAccess)' is set to 'Disabled'
    $RemoteAccess = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\RemoteAccess" -Name "Start" -ErrorAction Stop
    if ($RemoteAccess.Start -eq 4) {
        Add-Result "5.25" "Pass" "Routing and Remote Access is set to Disabled." "Ensure 'Routing and Remote Access (RemoteAccess)' is set to 'Disabled'" "System Services" "Medium" "Medium" "Ensure the Routing and Remote Access is disabled to enhance security." "Review and disable the service if enabled."
    } else {
        Add-Result "5.25" "Fail" "Routing and Remote Access is not set to Disabled." "Ensure 'Routing and Remote Access (RemoteAccess)' is set to 'Disabled'" "System Services" "Medium" "Medium" "Ensure the Routing and Remote Access is disabled to enhance security." "Review and disable the service if enabled."
    }
} catch {
    Add-Result "5.25" "Error" "Could not check 'Routing and Remote Access'. Error: $($_.Exception.Message)" "Ensure 'Routing and Remote Access (RemoteAccess)' is set to 'Disabled'" "System Services" "Medium" "Medium" "Ensure the Routing and Remote Access is disabled to enhance security." "Review and disable the service if enabled."
}

try {
    # Ensure 'Server (LanmanServer)' is set to 'Disabled'
    $LanmanServer = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer" -Name "Start" -ErrorAction Stop
    if ($LanmanServer.Start -eq 4) {
        Add-Result "5.26" "Pass" "Server (LanmanServer) is set to Disabled." "Ensure 'Server (LanmanServer)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Server (LanmanServer) service is disabled to enhance security." "Review and disable the service if enabled."
    } else {
        Add-Result "5.26" "Fail" "Server (LanmanServer) is not set to Disabled." "Ensure 'Server (LanmanServer)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Server (LanmanServer) service is disabled to enhance security." "Review and disable the service if enabled."
    }
} catch {
    Add-Result "5.26" "Error" "Could not check 'Server (LanmanServer)'. Error: $($_.Exception.Message)" "Ensure 'Server (LanmanServer)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Server (LanmanServer) service is disabled to enhance security." "Review and disable the service if enabled."
}

try {
    # Ensure 'Simple TCP/IP Services (simptcp)' is set to 'Disabled' or 'Not Installed'
    $simptcp = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\simptcp" -Name "Start" -ErrorAction SilentlyContinue
    if ($simptcp -eq $null) {
        Add-Result "5.27" "Pass" "Simple TCP/IP Services is not installed." "Ensure 'Simple TCP/IP Services (simptcp)' is set to 'Disabled' or 'Not Installed'" "System Services" "Medium" "Medium" "Ensure the Simple TCP/IP Services is disabled or removed to enhance security." "Review and remove or disable the service if present."
    } elseif ($simptcp.Start -eq 4) {
        Add-Result "5.27" "Pass" "Simple TCP/IP Services is set to Disabled." "Ensure 'Simple TCP/IP Services (simptcp)' is set to 'Disabled' or 'Not Installed'" "System Services" "Medium" "Medium" "Ensure the Simple TCP/IP Services is disabled or removed to enhance security." "Review and remove or disable the service if present."
    } else {
        Add-Result "5.27" "Fail" "Simple TCP/IP Services is not set to Disabled or removed." "Ensure 'Simple TCP/IP Services (simptcp)' is set to 'Disabled' or 'Not Installed'" "System Services" "Medium" "Medium" "Ensure the Simple TCP/IP Services is disabled or removed to enhance security." "Review and remove or disable the service if present."
    }
} catch {
    Add-Result "5.27" "Error" "Could not check 'Simple TCP/IP Services'. Error: $($_.Exception.Message)" "Ensure 'Simple TCP/IP Services (simptcp)' is set to 'Disabled' or 'Not Installed'" "System Services" "Medium" "Medium" "Ensure the Simple TCP/IP Services is disabled or removed to enhance security." "Review and remove or disable the service if present."
}

try {
    # Ensure 'SNMP Service (SNMP)' is set to 'Disabled' or 'Not Installed'
    $SNMP = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\SNMP" -Name "Start" -ErrorAction SilentlyContinue
    if ($SNMP -eq $null) {
        Add-Result "5.28" "Pass" "SNMP Service is not installed." "Ensure 'SNMP Service (SNMP)' is set to 'Disabled' or 'Not Installed'" "System Services" "Low" "Low" "Ensure the SNMP Service is disabled or removed to enhance security." "Review and remove or disable the service if present."
    } elseif ($SNMP.Start -eq 4) {
        Add-Result "5.28" "Pass" "SNMP Service is set to Disabled." "Ensure 'SNMP Service (SNMP)' is set to 'Disabled' or 'Not Installed'" "System Services" "Low" "Low" "Ensure the SNMP Service is disabled or removed to enhance security." "Review and remove or disable the service if present."
    } else {
        Add-Result "5.28" "Fail" "SNMP Service is not set to Disabled or removed." "Ensure 'SNMP Service (SNMP)' is set to 'Disabled' or 'Not Installed'" "System Services" "Low" "Low" "Ensure the SNMP Service is disabled or removed to enhance security." "Review and remove or disable the service if present."
    }
} catch {
    Add-Result "5.28" "Error" "Could not check 'SNMP Service'. Error: $($_.Exception.Message)" "Ensure 'SNMP Service (SNMP)' is set to 'Disabled' or 'Not Installed'" "System Services" "Low" "Low" "Ensure the SNMP Service is disabled or removed to enhance security." "Review and remove or disable the service if present."
}

try {
    # Ensure 'Special Administration Console Helper (sacsvr)' is set to 'Disabled' or 'Not Installed'
    $sacsvr = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\sacsvr" -Name "Start" -ErrorAction SilentlyContinue
    if ($sacsvr -eq $null) {
        Add-Result "5.29" "Pass" "Special Administration Console Helper is not installed." "Ensure 'Special Administration Console Helper (sacsvr)' is set to 'Disabled' or 'Not Installed'" "System Services" "Medium" "Medium" "Ensure the Special Administration Console Helper is disabled or removed to enhance security." "Review and remove or disable the service if present."
    } elseif ($sacsvr.Start -eq 4) {
        Add-Result "5.29" "Pass" "Special Administration Console Helper is set to Disabled." "Ensure 'Special Administration Console Helper (sacsvr)' is set to 'Disabled' or 'Not Installed'" "System Services" "Medium" "Medium" "Ensure the Special Administration Console Helper is disabled or removed to enhance security." "Review and remove or disable the service if present."
    } else {
        Add-Result "5.29" "Fail" "Special Administration Console Helper is not set to Disabled or removed." "Ensure 'Special Administration Console Helper (sacsvr)' is set to 'Disabled' or 'Not Installed'" "System Services" "Medium" "Medium" "Ensure the Special Administration Console Helper is disabled or removed to enhance security." "Review and remove or disable the service if present."
    }
} catch {
    Add-Result "5.29" "Error" "Could not check 'Special Administration Console Helper'. Error: $($_.Exception.Message)" "Ensure 'Special Administration Console Helper (sacsvr)' is set to 'Disabled' or 'Not Installed'" "System Services" "Medium" "Medium" "Ensure the Special Administration Console Helper is disabled or removed to enhance security." "Review and remove or disable the service if present."
}

try {
    # Ensure 'SSDP Discovery (SSDPSRV)' is set to 'Disabled'
    $SSDPSRV = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\SSDPSRV" -Name "Start" -ErrorAction Stop
    if ($SSDPSRV.Start -eq 4) {
        Add-Result "5.30" "Pass" "SSDP Discovery is set to Disabled." "Ensure 'SSDP Discovery (SSDPSRV)' is set to 'Disabled'" "System Services" "Medium" "Medium" "Ensure the SSDP Discovery is disabled to enhance security." "Review and disable the service if enabled."
    } else {
        Add-Result "5.30" "Fail" "SSDP Discovery is not set to Disabled." "Ensure 'SSDP Discovery (SSDPSRV)' is set to 'Disabled'" "System Services" "Medium" "Medium" "Ensure the SSDP Discovery is disabled to enhance security." "Review and disable the service if enabled."
    }
} catch {
    Add-Result "5.30" "Error" "Could not check 'SSDP Discovery'. Error: $($_.Exception.Message)" "Ensure 'SSDP Discovery (SSDPSRV)' is set to 'Disabled'" "System Services" "Medium" "Medium" "Ensure the SSDP Discovery is disabled to enhance security." "Review and disable the service if enabled."
}

try {
    # Ensure 'UPnP Device Host (upnphost)' is set to 'Disabled'
    $upnphost = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\upnphost" -Name "Start" -ErrorAction Stop
    if ($upnphost.Start -eq 4) {
        Add-Result "5.31" "Pass" "UPnP Device Host is set to Disabled." "Ensure 'UPnP Device Host (upnphost)' is set to 'Disabled'" "System Services" "Medium" "Medium" "Ensure the UPnP Device Host is disabled to enhance security." "Review and disable the service if enabled."
    } else {
        Add-Result "5.31" "Fail" "UPnP Device Host is not set to Disabled." "Ensure 'UPnP Device Host (upnphost)' is set to 'Disabled'" "System Services" "Medium" "Medium" "Ensure the UPnP Device Host is disabled to enhance security." "Review and disable the service if enabled."
    }
} catch {
    Add-Result "5.31" "Error" "Could not check 'UPnP Device Host'. Error: $($_.Exception.Message)" "Ensure 'UPnP Device Host (upnphost)' is set to 'Disabled'" "System Services" "Medium" "Medium" "Ensure the UPnP Device Host is disabled to enhance security." "Review and disable the service if enabled."
}

try {
    # Ensure 'Web Management Service (WMSvc)' is set to 'Disabled' or 'Not Installed'
    $WMSvc = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\WMSvc" -Name "Start" -ErrorAction SilentlyContinue
    if ($WMSvc -eq $null) {
        Add-Result "5.32" "Pass" "Web Management Service is not installed." "Ensure 'Web Management Service (WMSvc)' is set to 'Disabled' or 'Not Installed'" "System Services" "Medium" "Medium" "Ensure the Web Management Service is disabled or removed to enhance security." "Review and remove or disable the service if present."
    } elseif ($WMSvc.Start -eq 4) {
        Add-Result "5.32" "Pass" "Web Management Service is set to Disabled." "Ensure 'Web Management Service (WMSvc)' is set to 'Disabled' or 'Not Installed'" "System Services" "Medium" "Medium" "Ensure the Web Management Service is disabled or removed to enhance security." "Review and remove or disable the service if present."
    } else {
        Add-Result "5.32" "Fail" "Web Management Service is not set to Disabled or removed." "Ensure 'Web Management Service (WMSvc)' is set to 'Disabled' or 'Not Installed'" "System Services" "Medium" "Medium" "Ensure the Web Management Service is disabled or removed to enhance security." "Review and remove or disable the service if present."
    }
} catch {
    Add-Result "5.32" "Error" "Could not check 'Web Management Service'. Error: $($_.Exception.Message)" "Ensure 'Web Management Service (WMSvc)' is set to 'Disabled' or 'Not Installed'" "System Services" "Medium" "Medium" "Ensure the Web Management Service is disabled or removed to enhance security." "Review and remove or disable the service if present."
}

try {
    # Ensure 'Windows Error Reporting Service (WerSvc)' is set to 'Disabled'
    $WerSvc = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\WerSvc" -Name "Start" -ErrorAction Stop
    if ($WerSvc.Start -eq 4) {
        Add-Result "5.33" "Pass" "Windows Error Reporting Service is set to Disabled." "Ensure 'Windows Error Reporting Service (WerSvc)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Windows Error Reporting Service is disabled to enhance security." "Review and disable the service if enabled."
    } else {
        Add-Result "5.33" "Fail" "Windows Error Reporting Service is not set to Disabled." "Ensure 'Windows Error Reporting Service (WerSvc)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Windows Error Reporting Service is disabled to enhance security." "Review and disable the service if enabled."
    }
} catch {
    Add-Result "5.33" "Error" "Could not check 'Windows Error Reporting Service'. Error: $($_.Exception.Message)" "Ensure 'Windows Error Reporting Service (WerSvc)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Windows Error Reporting Service is disabled to enhance security." "Review and disable the service if enabled."
}

try {
    # Ensure 'Windows Event Collector (Wecsvc)' is set to 'Disabled'
    $Wecsvc = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Wecsvc" -Name "Start" -ErrorAction Stop
    if ($Wecsvc.Start -eq 4) {
        Add-Result "5.34" "Pass" "Windows Event Collector is set to Disabled." "Ensure 'Windows Event Collector (Wecsvc)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Windows Event Collector is disabled to enhance security." "Review and disable the service if enabled."
    } else {
        Add-Result "5.34" "Fail" "Windows Event Collector is not set to Disabled." "Ensure 'Windows Event Collector (Wecsvc)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Windows Event Collector is disabled to enhance security." "Review and disable the service if enabled."
    }
} catch {
    Add-Result "5.34" "Error" "Could not check 'Windows Event Collector'. Error: $($_.Exception.Message)" "Ensure 'Windows Event Collector (Wecsvc)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Windows Event Collector is disabled to enhance security." "Review and disable the service if enabled."
}

try {
    # Ensure 'Windows Media Player Network Sharing Service (WMPNetworkSvc)' is set to 'Disabled' or 'Not Installed'
    $WMPNetworkSvc = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\WMPNetworkSvc" -Name "Start" -ErrorAction SilentlyContinue
    if ($WMPNetworkSvc -eq $null) {
        Add-Result "5.35" "Pass" "Windows Media Player Network Sharing Service is not installed." "Ensure 'Windows Media Player Network Sharing Service (WMPNetworkSvc)' is set to 'Disabled' or 'Not Installed'" "System Services" "Medium" "Medium" "Ensure the Windows Media Player Network Sharing Service is disabled or removed to enhance security." "Review and remove or disable the service if present."
    } elseif ($WMPNetworkSvc.Start -eq 4) {
        Add-Result "5.35" "Pass" "Windows Media Player Network Sharing Service is set to Disabled." "Ensure 'Windows Media Player Network Sharing Service (WMPNetworkSvc)' is set to 'Disabled' or 'Not Installed'" "System Services" "Medium" "Medium" "Ensure the Windows Media Player Network Sharing Service is disabled or removed to enhance security." "Review and remove or disable the service if present."
    } else {
        Add-Result "5.35" "Fail" "Windows Media Player Network Sharing Service is not set to Disabled or removed." "Ensure 'Windows Media Player Network Sharing Service (WMPNetworkSvc)' is set to 'Disabled' or 'Not Installed'" "System Services" "Medium" "Medium" "Ensure the Windows Media Player Network Sharing Service is disabled or removed to enhance security." "Review and remove or disable the service if present."
    }
} catch {
    Add-Result "5.35" "Error" "Could not check 'Windows Media Player Network Sharing Service'. Error: $($_.Exception.Message)" "Ensure 'Windows Media Player Network Sharing Service (WMPNetworkSvc)' is set to 'Disabled' or 'Not Installed'" "System Services" "Medium" "Medium" "Ensure the Windows Media Player Network Sharing Service is disabled or removed to enhance security." "Review and remove or disable the service if present."
}

try {
    # Ensure 'Windows Mobile Hotspot Service (icssvc)' is set to 'Disabled'
    $icssvc = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\icssvc" -Name "Start" -ErrorAction Stop
    if ($icssvc.Start -eq 4) {
        Add-Result "5.36" "Pass" "Windows Mobile Hotspot Service is set to Disabled." "Ensure 'Windows Mobile Hotspot Service (icssvc)' is set to 'Disabled'" "System Services" "Medium" "Medium" "Ensure the Windows Mobile Hotspot Service is disabled to enhance security." "Review and disable the service if enabled."
    } else {
        Add-Result "5.36" "Fail" "Windows Mobile Hotspot Service is not set to Disabled." "Ensure 'Windows Mobile Hotspot Service (icssvc)' is set to 'Disabled'" "System Services" "Medium" "Medium" "Ensure the Windows Mobile Hotspot Service is disabled to enhance security." "Review and disable the service if enabled."
    }
} catch {
    Add-Result "5.36" "Error" "Could not check 'Windows Mobile Hotspot Service'. Error: $($_.Exception.Message)" "Ensure 'Windows Mobile Hotspot Service (icssvc)' is set to 'Disabled'" "System Services" "Medium" "Medium" "Ensure the Windows Mobile Hotspot Service is disabled to enhance security." "Review and disable the service if enabled."
}

try {
    # Ensure 'Windows Push Notifications System Service (WpnService)' is set to 'Disabled'
    $WpnService = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\WpnService" -Name "Start" -ErrorAction Stop
    if ($WpnService.Start -eq 4) {
        Add-Result "5.37" "Pass" "Windows Push Notifications System Service is set to Disabled." "Ensure 'Windows Push Notifications System Service (WpnService)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Windows Push Notifications System Service is disabled to enhance security." "Review and disable the service if enabled."
    } else {
        Add-Result "5.37" "Fail" "Windows Push Notifications System Service is not set to Disabled." "Ensure 'Windows Push Notifications System Service (WpnService)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Windows Push Notifications System Service is disabled to enhance security." "Review and disable the service if enabled."
    }
} catch {
    Add-Result "5.37" "Error" "Could not check 'Windows Push Notifications System Service'. Error: $($_.Exception.Message)" "Ensure 'Windows Push Notifications System Service (WpnService)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Windows Push Notifications System Service is disabled to enhance security." "Review and disable the service if enabled."
}

try {
    # Ensure 'Windows PushToInstall Service (PushToInstall)' is set to 'Disabled'
    $PushToInstall = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\PushToInstall" -Name "Start" -ErrorAction Stop
    if ($PushToInstall.Start -eq 4) {
        Add-Result "5.38" "Pass" "Windows PushToInstall Service is set to Disabled." "Ensure 'Windows PushToInstall Service (PushToInstall)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Windows PushToInstall Service is disabled to enhance security." "Review and disable the service if enabled."
    } else {
        Add-Result "5.38" "Fail" "Windows PushToInstall Service is not set to Disabled." "Ensure 'Windows PushToInstall Service (PushToInstall)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Windows PushToInstall Service is disabled to enhance security." "Review and disable the service if enabled."
    }
} catch {
    Add-Result "5.38" "Error" "Could not check 'Windows PushToInstall Service'. Error: $($_.Exception.Message)" "Ensure 'Windows PushToInstall Service (PushToInstall)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Windows PushToInstall Service is disabled to enhance security." "Review and disable the service if enabled."
}

try {
    # Ensure 'Windows Remote Management (WS-Management) (WinRM)' is set to 'Disabled'
    $WinRM = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\WinRM" -Name "Start" -ErrorAction Stop
    if ($WinRM.Start -eq 4) {
        Add-Result "5.39" "Pass" "Windows Remote Management (WS-Management) is set to Disabled." "Ensure 'Windows Remote Management (WS-Management) (WinRM)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Windows Remote Management (WinRM) is disabled to enhance security." "Review and disable the service if enabled."
    } else {
        Add-Result "5.39" "Fail" "Windows Remote Management (WS-Management) is not set to Disabled." "Ensure 'Windows Remote Management (WS-Management) (WinRM)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Windows Remote Management (WinRM) is disabled to enhance security." "Review and disable the service if enabled."
    }
} catch {
    Add-Result "5.39" "Error" "Could not check 'Windows Remote Management (WinRM)'. Error: $($_.Exception.Message)" "Ensure 'Windows Remote Management (WS-Management) (WinRM)' is set to 'Disabled'" "System Services" "Low" "Low" "Ensure the Windows Remote Management (WinRM) is disabled to enhance security." "Review and disable the service if enabled."
}

try {
    # Ensure 'World Wide Web Publishing Service (W3SVC)' is set to 'Disabled' or 'Not Installed'
    $W3SVC = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\W3SVC" -Name "Start" -ErrorAction SilentlyContinue
    if ($W3SVC -eq $null) {
        Add-Result "5.40" "Pass" "World Wide Web Publishing Service is not installed." "Ensure 'World Wide Web Publishing Service (W3SVC)' is set to 'Disabled' or 'Not Installed'" "System Services" "Medium" "Medium" "Ensure the World Wide Web Publishing Service is disabled or removed to enhance security." "Review and remove or disable the service if present."
    } elseif ($W3SVC.Start -eq 4) {
        Add-Result "5.40" "Pass" "World Wide Web Publishing Service is set to Disabled." "Ensure 'World Wide Web Publishing Service (W3SVC)' is set to 'Disabled' or 'Not Installed'" "System Services" "Medium" "Medium" "Ensure the World Wide Web Publishing Service is disabled or removed to enhance security." "Review and remove or disable the service if present."
    } else {
        Add-Result "5.40" "Fail" "World Wide Web Publishing Service is not set to Disabled or removed." "Ensure 'World Wide Web Publishing Service (W3SVC)' is set to 'Disabled' or 'Not Installed'" "System Services" "Medium" "Medium" "Ensure the World Wide Web Publishing Service is disabled or removed to enhance security." "Review and remove or disable the service if present."
    }
} catch {
    Add-Result "5.40" "Error" "Could not check 'World Wide Web Publishing Service'. Error: $($_.Exception.Message)" "Ensure 'World Wide Web Publishing Service (W3SVC)' is set to 'Disabled' or 'Not Installed'" "System Services" "Medium" "Medium" "Ensure the World Wide Web Publishing Service is disabled or removed to enhance security." "Review and remove or disable the service if present."
}

try {
    # Ensure 'Xbox Accessory Management Service (XboxGipSvc)' is set to 'Disabled'
    $XboxGipSvc = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\XboxGipSvc" -Name "Start" -ErrorAction Stop
    if ($XboxGipSvc.Start -eq 4) {
        Add-Result "5.41" "Pass" "Xbox Accessory Management Service is set to Disabled." "Ensure 'Xbox Accessory Management Service (XboxGipSvc)' is set to 'Disabled'" "System Services" "Medium" "Medium" "Ensure the Xbox Accessory Management Service is disabled to enhance security." "Review and disable the service if enabled."
    } else {
        Add-Result "5.41" "Fail" "Xbox Accessory Management Service is not set to Disabled." "Ensure 'Xbox Accessory Management Service (XboxGipSvc)' is set to 'Disabled'" "System Services" "Medium" "Medium" "Ensure the Xbox Accessory Management Service is disabled to enhance security." "Review and disable the service if enabled."
    }
} catch {
    Add-Result "5.41" "Error" "Could not check 'Xbox Accessory Management Service'. Error: $($_.Exception.Message)" "Ensure 'Xbox Accessory Management Service (XboxGipSvc)' is set to 'Disabled'" "System Services" "Medium" "Medium" "Ensure the Xbox Accessory Management Service is disabled to enhance security." "Review and disable the service if enabled."
}

try {
    # Ensure 'Xbox Live Auth Manager (XblAuthManager)' is set to 'Disabled'
    $XblAuthManager = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\XblAuthManager" -Name "Start" -ErrorAction Stop
    if ($XblAuthManager.Start -eq 4) {
        Add-Result "5.42" "Pass" "Xbox Live Auth Manager is set to Disabled." "Ensure 'Xbox Live Auth Manager (XblAuthManager)' is set to 'Disabled'" "System Services" "Medium" "Medium" "Ensure the Xbox Live Auth Manager is disabled to enhance security." "Review and disable the service if enabled."
    } else {
        Add-Result "5.42" "Fail" "Xbox Live Auth Manager is not set to Disabled." "Ensure 'Xbox Live Auth Manager (XblAuthManager)' is set to 'Disabled'" "System Services" "Medium" "Medium" "Ensure the Xbox Live Auth Manager is disabled to enhance security." "Review and disable the service if enabled."
    }
} catch {
    Add-Result "5.42" "Error" "Could not check 'Xbox Live Auth Manager'. Error: $($_.Exception.Message)" "Ensure 'Xbox Live Auth Manager (XblAuthManager)' is set to 'Disabled'" "System Services" "Medium" "Medium" "Ensure the Xbox Live Auth Manager is disabled to enhance security." "Review and disable the service if enabled."
}

try {
    # Ensure 'Xbox Live Game Save (XblGameSave)' is set to 'Disabled'
    $XblGameSave = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\XblGameSave" -Name "Start" -ErrorAction Stop
    if ($XblGameSave.Start -eq 4) {
        Add-Result "5.43" "Pass" "Xbox Live Game Save is set to Disabled." "Ensure 'Xbox Live Game Save (XblGameSave)' is set to 'Disabled'" "System Services" "Medium" "Medium" "Ensure the Xbox Live Game Save is disabled to enhance security." "Review and disable the service if enabled."
    } else {
        Add-Result "5.43" "Fail" "Xbox Live Game Save is not set to Disabled." "Ensure 'Xbox Live Game Save (XblGameSave)' is set to 'Disabled'" "System Services" "Medium" "Medium" "Ensure the Xbox Live Game Save is disabled to enhance security." "Review and disable the service if enabled."
    }
} catch {
    Add-Result "5.43" "Error" "Could not check 'Xbox Live Game Save'. Error: $($_.Exception.Message)" "Ensure 'Xbox Live Game Save (XblGameSave)' is set to 'Disabled'" "System Services" "Medium" "Medium" "Ensure the Xbox Live Game Save is disabled to enhance security." "Review and disable the service if enabled."
}

try {
    # Ensure 'Xbox Live Networking Service (XboxNetApiSvc)' is set to 'Disabled'
    $XboxNetApiSvc = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\XboxNetApiSvc" -Name "Start" -ErrorAction Stop
    if ($XboxNetApiSvc.Start -eq 4) {
        Add-Result "5.44" "Pass" "Xbox Live Networking Service is set to Disabled." "Ensure 'Xbox Live Networking Service (XboxNetApiSvc)' is set to 'Disabled'" "System Services" "Medium" "Medium" "Ensure the Xbox Live Networking Service is disabled to enhance security." "Review and disable the service if enabled."
    } else {
        Add-Result "5.44" "Fail" "Xbox Live Networking Service is not set to Disabled." "Ensure 'Xbox Live Networking Service (XboxNetApiSvc)' is set to 'Disabled'" "System Services" "Medium" "Medium" "Ensure the Xbox Live Networking Service is disabled to enhance security." "Review and disable the service if enabled."
    }
} catch {
    Add-Result "5.44" "Error" "Could not check 'Xbox Live Networking Service'. Error: $($_.Exception.Message)" "Ensure 'Xbox Live Networking Service (XboxNetApiSvc)' is set to 'Disabled'" "System Services" "Medium" "Medium" "Ensure the Xbox Live Networking Service is disabled to enhance security." "Review and disable the service if enabled."
}



#9th
try {
    # Ensure 'Windows Firewall: Private: Firewall state' is set to 'On (recommended)'
    $firewallPrivateState = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\PrivateProfile" -Name "EnableFirewall" -ErrorAction Stop
    if ($firewallPrivateState.EnableFirewall -eq 1) {
        Add-Result "9.2.1" "Pass" "Windows Firewall: Private: Firewall state is set to On." "Ensure 'Windows Firewall: Private: Firewall state' is set to 'On (recommended)'" "Windows Firewall" "Medium" "Medium" "Ensure the Windows Firewall Private profile is enabled." "Review and enable the Windows Firewall Private profile if disabled."
    } else {
        Add-Result "9.2.1" "Fail" "Windows Firewall: Private: Firewall state is not set to On." "Ensure 'Windows Firewall: Private: Firewall state' is set to 'On (recommended)'" "Windows Firewall" "Medium" "Medium" "Ensure the Windows Firewall Private profile is enabled." "Review and enable the Windows Firewall Private profile if disabled."
    }
} catch {
    Add-Result "9.2.1" "Error" "Could not check 'Windows Firewall: Private: Firewall state'. Error: $($_.Exception.Message)" "Ensure 'Windows Firewall: Private: Firewall state' is set to 'On (recommended)'" "Windows Firewall" "Medium" "Medium" "Ensure the Windows Firewall Private profile is enabled." "Review and enable the Windows Firewall Private profile if disabled."
}

try {
    # Ensure 'Windows Firewall: Private: Inbound connections' is set to 'Block (default)'
    $firewallPrivateInbound = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\PrivateProfile" -Name "DefaultInboundAction" -ErrorAction Stop
    if ($firewallPrivateInbound.DefaultInboundAction -eq 1) {
        Add-Result "9.2.2" "Pass" "Windows Firewall: Private: Inbound connections is set to Block." "Ensure 'Windows Firewall: Private: Inbound connections' is set to 'Block (default)'" "Windows Firewall" "Medium" "Medium" "Ensure the Windows Firewall Private profile blocks inbound connections." "Review and set inbound connections to Block if necessary."
    } else {
        Add-Result "9.2.2" "Fail" "Windows Firewall: Private: Inbound connections is not set to Block." "Ensure 'Windows Firewall: Private: Inbound connections' is set to 'Block (default)'" "Windows Firewall" "Medium" "Medium" "Ensure the Windows Firewall Private profile blocks inbound connections." "Review and set inbound connections to Block if necessary."
    }
} catch {
    Add-Result "9.2.2" "Error" "Could not check 'Windows Firewall: Private: Inbound connections'. Error: $($_.Exception.Message)" "Ensure 'Windows Firewall: Private: Inbound connections' is set to 'Block (default)'" "Windows Firewall" "Medium" "Medium" "Ensure the Windows Firewall Private profile blocks inbound connections." "Review and set inbound connections to Block if necessary."
}

try {
    # Ensure 'Windows Firewall: Private: Settings: Display a notification' is set to 'No'
    $firewallPrivateNotification = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\PrivateProfile" -Name "DisableNotifications" -ErrorAction Stop
    if ($firewallPrivateNotification.DisableNotifications -eq 1) {
        Add-Result "9.2.3" "Pass" "Windows Firewall: Private: Display a notification is set to No." "Ensure 'Windows Firewall: Private: Settings: Display a notification' is set to 'No'" "Windows Firewall" "Low" "Low" "Ensure notifications are disabled for the Windows Firewall Private profile." "Review and disable notifications if necessary."
    } else {
        Add-Result "9.2.3" "Fail" "Windows Firewall: Private: Display a notification is not set to No." "Ensure 'Windows Firewall: Private: Settings: Display a notification' is set to 'No'" "Windows Firewall" "Low" "Low" "Ensure notifications are disabled for the Windows Firewall Private profile." "Review and disable notifications if necessary."
    }
} catch {
    Add-Result "9.2.3" "Error" "Could not check 'Windows Firewall: Private: Display a notification'. Error: $($_.Exception.Message)" "Ensure 'Windows Firewall: Private: Settings: Display a notification' is set to 'No'" "Windows Firewall" "Low" "Low" "Ensure notifications are disabled for the Windows Firewall Private profile." "Review and disable notifications if necessary."
}

try {
    # Ensure 'Windows Firewall: Private: Logging: Name' is set to '%SystemRoot%\System32\logfiles\firewall\privatefw.log'
    $firewallPrivateLogName = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\PrivateProfile\Logging" -Name "LogFilePath" -ErrorAction Stop
    if ($firewallPrivateLogName.LogFilePath -eq "%SystemRoot%\System32\logfiles\firewall\privatefw.log") {
        Add-Result "9.2.4" "Pass" "Windows Firewall: Private: Logging Name is set correctly." "Ensure 'Windows Firewall: Private: Logging: Name' is set to '%SystemRoot%\System32\logfiles\firewall\privatefw.log'" "Windows Firewall" "Medium" "Medium" "Ensure the log file name is set correctly for the Windows Firewall Private profile." "Review and set the log file name if necessary."
    } else {
        Add-Result "9.2.4" "Fail" "Windows Firewall: Private: Logging Name is not set correctly." "Ensure 'Windows Firewall: Private: Logging: Name' is set to '%SystemRoot%\System32\logfiles\firewall\privatefw.log'" "Windows Firewall" "Medium" "Medium" "Ensure the log file name is set correctly for the Windows Firewall Private profile." "Review and set the log file name if necessary."
    }
} catch {
    Add-Result "9.2.4" "Error" "Could not check 'Windows Firewall: Private: Logging: Name'. Error: $($_.Exception.Message)" "Ensure 'Windows Firewall: Private: Logging: Name' is set to '%SystemRoot%\System32\logfiles\firewall\privatefw.log'" "Windows Firewall" "Medium" "Medium" "Ensure the log file name is set correctly for the Windows Firewall Private profile." "Review and set the log file name if necessary."
}

try {
    # Ensure 'Windows Firewall: Private: Logging: Size limit (KB)' is set to '16,384 KB or greater'
    $firewallPrivateLogSize = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\PrivateProfile\Logging" -Name "LogMaxSizeKilobytes" -ErrorAction Stop
    if ($firewallPrivateLogSize.LogMaxSizeKilobytes -ge 16384) {
        Add-Result "9.2.5" "Pass" "Windows Firewall: Private: Logging Size limit is set to 16,384 KB or greater." "Ensure 'Windows Firewall: Private: Logging: Size limit (KB)' is set to '16,384 KB or greater'" "Windows Firewall" "Medium" "Medium" "Ensure the log size limit is configured correctly for the Windows Firewall Private profile." "Review and increase the log size limit if necessary."
    } else {
        Add-Result "9.2.5" "Fail" "Windows Firewall: Private: Logging Size limit is less than 16,384 KB." "Ensure 'Windows Firewall: Private: Logging: Size limit (KB)' is set to '16,384 KB or greater'" "Windows Firewall" "Medium" "Medium" "Ensure the log size limit is configured correctly for the Windows Firewall Private profile." "Review and increase the log size limit if necessary."
    }
} catch {
    Add-Result "9.2.5" "Error" "Could not check 'Windows Firewall: Private: Logging: Size limit'. Error: $($_.Exception.Message)" "Ensure 'Windows Firewall: Private: Logging: Size limit (KB)' is set to '16,384 KB or greater'" "Windows Firewall" "Medium" "Medium" "Ensure the log size limit is configured correctly for the Windows Firewall Private profile." "Review and increase the log size limit if necessary."
}

try {
    # Ensure 'Windows Firewall: Private: Logging: Log dropped packets' is set to 'Yes'
    $firewallPrivateLogDropped = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\PrivateProfile\Logging" -Name "LogDroppedPackets" -ErrorAction Stop
    if ($firewallPrivateLogDropped.LogDroppedPackets -eq 1) {
        Add-Result "9.2.6" "Pass" "Windows Firewall: Private: Log dropped packets is set to Yes." "Ensure 'Windows Firewall: Private: Logging: Log dropped packets' is set to 'Yes'" "Windows Firewall" "Medium" "Medium" "Ensure logging of dropped packets is enabled for the Windows Firewall Private profile." "Review and enable logging of dropped packets if necessary."
    } else {
        Add-Result "9.2.6" "Fail" "Windows Firewall: Private: Log dropped packets is not set to Yes." "Ensure 'Windows Firewall: Private: Logging: Log dropped packets' is set to 'Yes'" "Windows Firewall" "Medium" "Medium" "Ensure logging of dropped packets is enabled for the Windows Firewall Private profile." "Review and enable logging of dropped packets if necessary."
    }
} catch {
    Add-Result "9.2.6" "Error" "Could not check 'Windows Firewall: Private: Logging: Log dropped packets'. Error: $($_.Exception.Message)" "Ensure 'Windows Firewall: Private: Logging: Log dropped packets' is set to 'Yes'" "Windows Firewall" "Medium" "Medium" "Ensure logging of dropped packets is enabled for the Windows Firewall Private profile." "Review and enable logging of dropped packets if necessary."
}

try {
    # Ensure 'Windows Firewall: Private: Logging: Log successful connections' is set to 'Yes'
    $firewallPrivateLogSuccessful = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\PrivateProfile\Logging" -Name "LogSuccessfulConnections" -ErrorAction Stop
    if ($firewallPrivateLogSuccessful.LogSuccessfulConnections -eq 1) {
        Add-Result "9.2.7" "Pass" "Windows Firewall: Private: Log successful connections is set to Yes." "Ensure 'Windows Firewall: Private: Logging: Log successful connections' is set to 'Yes'" "Windows Firewall" "Medium" "Medium" "Ensure logging of successful connections is enabled for the Windows Firewall Private profile." "Review and enable logging of successful connections if necessary."
    } else {
        Add-Result "9.2.7" "Fail" "Windows Firewall: Private: Log successful connections is not set to Yes." "Ensure 'Windows Firewall: Private: Logging: Log successful connections' is set to 'Yes'" "Windows Firewall" "Medium" "Medium" "Ensure logging of successful connections is enabled for the Windows Firewall Private profile." "Review and enable logging of successful connections if necessary."
    }
} catch {
    Add-Result "9.2.7" "Error" "Could not check 'Windows Firewall: Private: Logging: Log successful connections'. Error: $($_.Exception.Message)" "Ensure 'Windows Firewall: Private: Logging: Log successful connections' is set to 'Yes'" "Windows Firewall" "Medium" "Medium" "Ensure logging of successful connections is enabled for the Windows Firewall Private profile." "Review and enable logging of successful connections if necessary."
}

try {
    # Ensure 'Windows Firewall: Public: Firewall state' is set to 'On (recommended)'
    $firewallPublicState = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\PublicProfile" -Name "EnableFirewall" -ErrorAction Stop
    if ($firewallPublicState.EnableFirewall -eq 1) {
        Add-Result "9.3.1" "Pass" "Windows Firewall: Public: Firewall state is set to On." "Ensure 'Windows Firewall: Public: Firewall state' is set to 'On (recommended)'" "Windows Firewall" "Medium" "Medium" "Ensure the Windows Firewall Public profile is enabled." "Review and enable the Windows Firewall Public profile if disabled."
    } else {
        Add-Result "9.3.1" "Fail" "Windows Firewall: Public: Firewall state is not set to On." "Ensure 'Windows Firewall: Public: Firewall state' is set to 'On (recommended)'" "Windows Firewall" "Medium" "Medium" "Ensure the Windows Firewall Public profile is enabled." "Review and enable the Windows Firewall Public profile if disabled."
    }
} catch {
    Add-Result "9.3.1" "Error" "Could not check 'Windows Firewall: Public: Firewall state'. Error: $($_.Exception.Message)" "Ensure 'Windows Firewall: Public: Firewall state' is set to 'On (recommended)'" "Windows Firewall" "Medium" "Medium" "Ensure the Windows Firewall Public profile is enabled." "Review and enable the Windows Firewall Public profile if disabled."
}

try {
    # Ensure 'Windows Firewall: Public: Inbound connections' is set to 'Block (default)'
    $firewallPublicInbound = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\PublicProfile" -Name "DefaultInboundAction" -ErrorAction Stop
    if ($firewallPublicInbound.DefaultInboundAction -eq 1) {
        Add-Result "9.3.2" "Pass" "Windows Firewall: Public: Inbound connections is set to Block." "Ensure 'Windows Firewall: Public: Inbound connections' is set to 'Block (default)'" "Windows Firewall" "Medium" "Medium" "Ensure the Windows Firewall Public profile blocks inbound connections." "Review and set inbound connections to Block if necessary."
    } else {
        Add-Result "9.3.2" "Fail" "Windows Firewall: Public: Inbound connections is not set to Block." "Ensure 'Windows Firewall: Public: Inbound connections' is set to 'Block (default)'" "Windows Firewall" "Medium" "Medium" "Ensure the Windows Firewall Public profile blocks inbound connections." "Review and set inbound connections to Block if necessary."
    }
} catch {
    Add-Result "9.3.2" "Error" "Could not check 'Windows Firewall: Public: Inbound connections'. Error: $($_.Exception.Message)" "Ensure 'Windows Firewall: Public: Inbound connections' is set to 'Block (default)'" "Windows Firewall" "Medium" "Medium" "Ensure the Windows Firewall Public profile blocks inbound connections." "Review and set inbound connections to Block if necessary."
}

try {
    # Ensure 'Windows Firewall: Public: Settings: Display a notification' is set to 'No'
    $firewallPublicNotification = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\PublicProfile" -Name "DisableNotifications" -ErrorAction Stop
    if ($firewallPublicNotification.DisableNotifications -eq 1) {
        Add-Result "9.3.3" "Pass" "Windows Firewall: Public: Display a notification is set to No." "Ensure 'Windows Firewall: Public: Settings: Display a notification' is set to 'No'" "Windows Firewall" "Low" "Low" "Ensure notifications are disabled for the Windows Firewall Public profile." "Review and disable notifications if necessary."
    } else {
        Add-Result "9.3.3" "Fail" "Windows Firewall: Public: Display a notification is not set to No." "Ensure 'Windows Firewall: Public: Settings: Display a notification' is set to 'No'" "Windows Firewall" "Low" "Low" "Ensure notifications are disabled for the Windows Firewall Public profile." "Review and disable notifications if necessary."
    }
} catch {
    Add-Result "9.3.3" "Error" "Could not check 'Windows Firewall: Public: Display a notification'. Error: $($_.Exception.Message)" "Ensure 'Windows Firewall: Public: Settings: Display a notification' is set to 'No'" "Windows Firewall" "Low" "Low" "Ensure notifications are disabled for the Windows Firewall Public profile." "Review and disable notifications if necessary."
}

try {
    # Ensure 'Windows Firewall: Public: Settings: Apply local firewall rules' is set to 'No'
    $firewallPublicLocalRules = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\PublicProfile" -Name "AllowLocalPolicyMerge" -ErrorAction Stop
    if ($firewallPublicLocalRules.AllowLocalPolicyMerge -eq 0) {
        Add-Result "9.3.4" "Pass" "Windows Firewall: Public: Apply local firewall rules is set to No." "Ensure 'Windows Firewall: Public: Settings: Apply local firewall rules' is set to 'No'" "Windows Firewall" "Medium" "Medium" "Ensure local firewall rules are not applied for the Windows Firewall Public profile." "Review and disable the application of local firewall rules if necessary."
    } else {
        Add-Result "9.3.4" "Fail" "Windows Firewall: Public: Apply local firewall rules is not set to No." "Ensure 'Windows Firewall: Public: Settings: Apply local firewall rules' is set to 'No'" "Windows Firewall" "Medium" "Medium" "Ensure local firewall rules are not applied for the Windows Firewall Public profile." "Review and disable the application of local firewall rules if necessary."
    }
} catch {
    Add-Result "9.3.4" "Error" "Could not check 'Windows Firewall: Public: Apply local firewall rules'. Error: $($_.Exception.Message)" "Ensure 'Windows Firewall: Public: Settings: Apply local firewall rules' is set to 'No'" "Windows Firewall" "Medium" "Medium" "Ensure local firewall rules are not applied for the Windows Firewall Public profile." "Review and disable the application of local firewall rules if necessary."
}

try {
    # Ensure 'Windows Firewall: Public: Settings: Apply local connection security rules' is set to 'No'
    $firewallPublicLocalSecRules = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\PublicProfile" -Name "AllowLocalIPsecPolicyMerge" -ErrorAction Stop
    if ($firewallPublicLocalSecRules.AllowLocalIPsecPolicyMerge -eq 0) {
        Add-Result "9.3.5" "Pass" "Windows Firewall: Public: Apply local connection security rules is set to No." "Ensure 'Windows Firewall: Public: Settings: Apply local connection security rules' is set to 'No'" "Windows Firewall" "Medium" "Medium" "Ensure local connection security rules are not applied for the Windows Firewall Public profile." "Review and disable the application of local connection security rules if necessary."
    } else {
        Add-Result "9.3.5" "Fail" "Windows Firewall: Public: Apply local connection security rules is not set to No." "Ensure 'Windows Firewall: Public: Settings: Apply local connection security rules' is set to 'No'" "Windows Firewall" "Medium" "Medium" "Ensure local connection security rules are not applied for the Windows Firewall Public profile." "Review and disable the application of local connection security rules if necessary."
    }
} catch {
    Add-Result "9.3.5" "Error" "Could not check 'Windows Firewall: Public: Apply local connection security rules'. Error: $($_.Exception.Message)" "Ensure 'Windows Firewall: Public: Settings: Apply local connection security rules' is set to 'No'" "Windows Firewall" "Medium" "Medium" "Ensure local connection security rules are not applied for the Windows Firewall Public profile." "Review and disable the application of local connection security rules if necessary."
}

try {
    # Ensure 'Windows Firewall: Public: Logging: Name' is set to '%SystemRoot%\System32\logfiles\firewall\publicfw.log'
    $firewallPublicLogName = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\PublicProfile\Logging" -Name "LogFilePath" -ErrorAction Stop
    if ($firewallPublicLogName.LogFilePath -eq "%SystemRoot%\System32\logfiles\firewall\publicfw.log") {
        Add-Result "9.3.6" "Pass" "Windows Firewall: Public: Logging Name is set correctly." "Ensure 'Windows Firewall: Public: Logging: Name' is set to '%SystemRoot%\System32\logfiles\firewall\publicfw.log'" "Windows Firewall" "Medium" "Medium" "Ensure the log file name is set correctly for the Windows Firewall Public profile." "Review and set the log file name if necessary."
    } else {
        Add-Result "9.3.6" "Fail" "Windows Firewall: Public: Logging Name is not set correctly." "Ensure 'Windows Firewall: Public: Logging: Name' is set to '%SystemRoot%\System32\logfiles\firewall\publicfw.log'" "Windows Firewall" "Medium" "Medium" "Ensure the log file name is set correctly for the Windows Firewall Public profile." "Review and set the log file name if necessary."
    }
} catch {
    Add-Result "9.3.6" "Error" "Could not check 'Windows Firewall: Public: Logging: Name'. Error: $($_.Exception.Message)" "Ensure 'Windows Firewall: Public: Logging: Name' is set to '%SystemRoot%\System32\logfiles\firewall\publicfw.log'" "Windows Firewall" "Medium" "Medium" "Ensure the log file name is set correctly for the Windows Firewall Public profile." "Review and set the log file name if necessary."
}

try {
    # Ensure 'Windows Firewall: Public: Logging: Size limit (KB)' is set to '16,384 KB or greater'
    $firewallPublicLogSize = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\PublicProfile\Logging" -Name "LogMaxSizeKilobytes" -ErrorAction Stop
    if ($firewallPublicLogSize.LogMaxSizeKilobytes -ge 16384) {
        Add-Result "9.3.7" "Pass" "Windows Firewall: Public: Logging Size limit is set to 16,384 KB or greater." "Ensure 'Windows Firewall: Public: Logging: Size limit (KB)' is set to '16,384 KB or greater'" "Windows Firewall" "Medium" "Medium" "Ensure the log size limit is configured correctly for the Windows Firewall Public profile." "Review and increase the log size limit if necessary."
    } else {
        Add-Result "9.3.7" "Fail" "Windows Firewall: Public: Logging Size limit is less than 16,384 KB." "Ensure 'Windows Firewall: Public: Logging: Size limit (KB)' is set to '16,384 KB or greater'" "Windows Firewall" "Medium" "Medium" "Ensure the log size limit is configured correctly for the Windows Firewall Public profile." "Review and increase the log size limit if necessary."
    }
} catch {
    Add-Result "9.3.7" "Error" "Could not check 'Windows Firewall: Public: Logging: Size limit'. Error: $($_.Exception.Message)" "Ensure 'Windows Firewall: Public: Logging: Size limit (KB)' is set to '16,384 KB or greater'" "Windows Firewall" "Medium" "Medium" "Ensure the log size limit is configured correctly for the Windows Firewall Public profile." "Review and increase the log size limit if necessary."
}

try {
    # Ensure 'Windows Firewall: Public: Logging: Log dropped packets' is set to 'Yes'
    $firewallPublicLogDropped = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\PublicProfile\Logging" -Name "LogDroppedPackets" -ErrorAction Stop
    if ($firewallPublicLogDropped.LogDroppedPackets -eq 1) {
        Add-Result "9.3.8" "Pass" "Windows Firewall: Public: Log dropped packets is set to Yes." "Ensure 'Windows Firewall: Public: Logging: Log dropped packets' is set to 'Yes'" "Windows Firewall" "Medium" "Medium" "Ensure logging of dropped packets is enabled for the Windows Firewall Public profile." "Review and enable logging of dropped packets if necessary."
    } else {
        Add-Result "9.3.8" "Fail" "Windows Firewall: Public: Log dropped packets is not set to Yes." "Ensure 'Windows Firewall: Public: Logging: Log dropped packets' is set to 'Yes'" "Windows Firewall" "Medium" "Medium" "Ensure logging of dropped packets is enabled for the Windows Firewall Public profile." "Review and enable logging of dropped packets if necessary."
    }
} catch {
    Add-Result "9.3.8" "Error" "Could not check 'Windows Firewall: Public: Logging: Log dropped packets'. Error: $($_.Exception.Message)" "Ensure 'Windows Firewall: Public: Logging: Log dropped packets' is set to 'Yes'" "Windows Firewall" "Medium" "Medium" "Ensure logging of dropped packets is enabled for the Windows Firewall Public profile." "Review and enable logging of dropped packets if necessary."
}

try {
    # Ensure 'Windows Firewall: Public: Logging: Log successful connections' is set to 'Yes'
    $firewallPublicLogSuccessful = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\PublicProfile\Logging" -Name "LogSuccessfulConnections" -ErrorAction Stop
    if ($firewallPublicLogSuccessful.LogSuccessfulConnections -eq 1) {
        Add-Result "9.3.9" "Pass" "Windows Firewall: Public: Log successful connections is set to Yes." "Ensure 'Windows Firewall: Public: Logging: Log successful connections' is set to 'Yes'" "Windows Firewall" "Medium" "Medium" "Ensure logging of successful connections is enabled for the Windows Firewall Public profile." "Review and enable logging of successful connections if necessary."
    } else {
        Add-Result "9.3.9" "Fail" "Windows Firewall: Public: Log successful connections is not set to Yes." "Ensure 'Windows Firewall: Public: Logging: Log successful connections' is set to 'Yes'" "Windows Firewall" "Medium" "Medium" "Ensure logging of successful connections is enabled for the Windows Firewall Public profile." "Review and enable logging of successful connections if necessary."
    }
} catch {
    Add-Result "9.3.9" "Error" "Could not check 'Windows Firewall: Public: Logging: Log successful connections'. Error: $($_.Exception.Message)" "Ensure 'Windows Firewall: Public: Logging: Log successful connections' is set to 'Yes'" "Windows Firewall" "Medium" "Medium" "Ensure logging of successful connections is enabled for the Windows Firewall Public profile." "Review and enable logging of successful connections if necessary."
}

# 17th
try {
    # Ensure 'Audit Credential Validation' is set to 'Success and Failure'
    $auditCredentialValidation = (Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Audit\Configuration\Subcategories" -Name "{0CCE9224-69AE-11D9-BED3-505054503030}" -ErrorAction Stop).Value
    if ($auditCredentialValidation -contains "Success" -and $auditCredentialValidation -contains "Failure") {
        Add-Result "17.1.1" "Pass" "Audit Credential Validation is set to Success and Failure." "Ensure 'Audit Credential Validation' is set to 'Success and Failure'" "Audit Policy" "High" "High" "Ensure the Audit Credential Validation setting is configured correctly to capture all relevant events." "Review and configure Audit Credential Validation to include Success and Failure."
    } else {
        Add-Result "17.1.1" "Fail" "Audit Credential Validation is not set to Success and Failure." "Ensure 'Audit Credential Validation' is set to 'Success and Failure'" "Audit Policy" "High" "High" "Ensure the Audit Credential Validation setting is configured correctly to capture all relevant events." "Review and configure Audit Credential Validation to include Success and Failure."
    }
} catch {
    Add-Result "17.1.1" "Error" "Could not check 'Audit Credential Validation'. Error: $($_.Exception.Message)" "Ensure 'Audit Credential Validation' is set to 'Success and Failure'" "Audit Policy" "High" "High" "Ensure the Audit Credential Validation setting is configured correctly to capture all relevant events." "Review and configure Audit Credential Validation to include Success and Failure."
}

try {
    # Ensure 'Audit Application Group Management' is set to 'Success and Failure'
    $auditAppGroupManagement = (Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Audit\Configuration\Subcategories" -Name "{0CCE9225-69AE-11D9-BED3-505054503030}" -ErrorAction Stop).Value
    if ($auditAppGroupManagement -contains "Success" -and $auditAppGroupManagement -contains "Failure") {
        Add-Result "17.2.1" "Pass" "Audit Application Group Management is set to Success and Failure." "Ensure 'Audit Application Group Management' is set to 'Success and Failure'" "Audit Policy" "High" "High" "Ensure the Audit Application Group Management setting is configured correctly." "Review and configure Audit Application Group Management to include Success and Failure."
    } else {
        Add-Result "17.2.1" "Fail" "Audit Application Group Management is not set to Success and Failure." "Ensure 'Audit Application Group Management' is set to 'Success and Failure'" "Audit Policy" "High" "High" "Ensure the Audit Application Group Management setting is configured correctly." "Review and configure Audit Application Group Management to include Success and Failure."
    }
} catch {
    Add-Result "17.2.1" "Error" "Could not check 'Audit Application Group Management'. Error: $($_.Exception.Message)" "Ensure 'Audit Application Group Management' is set to 'Success and Failure'" "Audit Policy" "High" "High" "Ensure the Audit Application Group Management setting is configured correctly." "Review and configure Audit Application Group Management to include Success and Failure."
}

try {
    # Ensure 'Audit Security Group Management' is set to include 'Success'
    $auditSecurityGroupManagement = (Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Audit\Configuration\Subcategories" -Name "{0CCE9226-69AE-11D9-BED3-505054503030}" -ErrorAction Stop).Value
    if ($auditSecurityGroupManagement -contains "Success") {
        Add-Result "17.2.2" "Pass" "Audit Security Group Management is set to include Success." "Ensure 'Audit Security Group Management' is set to include 'Success'" "Audit Policy" "Medium" "Medium" "Ensure the Audit Security Group Management setting is configured correctly." "Review and configure Audit Security Group Management to include Success."
    } else {
        Add-Result "17.2.2" "Fail" "Audit Security Group Management does not include Success." "Ensure 'Audit Security Group Management' is set to include 'Success'" "Audit Policy" "Medium" "Medium" "Ensure the Audit Security Group Management setting is configured correctly." "Review and configure Audit Security Group Management to include Success."
    }
} catch {
    Add-Result "17.2.2" "Error" "Could not check 'Audit Security Group Management'. Error: $($_.Exception.Message)" "Ensure 'Audit Security Group Management' is set to include 'Success'" "Audit Policy" "Medium" "Medium" "Ensure the Audit Security Group Management setting is configured correctly." "Review and configure Audit Security Group Management to include Success."
}

try {
    # Ensure 'Audit User Account Management' is set to 'Success and Failure'
    $auditUserAccountManagement = (Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Audit\Configuration\Subcategories" -Name "{0CCE9227-69AE-11D9-BED3-505054503030}" -ErrorAction Stop).Value
    if ($auditUserAccountManagement -contains "Success" -and $auditUserAccountManagement -contains "Failure") {
        Add-Result "17.2.3" "Pass" "Audit User Account Management is set to Success and Failure." "Ensure 'Audit User Account Management' is set to 'Success and Failure'" "Audit Policy" "High" "High" "Ensure the Audit User Account Management setting is configured correctly." "Review and configure Audit User Account Management to include Success and Failure."
    } else {
        Add-Result "17.2.3" "Fail" "Audit User Account Management is not set to Success and Failure." "Ensure 'Audit User Account Management' is set to 'Success and Failure'" "Audit Policy" "High" "High" "Ensure the Audit User Account Management setting is configured correctly." "Review and configure Audit User Account Management to include Success and Failure."
    }
} catch {
    Add-Result "17.2.3" "Error" "Could not check 'Audit User Account Management'. Error: $($_.Exception.Message)" "Ensure 'Audit User Account Management' is set to 'Success and Failure'" "Audit Policy" "High" "High" "Ensure the Audit User Account Management setting is configured correctly." "Review and configure Audit User Account Management to include Success and Failure."
}

try {
    # Ensure 'Audit PNP Activity' is set to include 'Success'
    $auditPNPActivity = (Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Audit\Configuration\Subcategories" -Name "{0CCE9228-69AE-11D9-BED3-505054503030}" -ErrorAction Stop).Value
    if ($auditPNPActivity -contains "Success") {
        Add-Result "17.3.1" "Pass" "Audit PNP Activity is set to include Success." "Ensure 'Audit PNP Activity' is set to include 'Success'" "Audit Policy" "Medium" "Medium" "Ensure the Audit PNP Activity setting is configured correctly." "Review and configure Audit PNP Activity to include Success."
    } else {
        Add-Result "17.3.1" "Fail" "Audit PNP Activity does not include Success." "Ensure 'Audit PNP Activity' is set to include 'Success'" "Audit Policy" "Medium" "Medium" "Ensure the Audit PNP Activity setting is configured correctly." "Review and configure Audit PNP Activity to include Success."
    }
} catch {
    Add-Result "17.3.1" "Error" "Could not check 'Audit PNP Activity'. Error: $($_.Exception.Message)" "Ensure 'Audit PNP Activity' is set to include 'Success'" "Audit Policy" "Medium" "Medium" "Ensure the Audit PNP Activity setting is configured correctly." "Review and configure Audit PNP Activity to include Success."
}

try {
    # Ensure 'Audit Process Creation' is set to include 'Success'
    $auditProcessCreation = (Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Audit\Configuration\Subcategories" -Name "{0CCE9229-69AE-11D9-BED3-505054503030}" -ErrorAction Stop).Value
    if ($auditProcessCreation -contains "Success") {
        Add-Result "17.3.2" "Pass" "Audit Process Creation is set to include Success." "Ensure 'Audit Process Creation' is set to include 'Success'" "Audit Policy" "Medium" "Medium" "Ensure the Audit Process Creation setting is configured correctly." "Review and configure Audit Process Creation to include Success."
    } else {
        Add-Result "17.3.2" "Fail" "Audit Process Creation does not include Success." "Ensure 'Audit Process Creation' is set to include 'Success'" "Audit Policy" "Medium" "Medium" "Ensure the Audit Process Creation setting is configured correctly." "Review and configure Audit Process Creation to include Success."
    }
} catch {
    Add-Result "17.3.2" "Error" "Could not check 'Audit Process Creation'. Error: $($_.Exception.Message)" "Ensure 'Audit Process Creation' is set to include 'Success'" "Audit Policy" "Medium" "Medium" "Ensure the Audit Process Creation setting is configured correctly." "Review and configure Audit Process Creation to include Success."
}

try {
    # Ensure 'Audit Account Lockout' is set to include 'Failure'
    $auditAccountLockout = (Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Audit\Configuration\Subcategories" -Name "{0CCE922A-69AE-11D9-BED3-505054503030}" -ErrorAction Stop).Value
    if ($auditAccountLockout -contains "Failure") {
        Add-Result "17.5.1" "Pass" "Audit Account Lockout is set to include Failure." "Ensure 'Audit Account Lockout' is set to include 'Failure'" "Audit Policy" "Medium" "Medium" "Ensure the Audit Account Lockout setting is configured correctly." "Review and configure Audit Account Lockout to include Failure."
    } else {
        Add-Result "17.5.1" "Fail" "Audit Account Lockout does not include Failure." "Ensure 'Audit Account Lockout' is set to include 'Failure'" "Audit Policy" "Medium" "Medium" "Ensure the Audit Account Lockout setting is configured correctly." "Review and configure Audit Account Lockout to include Failure."
    }
} catch {
    Add-Result "17.5.1" "Error" "Could not check 'Audit Account Lockout'. Error: $($_.Exception.Message)" "Ensure 'Audit Account Lockout' is set to include 'Failure'" "Audit Policy" "Medium" "Medium" "Ensure the Audit Account Lockout setting is configured correctly." "Review and configure Audit Account Lockout to include Failure."
}

try {
    # Ensure 'Audit Group Membership' is set to include 'Success'
    $auditGroupMembership = (Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Audit\Configuration\Subcategories" -Name "{0CCE922B-69AE-11D9-BED3-505054503030}" -ErrorAction Stop).Value
    if ($auditGroupMembership -contains "Success") {
        Add-Result "17.5.2" "Pass" "Audit Group Membership is set to include Success." "Ensure 'Audit Group Membership' is set to include 'Success'" "Audit Policy" "Medium" "Medium" "Ensure the Audit Group Membership setting is configured correctly." "Review and configure Audit Group Membership to include Success."
    } else {
        Add-Result "17.5.2" "Fail" "Audit Group Membership does not include Success." "Ensure 'Audit Group Membership' is set to include 'Success'" "Audit Policy" "Medium" "Medium" "Ensure the Audit Group Membership setting is configured correctly." "Review and configure Audit Group Membership to include Success."
    }
} catch {
    Add-Result "17.5.2" "Error" "Could not check 'Audit Group Membership'. Error: $($_.Exception.Message)" "Ensure 'Audit Group Membership' is set to include 'Success'" "Audit Policy" "Medium" "Medium" "Ensure the Audit Group Membership setting is configured correctly." "Review and configure Audit Group Membership to include Success."
}

try {
    # Ensure 'Audit Logoff' is set to include 'Success'
    $auditLogoff = (Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Audit\Configuration\Subcategories" -Name "{0CCE922C-69AE-11D9-BED3-505054503030}" -ErrorAction Stop).Value
    if ($auditLogoff -contains "Success") {
        Add-Result "17.5.3" "Pass" "Audit Logoff is set to include Success." "Ensure 'Audit Logoff' is set to include 'Success'" "Audit Policy" "Medium" "Medium" "Ensure the Audit Logoff setting is configured correctly." "Review and configure Audit Logoff to include Success."
    } else {
        Add-Result "17.5.3" "Fail" "Audit Logoff does not include Success." "Ensure 'Audit Logoff' is set to include 'Success'" "Audit Policy" "Medium" "Medium" "Ensure the Audit Logoff setting is configured correctly." "Review and configure Audit Logoff to include Success."
    }
} catch {
    Add-Result "17.5.3" "Error" "Could not check 'Audit Logoff'. Error: $($_.Exception.Message)" "Ensure 'Audit Logoff' is set to include 'Success'" "Audit Policy" "Medium" "Medium" "Ensure the Audit Logoff setting is configured correctly." "Review and configure Audit Logoff to include Success."
}

try {
    # Ensure 'Audit Logon' is set to 'Success and Failure'
    $auditLogon = (Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Audit\Configuration\Subcategories" -Name "{0CCE922D-69AE-11D9-BED3-505054503030}" -ErrorAction Stop).Value
    if ($auditLogon -contains "Success" -and $auditLogon -contains "Failure") {
        Add-Result "17.5.4" "Pass" "Audit Logon is set to Success and Failure." "Ensure 'Audit Logon' is set to 'Success and Failure'" "Audit Policy" "High" "High" "Ensure the Audit Logon setting is configured correctly." "Review and configure Audit Logon to include Success and Failure."
    } else {
        Add-Result "17.5.4" "Fail" "Audit Logon is not set to Success and Failure." "Ensure 'Audit Logon' is set to 'Success and Failure'" "Audit Policy" "High" "High" "Ensure the Audit Logon setting is configured correctly." "Review and configure Audit Logon to include Success and Failure."
    }
} catch {
    Add-Result "17.5.4" "Error" "Could not check 'Audit Logon'. Error: $($_.Exception.Message)" "Ensure 'Audit Logon' is set to 'Success and Failure'" "Audit Policy" "High" "High" "Ensure the Audit Logon setting is configured correctly." "Review and configure Audit Logon to include Success and Failure."
}

try {
    # Ensure 'Audit Other Logon/Logoff Events' is set to 'Success and Failure'
    $auditOtherLogonLogoff = (Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Audit\Configuration\Subcategories" -Name "{0CCE922E-69AE-11D9-BED3-505054503030}" -ErrorAction Stop).Value
    if ($auditOtherLogonLogoff -contains "Success" -and $auditOtherLogonLogoff -contains "Failure") {
        Add-Result "17.5.5" "Pass" "Audit Other Logon/Logoff Events is set to Success and Failure." "Ensure 'Audit Other Logon/Logoff Events' is set to 'Success and Failure'" "Audit Policy" "High" "High" "Ensure the Audit Other Logon/Logoff Events setting is configured correctly." "Review and configure Audit Other Logon/Logoff Events to include Success and Failure."
    } else {
        Add-Result "17.5.5" "Fail" "Audit Other Logon/Logoff Events is not set to Success and Failure." "Ensure 'Audit Other Logon/Logoff Events' is set to 'Success and Failure'" "Audit Policy" "High" "High" "Ensure the Audit Other Logon/Logoff Events setting is configured correctly." "Review and configure Audit Other Logon/Logoff Events to include Success and Failure."
    }
} catch {
    Add-Result "17.5.5" "Error" "Could not check 'Audit Other Logon/Logoff Events'. Error: $($_.Exception.Message)" "Ensure 'Audit Other Logon/Logoff Events' is set to 'Success and Failure'" "Audit Policy" "High" "High" "Ensure the Audit Other Logon/Logoff Events setting is configured correctly." "Review and configure Audit Other Logon/Logoff Events to include Success and Failure."
}

try {
    # Ensure 'Audit Special Logon' is set to include 'Success'
    $auditSpecialLogon = (Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Audit\Configuration\Subcategories" -Name "{0CCE922F-69AE-11D9-BED3-505054503030}" -ErrorAction Stop).Value
    if ($auditSpecialLogon -contains "Success") {
        Add-Result "17.5.6" "Pass" "Audit Special Logon is set to include Success." "Ensure 'Audit Special Logon' is set to include 'Success'" "Audit Policy" "Medium" "Medium" "Ensure the Audit Special Logon setting is configured correctly." "Review and configure Audit Special Logon to include Success."
    } else {
        Add-Result "17.5.6" "Fail" "Audit Special Logon does not include Success." "Ensure 'Audit Special Logon' is set to include 'Success'" "Audit Policy" "Medium" "Medium" "Ensure the Audit Special Logon setting is configured correctly." "Review and configure Audit Special Logon to include Success."
    }
} catch {
    Add-Result "17.5.6" "Error" "Could not check 'Audit Special Logon'. Error: $($_.Exception.Message)" "Ensure 'Audit Special Logon' is set to include 'Success'" "Audit Policy" "Medium" "Medium" "Ensure the Audit Special Logon setting is configured correctly." "Review and configure Audit Special Logon to include Success."
}

try {
    # Ensure 'Audit Detailed File Share' is set to include 'Failure'
    $auditDetailedFileShare = (Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Audit\Configuration\Subcategories" -Name "{0CCE9230-69AE-11D9-BED3-505054503030}" -ErrorAction Stop).Value
    if ($auditDetailedFileShare -contains "Failure") {
        Add-Result "17.6.1" "Pass" "Audit Detailed File Share is set to include Failure." "Ensure 'Audit Detailed File Share' is set to include 'Failure'" "Audit Policy" "Medium" "Medium" "Ensure the Audit Detailed File Share setting is configured correctly." "Review and configure Audit Detailed File Share to include Failure."
    } else {
        Add-Result "17.6.1" "Fail" "Audit Detailed File Share does not include Failure." "Ensure 'Audit Detailed File Share' is set to include 'Failure'" "Audit Policy" "Medium" "Medium" "Ensure the Audit Detailed File Share setting is configured correctly." "Review and configure Audit Detailed File Share to include Failure."
    }
} catch {
    Add-Result "17.6.1" "Error" "Could not check 'Audit Detailed File Share'. Error: $($_.Exception.Message)" "Ensure 'Audit Detailed File Share' is set to include 'Failure'" "Audit Policy" "Medium" "Medium" "Ensure the Audit Detailed File Share setting is configured correctly." "Review and configure Audit Detailed File Share to include Failure."
}

try {
    # Ensure 'Audit File Share' is set to 'Success and Failure'
    $auditFileShare = (Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Audit\Configuration\Subcategories" -Name "{0CCE9231-69AE-11D9-BED3-505054503030}" -ErrorAction Stop).Value
    if ($auditFileShare -contains "Success" -and $auditFileShare -contains "Failure") {
        Add-Result "17.6.2" "Pass" "Audit File Share is set to Success and Failure." "Ensure 'Audit File Share' is set to 'Success and Failure'" "Audit Policy" "High" "High" "Ensure the Audit File Share setting is configured correctly." "Review and configure Audit File Share to include Success and Failure."
    } else {
        Add-Result "17.6.2" "Fail" "Audit File Share is not set to Success and Failure." "Ensure 'Audit File Share' is set to 'Success and Failure'" "Audit Policy" "High" "High" "Ensure the Audit File Share setting is configured correctly." "Review and configure Audit File Share to include Success and Failure."
    }
} catch {
    Add-Result "17.6.2" "Error" "Could not check 'Audit File Share'. Error: $($_.Exception.Message)" "Ensure 'Audit File Share' is set to 'Success and Failure'" "Audit Policy" "High" "High" "Ensure the Audit File Share setting is configured correctly." "Review and configure Audit File Share to include Success and Failure."
}

try {
    # Ensure 'Audit Other Object Access Events' is set to 'Success and Failure'
    $auditOtherObjectAccess = (Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Audit\Configuration\Subcategories" -Name "{0CCE9232-69AE-11D9-BED3-505054503030}" -ErrorAction Stop).Value
    if ($auditOtherObjectAccess -contains "Success" -and $auditOtherObjectAccess -contains "Failure") {
        Add-Result "17.6.3" "Pass" "Audit Other Object Access Events is set to Success and Failure." "Ensure 'Audit Other Object Access Events' is set to 'Success and Failure'" "Audit Policy" "High" "High" "Ensure the Audit Other Object Access Events setting is configured correctly." "Review and configure Audit Other Object Access Events to include Success and Failure."
    } else {
        Add-Result "17.6.3" "Fail" "Audit Other Object Access Events is not set to Success and Failure." "Ensure 'Audit Other Object Access Events' is set to 'Success and Failure'" "Audit Policy" "High" "High" "Ensure the Audit Other Object Access Events setting is configured correctly." "Review and configure Audit Other Object Access Events to include Success and Failure."
    }
} catch {
    Add-Result "17.6.3" "Error" "Could not check 'Audit Other Object Access Events'. Error: $($_.Exception.Message)" "Ensure 'Audit Other Object Access Events' is set to 'Success and Failure'" "Audit Policy" "High" "High" "Ensure the Audit Other Object Access Events setting is configured correctly." "Review and configure Audit Other Object Access Events to include Success and Failure."
}

try {
    # Ensure 'Audit Removable Storage' is set to 'Success and Failure'
    $auditRemovableStorage = (Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Audit\Configuration\Subcategories" -Name "{0CCE9233-69AE-11D9-BED3-505054503030}" -ErrorAction Stop).Value
    if ($auditRemovableStorage -contains "Success" -and $auditRemovableStorage -contains "Failure") {
        Add-Result "17.6.4" "Pass" "Audit Removable Storage is set to Success and Failure." "Ensure 'Audit Removable Storage' is set to 'Success and Failure'" "Audit Policy" "High" "High" "Ensure the Audit Removable Storage setting is configured correctly." "Review and configure Audit Removable Storage to include Success and Failure."
    } else {
        Add-Result "17.6.4" "Fail" "Audit Removable Storage is not set to Success and Failure." "Ensure 'Audit Removable Storage' is set to 'Success and Failure'" "Audit Policy" "High" "High" "Ensure the Audit Removable Storage setting is configured correctly." "Review and configure Audit Removable Storage to include Success and Failure."
    }
} catch {
    Add-Result "17.6.4" "Error" "Could not check 'Audit Removable Storage'. Error: $($_.Exception.Message)" "Ensure 'Audit Removable Storage' is set to 'Success and Failure'" "Audit Policy" "High" "High" "Ensure the Audit Removable Storage setting is configured correctly." "Review and configure Audit Removable Storage to include Success and Failure."
}

try {
    # Ensure 'Audit Audit Policy Change' is set to include 'Success'
    $auditPolicyChange = (Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Audit\Configuration\Subcategories" -Name "{0CCE9234-69AE-11D9-BED3-505054503030}" -ErrorAction Stop).Value
    if ($auditPolicyChange -contains "Success") {
        Add-Result "17.7.1" "Pass" "Audit Audit Policy Change is set to include Success." "Ensure 'Audit Audit Policy Change' is set to include 'Success'" "Audit Policy" "Medium" "Medium" "Ensure the Audit Audit Policy Change setting is configured correctly." "Review and configure Audit Audit Policy Change to include Success."
    } else {
        Add-Result "17.7.1" "Fail" "Audit Audit Policy Change does not include Success." "Ensure 'Audit Audit Policy Change' is set to include 'Success'" "Audit Policy" "Medium" "Medium" "Ensure the Audit Audit Policy Change setting is configured correctly." "Review and configure Audit Audit Policy Change to include Success."
    }
} catch {
    Add-Result "17.7.1" "Error" "Could not check 'Audit Audit Policy Change'. Error: $($_.Exception.Message)" "Ensure 'Audit Audit Policy Change' is set to include 'Success'" "Audit Policy" "Medium" "Medium" "Ensure the Audit Audit Policy Change setting is configured correctly." "Review and configure Audit Audit Policy Change to include Success."
}

try {
    # Ensure 'Audit Sensitive Privilege Use' is set to 'Success and Failure'
    $auditSensitivePrivilegeUse = (Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Audit\Configuration\Subcategories" -Name "{0CCE9235-69AE-11D9-BED3-505054503030}" -ErrorAction Stop).Value
    if ($auditSensitivePrivilegeUse -contains "Success" -and $auditSensitivePrivilegeUse -contains "Failure") {
        Add-Result "17.8.1" "Pass" "Audit Sensitive Privilege Use is set to Success and Failure." "Ensure 'Audit Sensitive Privilege Use' is set to 'Success and Failure'" "Audit Policy" "High" "High" "Ensure the Audit Sensitive Privilege Use setting is configured correctly." "Review and configure Audit Sensitive Privilege Use to include Success and Failure."
    } else {
        Add-Result "17.8.1" "Fail" "Audit Sensitive Privilege Use is not set to Success and Failure." "Ensure 'Audit Sensitive Privilege Use' is set to 'Success and Failure'" "Audit Policy" "High" "High" "Ensure the Audit Sensitive Privilege Use setting is configured correctly." "Review and configure Audit Sensitive Privilege Use to include Success and Failure."
    }
} catch {
    Add-Result "17.8.1" "Error" "Could not check 'Audit Sensitive Privilege Use'. Error: $($_.Exception.Message)" "Ensure 'Audit Sensitive Privilege Use' is set to 'Success and Failure'" "Audit Policy" "High" "High" "Ensure the Audit Sensitive Privilege Use setting is configured correctly." "Review and configure Audit Sensitive Privilege Use to include Success and Failure."
}

try {
    # Ensure 'Audit IPsec Driver' is set to 'Success and Failure'
    $auditIPsecDriver = (Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Audit\Configuration\Subcategories" -Name "{0CCE9236-69AE-11D9-BED3-505054503030}" -ErrorAction Stop).Value
    if ($auditIPsecDriver -contains "Success" -and $auditIPsecDriver -contains "Failure") {
        Add-Result "17.9.1" "Pass" "Audit IPsec Driver is set to Success and Failure." "Ensure 'Audit IPsec Driver' is set to 'Success and Failure'" "Audit Policy" "High" "High" "Ensure the Audit IPsec Driver setting is configured correctly." "Review and configure Audit IPsec Driver to include Success and Failure."
    } else {
        Add-Result "17.9.1" "Fail" "Audit IPsec Driver is not set to Success and Failure." "Ensure 'Audit IPsec Driver' is set to 'Success and Failure'" "Audit Policy" "High" "High" "Ensure the Audit IPsec Driver setting is configured correctly." "Review and configure Audit IPsec Driver to include Success and Failure."
    }
} catch {
    Add-Result "17.9.1" "Error" "Could not check 'Audit IPsec Driver'. Error: $($_.Exception.Message)" "Ensure 'Audit IPsec Driver' is set to 'Success and Failure'" "Audit Policy" "High" "High" "Ensure the Audit IPsec Driver setting is configured correctly." "Review and configure Audit IPsec Driver to include Success and Failure."
}

try {
    # Ensure 'Audit Other System Events' is set to 'Success and Failure'
    $auditOtherSystemEvents = (Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Audit\Configuration\Subcategories" -Name "{0CCE9237-69AE-11D9-BED3-505054503030}" -ErrorAction Stop).Value
    if ($auditOtherSystemEvents -contains "Success" -and $auditOtherSystemEvents -contains "Failure") {
        Add-Result "17.9.2" "Pass" "Audit Other System Events is set to Success and Failure." "Ensure 'Audit Other System Events' is set to 'Success and Failure'" "Audit Policy" "High" "High" "Ensure the Audit Other System Events setting is configured correctly." "Review and configure Audit Other System Events to include Success and Failure."
    } else {
        Add-Result "17.9.2" "Fail" "Audit Other System Events is not set to Success and Failure." "Ensure 'Audit Other System Events' is set to 'Success and Failure'" "Audit Policy" "High" "High" "Ensure the Audit Other System Events setting is configured correctly." "Review and configure Audit Other System Events to include Success and Failure."
    }
} catch {
    Add-Result "17.9.2" "Error" "Could not check 'Audit Other System Events'. Error: $($_.Exception.Message)" "Ensure 'Audit Other System Events' is set to 'Success and Failure'" "Audit Policy" "High" "High" "Ensure the Audit Other System Events setting is configured correctly." "Review and configure Audit Other System Events to include Success and Failure."
}

try {
    # Ensure 'Audit Security State Change' is set to include 'Success'
    $auditSecurityStateChange = (Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Audit\Configuration\Subcategories" -Name "{0CCE9238-69AE-11D9-BED3-505054503030}" -ErrorAction Stop).Value
    if ($auditSecurityStateChange -contains "Success") {
        Add-Result "17.9.3" "Pass" "Audit Security State Change is set to include Success." "Ensure 'Audit Security State Change' is set to include 'Success'" "Audit Policy" "Medium" "Medium" "Ensure the Audit Security State Change setting is configured correctly." "Review and configure Audit Security State Change to include Success."
    } else {
        Add-Result "17.9.3" "Fail" "Audit Security State Change does not include Success." "Ensure 'Audit Security State Change' is set to include 'Success'" "Audit Policy" "Medium" "Medium" "Ensure the Audit Security State Change setting is configured correctly." "Review and configure Audit Security State Change to include Success."
    }
} catch {
    Add-Result "17.9.3" "Error" "Could not check 'Audit Security State Change'. Error: $($_.Exception.Message)" "Ensure 'Audit Security State Change' is set to include 'Success'" "Audit Policy" "Medium" "Medium" "Ensure the Audit Security State Change setting is configured correctly." "Review and configure Audit Security State Change to include Success."
}

try {
    # Ensure 'Audit Security System Extension' is set to include 'Success'
    $auditSecuritySystemExtension = (Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Audit\Configuration\Subcategories" -Name "{0CCE9239-69AE-11D9-BED3-505054503030}" -ErrorAction Stop).Value
    if ($auditSecuritySystemExtension -contains "Success") {
        Add-Result "17.9.4" "Pass" "Audit Security System Extension is set to include Success." "Ensure 'Audit Security System Extension' is set to include 'Success'" "Audit Policy" "Medium" "Medium" "Ensure the Audit Security System Extension setting is configured correctly." "Review and configure Audit Security System Extension to include Success."
    } else {
        Add-Result "17.9.4" "Fail" "Audit Security System Extension does not include Success." "Ensure 'Audit Security System Extension' is set to include 'Success'" "Audit Policy" "Medium" "Medium" "Ensure the Audit Security System Extension setting is configured correctly." "Review and configure Audit Security System Extension to include Success."
    }
} catch {
    Add-Result "17.9.4" "Error" "Could not check 'Audit Security System Extension'. Error: $($_.Exception.Message)" "Ensure 'Audit Security System Extension' is set to include 'Success'" "Audit Policy" "Medium" "Medium" "Ensure the Audit Security System Extension setting is configured correctly." "Review and configure Audit Security System Extension to include Success."
}

try {
    # Ensure 'Audit System Integrity' is set to 'Success and Failure'
    $auditSystemIntegrity = (Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Audit\Configuration\Subcategories" -Name "{0CCE923A-69AE-11D9-BED3-505054503030}" -ErrorAction Stop).Value
    if ($auditSystemIntegrity -contains "Success" -and $auditSystemIntegrity -contains "Failure") {
        Add-Result "17.9.5" "Pass" "Audit System Integrity is set to Success and Failure." "Ensure 'Audit System Integrity' is set to 'Success and Failure'" "Audit Policy" "High" "High" "Ensure the Audit System Integrity setting is configured correctly." "Review and configure Audit System Integrity to include Success and Failure."
    } else {
        Add-Result "17.9.5" "Fail" "Audit System Integrity is not set to Success and Failure." "Ensure 'Audit System Integrity' is set to 'Success and Failure'" "Audit Policy" "High" "High" "Ensure the Audit System Integrity setting is configured correctly." "Review and configure Audit System Integrity to include Success and Failure."
    }
} catch {
    Add-Result "17.9.5" "Error" "Could not check 'Audit System Integrity'. Error: $($_.Exception.Message)" "Ensure 'Audit System Integrity' is set to 'Success and Failure'" "Audit Policy" "High" "High" "Ensure the Audit System Integrity setting is configured correctly." "Review and configure Audit System Integrity to include Success and Failure."
}

# 18th
try {
    # Ensure 'Prevent enabling lock screen camera' is set to 'Enabled'
    $lockScreenCamera = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Personalization" -Name "NoLockScreenCamera" -ErrorAction Stop
    if ($lockScreenCamera.NoLockScreenCamera -eq 1) {
        Add-Result "18.1.1.1" "Pass" "Prevent enabling lock screen camera is set to Enabled." "Ensure 'Prevent enabling lock screen camera' is set to 'Enabled'" "Personalization" "Medium" "Medium" "Ensure the lock screen camera is disabled to improve security." "Review and enable the policy if not configured."
    } else {
        Add-Result "18.1.1.1" "Fail" "Prevent enabling lock screen camera is not set to Enabled." "Ensure 'Prevent enabling lock screen camera' is set to 'Enabled'" "Personalization" "Medium" "Medium" "Ensure the lock screen camera is disabled to improve security." "Review and enable the policy if not configured."
    }
} catch {
    Add-Result "18.1.1.1" "Error" "Could not check 'Prevent enabling lock screen camera'. Error: $($_.Exception.Message)" "Ensure 'Prevent enabling lock screen camera' is set to 'Enabled'" "Personalization" "Medium" "Medium" "Ensure the lock screen camera is disabled to improve security." "Review and enable the policy if not configured."
}

try {
    # Ensure 'Prevent enabling lock screen slide show' is set to 'Enabled'
    $lockScreenSlideShow = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Personalization" -Name "NoLockScreenSlideshow" -ErrorAction Stop
    if ($lockScreenSlideShow.NoLockScreenSlideshow -eq 1) {
        Add-Result "18.1.1.2" "Pass" "Prevent enabling lock screen slide show is set to Enabled." "Ensure 'Prevent enabling lock screen slide show' is set to 'Enabled'" "Personalization" "Medium" "Medium" "Ensure the lock screen slide show is disabled to improve security." "Review and enable the policy if not configured."
    } else {
        Add-Result "18.1.1.2" "Fail" "Prevent enabling lock screen slide show is not set to Enabled." "Ensure 'Prevent enabling lock screen slide show' is set to 'Enabled'" "Personalization" "Medium" "Medium" "Ensure the lock screen slide show is disabled to improve security." "Review and enable the policy if not configured."
    }
} catch {
    Add-Result "18.1.1.2" "Error" "Could not check 'Prevent enabling lock screen slide show'. Error: $($_.Exception.Message)" "Ensure 'Prevent enabling lock screen slide show' is set to 'Enabled'" "Personalization" "Medium" "Medium" "Ensure the lock screen slide show is disabled to improve security." "Review and enable the policy if not configured."
}

try {
    # Ensure 'Allow users to enable online speech recognition services' is set to 'Disabled'
    $onlineSpeechRecognition = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Speech" -Name "AllowOnlineSpeechRecognition" -ErrorAction Stop
    if ($onlineSpeechRecognition.AllowOnlineSpeechRecognition -eq 0) {
        Add-Result "18.1.2.2" "Pass" "Allow users to enable online speech recognition services is set to Disabled." "Ensure 'Allow users to enable online speech recognition services' is set to 'Disabled'" "Regional and Language Options" "Medium" "Medium" "Ensure online speech recognition services are disabled to improve privacy." "Review and disable the policy if not configured."
    } else {
        Add-Result "18.1.2.2" "Fail" "Allow users to enable online speech recognition services is not set to Disabled." "Ensure 'Allow users to enable online speech recognition services' is set to 'Disabled'" "Regional and Language Options" "Medium" "Medium" "Ensure online speech recognition services are disabled to improve privacy." "Review and disable the policy if not configured."
    }
} catch {
    Add-Result "18.1.2.2" "Error" "Could not check 'Allow users to enable online speech recognition services'. Error: $($_.Exception.Message)" "Ensure 'Allow users to enable online speech recognition services' is set to 'Disabled'" "Regional and Language Options" "Medium" "Medium" "Ensure online speech recognition services are disabled to improve privacy." "Review and disable the policy if not configured."
}

try {
    # Ensure 'Allow Online Tips' is set to 'Disabled'
    $allowOnlineTips = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CloudContent" -Name "DisableSoftLanding" -ErrorAction Stop
    if ($allowOnlineTips.DisableSoftLanding -eq 1) {
        Add-Result "18.1.3" "Pass" "Allow Online Tips is set to Disabled." "Ensure 'Allow Online Tips' is set to 'Disabled'" "Personalization" "Low" "Low" "Ensure online tips are disabled to improve privacy." "Review and disable the policy if not configured."
    } else {
        Add-Result "18.1.3" "Fail" "Allow Online Tips is not set to Disabled." "Ensure 'Allow Online Tips' is set to 'Disabled'" "Personalization" "Low" "Low" "Ensure online tips are disabled to improve privacy." "Review and disable the policy if not configured."
    }
} catch {
    Add-Result "18.1.3" "Error" "Could not check 'Allow Online Tips'. Error: $($_.Exception.Message)" "Ensure 'Allow Online Tips' is set to 'Disabled'" "Personalization" "Low" "Low" "Ensure online tips are disabled to improve privacy." "Review and disable the policy if not configured."
}

try {
    # Ensure 'Configure RPC packet level privacy setting for incoming connections' is set to 'Enabled'
    $rpcPrivacySetting = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Rpc" -Name "EnableAuthEpResolution" -ErrorAction Stop
    if ($rpcPrivacySetting.EnableAuthEpResolution -eq 1) {
        Add-Result "18.4.1" "Pass" "Configure RPC packet level privacy setting for incoming connections is set to Enabled." "Ensure 'Configure RPC packet level privacy setting for incoming connections' is set to 'Enabled'" "MS Security Guide" "Medium" "Medium" "Ensure RPC packet level privacy is configured correctly." "Review and enable the policy if not configured."
    } else {
        Add-Result "18.4.1" "Fail" "Configure RPC packet level privacy setting for incoming connections is not set to Enabled." "Ensure 'Configure RPC packet level privacy setting for incoming connections' is set to 'Enabled'" "MS Security Guide" "Medium" "Medium" "Ensure RPC packet level privacy is configured correctly." "Review and enable the policy if not configured."
    }
} catch {
    Add-Result "18.4.1" "Error" "Could not check 'Configure RPC packet level privacy setting for incoming connections'. Error: $($_.Exception.Message)" "Ensure 'Configure RPC packet level privacy setting for incoming connections' is set to 'Enabled'" "MS Security Guide" "Medium" "Medium" "Ensure RPC packet level privacy is configured correctly." "Review and enable the policy if not configured."
}

try {
    # Ensure 'Configure SMB v1 client driver' is set to 'Enabled: Disable driver (recommended)'
    $smbV1ClientDriver = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation" -Name "DependOnService" -ErrorAction Stop
    if ($smbV1ClientDriver.DependOnService -notcontains "MRxSmb10") {
        Add-Result "18.4.2" "Pass" "Configure SMB v1 client driver is set to 'Enabled: Disable driver (recommended)'." "Ensure 'Configure SMB v1 client driver' is set to 'Enabled: Disable driver (recommended)'" "MS Security Guide" "High" "High" "Ensure SMB v1 is disabled to mitigate security risks." "Review and disable SMB v1 if not configured."
    } else {
        Add-Result "18.4.2" "Fail" "Configure SMB v1 client driver is not set to 'Enabled: Disable driver (recommended)'." "Ensure 'Configure SMB v1 client driver' is set to 'Enabled: Disable driver (recommended)'" "MS Security Guide" "High" "High" "Ensure SMB v1 is disabled to mitigate security risks." "Review and disable SMB v1 if not configured."
    }
} catch {
    Add-Result "18.4.2" "Error" "Could not check 'Configure SMB v1 client driver'. Error: $($_.Exception.Message)" "Ensure 'Configure SMB v1 client driver' is set to 'Enabled: Disable driver (recommended)'" "MS Security Guide" "High" "High" "Ensure SMB v1 is disabled to mitigate security risks." "Review and disable SMB v1 if not configured."
}

try {
    # Ensure 'Configure SMB v1 server' is set to 'Disabled'
    $smbV1Server = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" -Name "SMB1" -ErrorAction Stop
    if ($smbV1Server.SMB1 -eq 0) {
        Add-Result "18.4.3" "Pass" "Configure SMB v1 server is set to Disabled." "Ensure 'Configure SMB v1 server' is set to 'Disabled'" "MS Security Guide" "High" "High" "Ensure SMB v1 server is disabled to improve security." "Review and disable SMB v1 server if not configured."
    } else {
        Add-Result "18.4.3" "Fail" "Configure SMB v1 server is not set to Disabled." "Ensure 'Configure SMB v1 server' is set to 'Disabled'" "MS Security Guide" "High" "High" "Ensure SMB v1 server is disabled to improve security." "Review and disable SMB v1 server if not configured."
    }
} catch {
    Add-Result "18.4.3" "Error" "Could not check 'Configure SMB v1 server'. Error: $($_.Exception.Message)" "Ensure 'Configure SMB v1 server' is set to 'Disabled'" "MS Security Guide" "High" "High" "Ensure SMB v1 server is disabled to improve security." "Review and disable SMB v1 server if not configured."
}

try {
    # Ensure 'Enable Certificate Padding' is set to 'Enabled'
    $certificatePadding = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Cryptography" -Name "EnableCertPaddingCheck" -ErrorAction Stop
    if ($certificatePadding.EnableCertPaddingCheck -eq 1) {
        Add-Result "18.4.4" "Pass" "Enable Certificate Padding is set to Enabled." "Ensure 'Enable Certificate Padding' is set to 'Enabled'" "MS Security Guide" "Medium" "Medium" "Ensure certificate padding is enabled to prevent attacks." "Review and enable the policy if not configured."
    } else {
        Add-Result "18.4.4" "Fail" "Enable Certificate Padding is not set to Enabled." "Ensure 'Enable Certificate Padding' is set to 'Enabled'" "MS Security Guide" "Medium" "Medium" "Ensure certificate padding is enabled to prevent attacks." "Review and enable the policy if not configured."
    }
} catch {
    Add-Result "18.4.4" "Error" "Could not check 'Enable Certificate Padding'. Error: $($_.Exception.Message)" "Ensure 'Enable Certificate Padding' is set to 'Enabled'" "MS Security Guide" "Medium" "Medium" "Ensure certificate padding is enabled to prevent attacks." "Review and enable the policy if not configured."
}

try {
    # Ensure 'Enable Structured Exception Handling Overwrite Protection (SEHOP)' is set to 'Enabled'
    $sehProtection = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Kernel" -Name "DisableExceptionChainValidation" -ErrorAction Stop
    if ($sehProtection.DisableExceptionChainValidation -eq 0) {
        Add-Result "18.4.5" "Pass" "Enable SEHOP is set to Enabled." "Ensure 'Enable Structured Exception Handling Overwrite Protection (SEHOP)' is set to 'Enabled'" "MS Security Guide" "High" "High" "Ensure SEHOP is enabled to prevent exploitation of structured exception handling." "Review and enable the policy if not configured."
    } else {
        Add-Result "18.4.5" "Fail" "Enable SEHOP is not set to Enabled." "Ensure 'Enable Structured Exception Handling Overwrite Protection (SEHOP)' is set to 'Enabled'" "MS Security Guide" "High" "High" "Ensure SEHOP is enabled to prevent exploitation of structured exception handling." "Review and enable the policy if not configured."
    }
} catch {
    Add-Result "18.4.5" "Error" "Could not check 'Enable SEHOP'. Error: $($_.Exception.Message)" "Ensure 'Enable Structured Exception Handling Overwrite Protection (SEHOP)' is set to 'Enabled'" "MS Security Guide" "High" "High" "Ensure SEHOP is enabled to prevent exploitation of structured exception handling." "Review and enable the policy if not configured."
}

try {
    # Ensure 'NetBT NodeType configuration' is set to 'Enabled: P-node (recommended)'
    $netbtNodeType = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\NetBT\Parameters" -Name "NodeType" -ErrorAction Stop
    if ($netbtNodeType.NodeType -eq 2) {
        Add-Result "18.4.6" "Pass" "NetBT NodeType configuration is set to Enabled: P-node." "Ensure 'NetBT NodeType configuration' is set to 'Enabled: P-node (recommended)'" "MS Security Guide" "Medium" "Medium" "Ensure P-node is configured for enhanced security." "Review and configure NodeType to P-node if not set."
    } else {
        Add-Result "18.4.6" "Fail" "NetBT NodeType configuration is not set to Enabled: P-node." "Ensure 'NetBT NodeType configuration' is set to 'Enabled: P-node (recommended)'" "MS Security Guide" "Medium" "Medium" "Ensure P-node is configured for enhanced security." "Review and configure NodeType to P-node if not set."
    }
} catch {
    Add-Result "18.4.6" "Error" "Could not check 'NetBT NodeType configuration'. Error: $($_.Exception.Message)" "Ensure 'NetBT NodeType configuration' is set to 'Enabled: P-node (recommended)'" "MS Security Guide" "Medium" "Medium" "Ensure P-node is configured for enhanced security." "Review and configure NodeType to P-node if not set."
}

try {
    # Ensure 'WDigest Authentication' is set to 'Disabled'
    $wdigestAuth = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\WDigest" -Name "UseLogonCredential" -ErrorAction Stop
    if ($wdigestAuth.UseLogonCredential -eq 0) {
        Add-Result "18.4.7" "Pass" "WDigest Authentication is set to Disabled." "Ensure 'WDigest Authentication' is set to 'Disabled'" "MS Security Guide" "High" "High" "Ensure WDigest is disabled to prevent credential theft." "Review and disable WDigest Authentication if enabled."
    } else {
        Add-Result "18.4.7" "Fail" "WDigest Authentication is not set to Disabled." "Ensure 'WDigest Authentication' is set to 'Disabled'" "MS Security Guide" "High" "High" "Ensure WDigest is disabled to prevent credential theft." "Review and disable WDigest Authentication if enabled."
    }
} catch {
    Add-Result "18.4.7" "Error" "Could not check 'WDigest Authentication'. Error: $($_.Exception.Message)" "Ensure 'WDigest Authentication' is set to 'Disabled'" "MS Security Guide" "High" "High" "Ensure WDigest is disabled to prevent credential theft." "Review and disable WDigest Authentication if enabled."
}

try {
    # Ensure 'MSS: (AutoAdminLogon) Enable Automatic Logon' is set to 'Disabled'
    $autoAdminLogon = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" -Name "AutoAdminLogon" -ErrorAction Stop
    if ($autoAdminLogon.AutoAdminLogon -eq 0) {
        Add-Result "18.5.1" "Pass" "AutoAdminLogon is set to Disabled." "Ensure 'MSS: (AutoAdminLogon) Enable Automatic Logon' is set to 'Disabled'" "MSS (Legacy)" "High" "High" "Ensure automatic logon is disabled for enhanced security." "Review and disable automatic logon if enabled."
    } else {
        Add-Result "18.5.1" "Fail" "AutoAdminLogon is not set to Disabled." "Ensure 'MSS: (AutoAdminLogon) Enable Automatic Logon' is set to 'Disabled'" "MSS (Legacy)" "High" "High" "Ensure automatic logon is disabled for enhanced security." "Review and disable automatic logon if enabled."
    }
} catch {
    Add-Result "18.5.1" "Error" "Could not check 'MSS: (AutoAdminLogon) Enable Automatic Logon'. Error: $($_.Exception.Message)" "Ensure 'MSS: (AutoAdminLogon) Enable Automatic Logon' is set to 'Disabled'" "MSS (Legacy)" "High" "High" "Ensure automatic logon is disabled for enhanced security." "Review and disable automatic logon if enabled."
}

try {
    # Ensure 'MSS: (DisableIPSourceRouting IPv6) IP source routing protection level' is set to 'Enabled: Highest protection, source routing is completely disabled'
    $ipSourceRoutingIPv6 = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters" -Name "DisableIPSourceRouting" -ErrorAction Stop
    if ($ipSourceRoutingIPv6.DisableIPSourceRouting -eq 2) {
        Add-Result "18.5.2" "Pass" "DisableIPSourceRouting IPv6 is set to Highest protection." "Ensure 'MSS: (DisableIPSourceRouting IPv6) IP source routing protection level' is set to 'Enabled: Highest protection, source routing is completely disabled'" "MSS (Legacy)" "High" "High" "Ensure IPv6 source routing is completely disabled." "Review and configure the policy for maximum protection."
    } else {
        Add-Result "18.5.2" "Fail" "DisableIPSourceRouting IPv6 is not set to Highest protection." "Ensure 'MSS: (DisableIPSourceRouting IPv6) IP source routing protection level' is set to 'Enabled: Highest protection, source routing is completely disabled'" "MSS (Legacy)" "High" "High" "Ensure IPv6 source routing is completely disabled." "Review and configure the policy for maximum protection."
    }
} catch {
    Add-Result "18.5.2" "Error" "Could not check 'MSS: (DisableIPSourceRouting IPv6) IP source routing protection level'. Error: $($_.Exception.Message)" "Ensure 'MSS: (DisableIPSourceRouting IPv6) IP source routing protection level' is set to 'Enabled: Highest protection, source routing is completely disabled'" "MSS (Legacy)" "High" "High" "Ensure IPv6 source routing is completely disabled." "Review and configure the policy for maximum protection."
}

try {
    # Ensure 'MSS: (DisableIPSourceRouting) IP source routing protection level' is set to 'Enabled: Highest protection, source routing is completely disabled'
    $ipSourceRouting = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" -Name "DisableIPSourceRouting" -ErrorAction Stop
    if ($ipSourceRouting.DisableIPSourceRouting -eq 2) {
        Add-Result "18.5.3" "Pass" "DisableIPSourceRouting is set to Highest protection." "Ensure 'MSS: (DisableIPSourceRouting) IP source routing protection level' is set to 'Enabled: Highest protection, source routing is completely disabled'" "MSS (Legacy)" "High" "High" "Ensure IP source routing is completely disabled." "Review and configure the policy for maximum protection."
    } else {
        Add-Result "18.5.3" "Fail" "DisableIPSourceRouting is not set to Highest protection." "Ensure 'MSS: (DisableIPSourceRouting) IP source routing protection level' is set to 'Enabled: Highest protection, source routing is completely disabled'" "MSS (Legacy)" "High" "High" "Ensure IP source routing is completely disabled." "Review and configure the policy for maximum protection."
    }
} catch {
    Add-Result "18.5.3" "Error" "Could not check 'MSS: (DisableIPSourceRouting) IP source routing protection level'. Error: $($_.Exception.Message)" "Ensure 'MSS: (DisableIPSourceRouting) IP source routing protection level' is set to 'Enabled: Highest protection, source routing is completely disabled'" "MSS (Legacy)" "High" "High" "Ensure IP source routing is completely disabled." "Review and configure the policy for maximum protection."
}

try {
    # Ensure 'MSS: (DisableSavePassword) Prevent the dial-up password from being saved' is set to 'Enabled'
    $disableSavePassword = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\NetworkProvider" -Name "DisableSavePassword" -ErrorAction Stop
    if ($disableSavePassword.DisableSavePassword -eq 1) {
        Add-Result "18.5.4" "Pass" "DisableSavePassword is set to Enabled." "Ensure 'MSS: (DisableSavePassword) Prevent the dial-up password from being saved' is set to 'Enabled'" "MSS (Legacy)" "Medium" "Medium" "Ensure dial-up passwords cannot be saved to prevent unauthorized access." "Review and enable the policy if not configured."
    } else {
        Add-Result "18.5.4" "Fail" "DisableSavePassword is not set to Enabled." "Ensure 'MSS: (DisableSavePassword) Prevent the dial-up password from being saved' is set to 'Enabled'" "MSS (Legacy)" "Medium" "Medium" "Ensure dial-up passwords cannot be saved to prevent unauthorized access." "Review and enable the policy if not configured."
    }
} catch {
    Add-Result "18.5.4" "Error" "Could not check 'MSS: (DisableSavePassword) Prevent the dial-up password from being saved'. Error: $($_.Exception.Message)" "Ensure 'MSS: (DisableSavePassword) Prevent the dial-up password from being saved' is set to 'Enabled'" "MSS (Legacy)" "Medium" "Medium" "Ensure dial-up passwords cannot be saved to prevent unauthorized access." "Review and enable the policy if not configured."
}

try {
    # Ensure 'MSS: (EnableICMPRedirect) Allow ICMP redirects to override OSPF generated routes' is set to 'Disabled'
    $enableICMPRedirect = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" -Name "EnableICMPRedirect" -ErrorAction Stop
    if ($enableICMPRedirect.EnableICMPRedirect -eq 0) {
        Add-Result "18.5.5" "Pass" "EnableICMPRedirect is set to Disabled." "Ensure 'MSS: (EnableICMPRedirect) Allow ICMP redirects to override OSPF generated routes' is set to 'Disabled'" "MSS (Legacy)" "High" "High" "Ensure ICMP redirects are disabled to improve network security." "Review and disable the policy if not configured."
    } else {
        Add-Result "18.5.5" "Fail" "EnableICMPRedirect is not set to Disabled." "Ensure 'MSS: (EnableICMPRedirect) Allow ICMP redirects to override OSPF generated routes' is set to 'Disabled'" "MSS (Legacy)" "High" "High" "Ensure ICMP redirects are disabled to improve network security." "Review and disable the policy if not configured."
    }
} catch {
    Add-Result "18.5.5" "Error" "Could not check 'MSS: (EnableICMPRedirect) Allow ICMP redirects to override OSPF generated routes'. Error: $($_.Exception.Message)" "Ensure 'MSS: (EnableICMPRedirect) Allow ICMP redirects to override OSPF generated routes' is set to 'Disabled'" "MSS (Legacy)" "High" "High" "Ensure ICMP redirects are disabled to improve network security." "Review and disable the policy if not configured."
}

try {
    # Ensure 'MSS: (KeepAliveTime) How often keep-alive packets are sent in milliseconds' is set to 'Enabled: 300,000 or 5 minutes'
    $keepAliveTime = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" -Name "KeepAliveTime" -ErrorAction Stop
    if ($keepAliveTime.KeepAliveTime -eq 300000) {
        Add-Result "18.5.6" "Pass" "KeepAliveTime is set to 300,000 milliseconds (5 minutes)." "Ensure 'MSS: (KeepAliveTime) How often keep-alive packets are sent in milliseconds' is set to 'Enabled: 300,000 or 5 minutes'" "MSS (Legacy)" "Medium" "Medium" "Ensure keep-alive packets are sent at the recommended interval to maintain connectivity and improve security." "Review and configure the policy if not set."
    } else {
        Add-Result "18.5.6" "Fail" "KeepAliveTime is not set to 300,000 milliseconds (5 minutes)." "Ensure 'MSS: (KeepAliveTime) How often keep-alive packets are sent in milliseconds' is set to 'Enabled: 300,000 or 5 minutes'" "MSS (Legacy)" "Medium" "Medium" "Ensure keep-alive packets are sent at the recommended interval to maintain connectivity and improve security." "Review and configure the policy if not set."
    }
} catch {
    Add-Result "18.5.6" "Error" "Could not check 'MSS: (KeepAliveTime) How often keep-alive packets are sent in milliseconds'. Error: $($_.Exception.Message)" "Ensure 'MSS: (KeepAliveTime) How often keep-alive packets are sent in milliseconds' is set to 'Enabled: 300,000 or 5 minutes'" "MSS (Legacy)" "Medium" "Medium" "Ensure keep-alive packets are sent at the recommended interval to maintain connectivity and improve security." "Review and configure the policy if not set."
}

try {
    # Ensure 'MSS: (NoNameReleaseOnDemand) Allow the computer to ignore NetBIOS name release requests except from WINS servers' is set to 'Enabled'
    $noNameRelease = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\NetBT\Parameters" -Name "NoNameReleaseOnDemand" -ErrorAction Stop
    if ($noNameRelease.NoNameReleaseOnDemand -eq 1) {
        Add-Result "18.5.7" "Pass" "NoNameReleaseOnDemand is set to Enabled." "Ensure 'MSS: (NoNameReleaseOnDemand) Allow the computer to ignore NetBIOS name release requests except from WINS servers' is set to 'Enabled'" "MSS (Legacy)" "Medium" "Medium" "Ensure NetBIOS name release requests are ignored except from WINS servers." "Review and enable the policy if not configured."
    } else {
        Add-Result "18.5.7" "Fail" "NoNameReleaseOnDemand is not set to Enabled." "Ensure 'MSS: (NoNameReleaseOnDemand) Allow the computer to ignore NetBIOS name release requests except from WINS servers' is set to 'Enabled'" "MSS (Legacy)" "Medium" "Medium" "Ensure NetBIOS name release requests are ignored except from WINS servers." "Review and enable the policy if not configured."
    }
} catch {
    Add-Result "18.5.7" "Error" "Could not check 'MSS: (NoNameReleaseOnDemand) Allow the computer to ignore NetBIOS name release requests except from WINS servers'. Error: $($_.Exception.Message)" "Ensure 'MSS: (NoNameReleaseOnDemand) Allow the computer to ignore NetBIOS name release requests except from WINS servers' is set to 'Enabled'" "MSS (Legacy)" "Medium" "Medium" "Ensure NetBIOS name release requests are ignored except from WINS servers." "Review and enable the policy if not configured."
}

try {
    # Ensure 'MSS: (PerformRouterDiscovery) Allow IRDP to detect and configure Default Gateway addresses' is set to 'Disabled'
    $performRouterDiscovery = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" -Name "PerformRouterDiscovery" -ErrorAction Stop
    if ($performRouterDiscovery.PerformRouterDiscovery -eq 0) {
        Add-Result "18.5.8" "Pass" "PerformRouterDiscovery is set to Disabled." "Ensure 'MSS: (PerformRouterDiscovery) Allow IRDP to detect and configure Default Gateway addresses' is set to 'Disabled'" "MSS (Legacy)" "Low" "Low" "Ensure router discovery is disabled to enhance network security." "Review and disable the policy if not configured."
    } else {
        Add-Result "18.5.8" "Fail" "PerformRouterDiscovery is not set to Disabled." "Ensure 'MSS: (PerformRouterDiscovery) Allow IRDP to detect and configure Default Gateway addresses' is set to 'Disabled'" "MSS (Legacy)" "Low" "Low" "Ensure router discovery is disabled to enhance network security." "Review and disable the policy if not configured."
    }
} catch {
    Add-Result "18.5.8" "Error" "Could not check 'PerformRouterDiscovery'. Error: $($_.Exception.Message)" "Ensure 'MSS: (PerformRouterDiscovery) Allow IRDP to detect and configure Default Gateway addresses' is set to 'Disabled'" "MSS (Legacy)" "Low" "Low" "Ensure router discovery is disabled to enhance network security." "Review and disable the policy if not configured."
}

try {
    # Ensure 'MSS: (SafeDllSearchMode) Enable Safe DLL search mode' is set to 'Enabled'
    $safeDllSearchMode = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager" -Name "SafeDllSearchMode" -ErrorAction Stop
    if ($safeDllSearchMode.SafeDllSearchMode -eq 1) {
        Add-Result "18.5.9" "Pass" "SafeDllSearchMode is set to Enabled." "Ensure 'MSS: (SafeDllSearchMode) Enable Safe DLL search mode' is set to 'Enabled'" "MSS (Legacy)" "High" "High" "Ensure Safe DLL search mode is enabled to improve security." "Review and enable the policy if not configured."
    } else {
        Add-Result "18.5.9" "Fail" "SafeDllSearchMode is not set to Enabled." "Ensure 'MSS: (SafeDllSearchMode) Enable Safe DLL search mode' is set to 'Enabled'" "MSS (Legacy)" "High" "High" "Ensure Safe DLL search mode is enabled to improve security." "Review and enable the policy if not configured."
    }
} catch {
    Add-Result "18.5.9" "Error" "Could not check 'SafeDllSearchMode'. Error: $($_.Exception.Message)" "Ensure 'MSS: (SafeDllSearchMode) Enable Safe DLL search mode' is set to 'Enabled'" "MSS (Legacy)" "High" "High" "Ensure Safe DLL search mode is enabled to improve security." "Review and enable the policy if not configured."
}

try {
    # Ensure 'MSS: (ScreenSaverGracePeriod) The time in seconds before the screen saver grace period expires' is set to 'Enabled: 5 or fewer seconds'
    $screenSaverGracePeriod = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" -Name "ScreenSaverGracePeriod" -ErrorAction Stop
    if ($screenSaverGracePeriod.ScreenSaverGracePeriod -le 5) {
        Add-Result "18.5.10" "Pass" "ScreenSaverGracePeriod is set to 5 or fewer seconds." "Ensure 'MSS: (ScreenSaverGracePeriod) The time in seconds before the screen saver grace period expires' is set to 'Enabled: 5 or fewer seconds'" "MSS (Legacy)" "Medium" "Medium" "Ensure the screen saver grace period is short to improve security." "Review and configure the policy if not set."
    } else {
        Add-Result "18.5.10" "Fail" "ScreenSaverGracePeriod is not set to 5 or fewer seconds." "Ensure 'MSS: (ScreenSaverGracePeriod) The time in seconds before the screen saver grace period expires' is set to 'Enabled: 5 or fewer seconds'" "MSS (Legacy)" "Medium" "Medium" "Ensure the screen saver grace period is short to improve security." "Review and configure the policy if not set."
    }
} catch {
    Add-Result "18.5.10" "Error" "Could not check 'ScreenSaverGracePeriod'. Error: $($_.Exception.Message)" "Ensure 'MSS: (ScreenSaverGracePeriod) The time in seconds before the screen saver grace period expires' is set to 'Enabled: 5 or fewer seconds'" "MSS (Legacy)" "Medium" "Medium" "Ensure the screen saver grace period is short to improve security." "Review and configure the policy if not set."
}

try {
    # Ensure 'MSS: (TcpMaxDataRetransmissions IPv6) How many times unacknowledged data is retransmitted' is set to 'Enabled: 3'
    $tcpMaxRetransIPv6 = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters" -Name "TcpMaxDataRetransmissions" -ErrorAction Stop
    if ($tcpMaxRetransIPv6.TcpMaxDataRetransmissions -eq 3) {
        Add-Result "18.5.11" "Pass" "TcpMaxDataRetransmissions IPv6 is set to 3." "Ensure 'MSS: (TcpMaxDataRetransmissions IPv6) How many times unacknowledged data is retransmitted' is set to 'Enabled: 3'" "MSS (Legacy)" "Medium" "Medium" "Ensure data retransmissions are limited to 3 to improve network efficiency." "Review and configure the policy if not set."
    } else {
        Add-Result "18.5.11" "Fail" "TcpMaxDataRetransmissions IPv6 is not set to 3." "Ensure 'MSS: (TcpMaxDataRetransmissions IPv6) How many times unacknowledged data is retransmitted' is set to 'Enabled: 3'" "MSS (Legacy)" "Medium" "Medium" "Ensure data retransmissions are limited to 3 to improve network efficiency." "Review and configure the policy if not set."
    }
} catch {
    Add-Result "18.5.11" "Error" "Could not check 'TcpMaxDataRetransmissions IPv6'. Error: $($_.Exception.Message)" "Ensure 'MSS: (TcpMaxDataRetransmissions IPv6) How many times unacknowledged data is retransmitted' is set to 'Enabled: 3'" "MSS (Legacy)" "Medium" "Medium" "Ensure data retransmissions are limited to 3 to improve network efficiency." "Review and configure the policy if not set."
}

try {
    # Ensure 'MSS: (TcpMaxDataRetransmissions) How many times unacknowledged data is retransmitted' is set to 'Enabled: 3'
    $tcpMaxRetrans = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" -Name "TcpMaxDataRetransmissions" -ErrorAction Stop
    if ($tcpMaxRetrans.TcpMaxDataRetransmissions -eq 3) {
        Add-Result "18.5.12" "Pass" "TcpMaxDataRetransmissions is set to 3." "Ensure 'MSS: (TcpMaxDataRetransmissions) How many times unacknowledged data is retransmitted' is set to 'Enabled: 3'" "MSS (Legacy)" "Medium" "Medium" "Ensure data retransmissions are limited to 3 to improve network efficiency." "Review and configure the policy if not set."
    } else {
        Add-Result "18.5.12" "Fail" "TcpMaxDataRetransmissions is not set to 3." "Ensure 'MSS: (TcpMaxDataRetransmissions) How many times unacknowledged data is retransmitted' is set to 'Enabled: 3'" "MSS (Legacy)" "Medium" "Medium" "Ensure data retransmissions are limited to 3 to improve network efficiency." "Review and configure the policy if not set."
    }
} catch {
    Add-Result "18.5.12" "Error" "Could not check 'TcpMaxDataRetransmissions'. Error: $($_.Exception.Message)" "Ensure 'MSS: (TcpMaxDataRetransmissions) How many times unacknowledged data is retransmitted' is set to 'Enabled: 3'" "MSS (Legacy)" "Medium" "Medium" "Ensure data retransmissions are limited to 3 to improve network efficiency." "Review and configure the policy if not set."
}

try {
    # Ensure 'MSS: (WarningLevel) Percentage threshold for the security event log at which the system will generate a warning' is set to 'Enabled: 90% or less'
    $warningLevel = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Eventlog\Security" -Name "WarningLevel" -ErrorAction Stop
    if ($warningLevel.WarningLevel -le 90) {
        Add-Result "18.5.13" "Pass" "WarningLevel is set to 90% or less." "Ensure 'MSS: (WarningLevel) Percentage threshold for the security event log at which the system will generate a warning' is set to 'Enabled: 90% or less'" "MSS (Legacy)" "High" "High" "Ensure the event log warning threshold is configured for effective monitoring." "Review and configure the policy if not set."
    } else {
        Add-Result "18.5.13" "Fail" "WarningLevel is not set to 90% or less." "Ensure 'MSS: (WarningLevel) Percentage threshold for the security event log at which the system will generate a warning' is set to 'Enabled: 90% or less'" "MSS (Legacy)" "High" "High" "Ensure the event log warning threshold is configured for effective monitoring." "Review and configure the policy if not set."
    }
} catch {
    Add-Result "18.5.13" "Error" "Could not check 'WarningLevel'. Error: $($_.Exception.Message)" "Ensure 'MSS: (WarningLevel) Percentage threshold for the security event log at which the system will generate a warning' is set to 'Enabled: 90% or less'" "MSS (Legacy)" "High" "High" "Ensure the event log warning threshold is configured for effective monitoring." "Review and configure the policy if not set."
}

try {
    # Ensure 'Configure DNS over HTTPS (DoH) name resolution' is set to 'Enabled: Allow DoH' or higher
    $dnsOverHttps = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient" -Name "EnableAutoDoh" -ErrorAction Stop
    if ($dnsOverHttps.EnableAutoDoh -ge 1) {
        Add-Result "18.6.4.1" "Pass" "Configure DNS over HTTPS (DoH) is set to Allow DoH or higher." "Ensure 'Configure DNS over HTTPS (DoH) name resolution' is set to 'Enabled: Allow DoH' or higher" "DNS Client" "Medium" "Medium" "Ensure DoH is enabled for secure DNS name resolution." "Review and enable the policy if not set."
    } else {
        Add-Result "18.6.4.1" "Fail" "Configure DNS over HTTPS (DoH) is not set to Allow DoH or higher." "Ensure 'Configure DNS over HTTPS (DoH) name resolution' is set to 'Enabled: Allow DoH' or higher" "DNS Client" "Medium" "Medium" "Ensure DoH is enabled for secure DNS name resolution." "Review and enable the policy if not set."
    }
} catch {
    Add-Result "18.6.4.1" "Error" "Could not check 'Configure DNS over HTTPS (DoH) name resolution'. Error: $($_.Exception.Message)" "Ensure 'Configure DNS over HTTPS (DoH) name resolution' is set to 'Enabled: Allow DoH' or higher" "DNS Client" "Medium" "Medium" "Ensure DoH is enabled for secure DNS name resolution." "Review and enable the policy if not set."
}

try {
    # Ensure 'Enable Font Providers' is set to 'Disabled'
    $fontProviders = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\CurrentVersion\FontProviders" -Name "Enabled" -ErrorAction Stop
    if ($fontProviders.Enabled -eq 0) {
        Add-Result "18.6.5.1" "Pass" "Enable Font Providers is set to Disabled." "Ensure 'Enable Font Providers' is set to 'Disabled'" "Fonts" "Low" "Low" "Ensure font providers are disabled to improve security." "Review and disable the policy if not configured."
    } else {
        Add-Result "18.6.5.1" "Fail" "Enable Font Providers is not set to Disabled." "Ensure 'Enable Font Providers' is set to 'Disabled'" "Fonts" "Low" "Low" "Ensure font providers are disabled to improve security." "Review and disable the policy if not configured."
    }
} catch {
    Add-Result "18.6.5.1" "Error" "Could not check 'Enable Font Providers'. Error: $($_.Exception.Message)" "Ensure 'Enable Font Providers' is set to 'Disabled'" "Fonts" "Low" "Low" "Ensure font providers are disabled to improve security." "Review and disable the policy if not configured."
}

try {
    # Ensure 'Enable insecure guest logons' is set to 'Disabled'
    $insecureGuestLogons = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\LanmanWorkstation" -Name "AllowInsecureGuestAuth" -ErrorAction Stop
    if ($insecureGuestLogons.AllowInsecureGuestAuth -eq 0) {
        Add-Result "18.6.8.1" "Pass" "Enable insecure guest logons is set to Disabled." "Ensure 'Enable insecure guest logons' is set to 'Disabled'" "Lanman Workstation" "High" "High" "Ensure insecure guest logons are disabled to prevent unauthorized access." "Review and disable the policy if not configured."
    } else {
        Add-Result "18.6.8.1" "Fail" "Enable insecure guest logons is not set to Disabled." "Ensure 'Enable insecure guest logons' is set to 'Disabled'" "Lanman Workstation" "High" "High" "Ensure insecure guest logons are disabled to prevent unauthorized access." "Review and disable the policy if not configured."
    }
} catch {
    Add-Result "18.6.8.1" "Error" "Could not check 'Enable insecure guest logons'. Error: $($_.Exception.Message)" "Ensure 'Enable insecure guest logons' is set to 'Disabled'" "Lanman Workstation" "High" "High" "Ensure insecure guest logons are disabled to prevent unauthorized access." "Review and disable the policy if not configured."
}

try {
    # Ensure 'Turn on Mapper I/O (LLTDIO) driver' is set to 'Disabled'
    $mapperDriver = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\LLTDIO" -Name "EnableLLTDIO" -ErrorAction Stop
    if ($mapperDriver.EnableLLTDIO -eq 0) {
        Add-Result "18.6.9.1" "Pass" "Mapper I/O (LLTDIO) driver is set to Disabled." "Ensure 'Turn on Mapper I/O (LLTDIO) driver' is set to 'Disabled'" "Link-Layer Topology Discovery" "Low" "Low" "Ensure Mapper I/O driver is disabled to improve network security." "Review and disable the policy if not configured."
    } else {
        Add-Result "18.6.9.1" "Fail" "Mapper I/O (LLTDIO) driver is not set to Disabled." "Ensure 'Turn on Mapper I/O (LLTDIO) driver' is set to 'Disabled'" "Link-Layer Topology Discovery" "Low" "Low" "Ensure Mapper I/O driver is disabled to improve network security." "Review and disable the policy if not configured."
    }
} catch {
    Add-Result "18.6.9.1" "Error" "Could not check 'Mapper I/O (LLTDIO) driver'. Error: $($_.Exception.Message)" "Ensure 'Turn on Mapper I/O (LLTDIO) driver' is set to 'Disabled'" "Link-Layer Topology Discovery" "Low" "Low" "Ensure Mapper I/O driver is disabled to improve network security." "Review and disable the policy if not configured."
}

try {
    # Ensure 'Turn on Responder (RSPNDR) driver' is set to 'Disabled'
    $responderDriver = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\RSPNDR" -Name "EnableRspndr" -ErrorAction Stop
    if ($responderDriver.EnableRspndr -eq 0) {
        Add-Result "18.6.9.2" "Pass" "Responder (RSPNDR) driver is set to Disabled." "Ensure 'Turn on Responder (RSPNDR) driver' is set to 'Disabled'" "Link-Layer Topology Discovery" "Low" "Low" "Ensure Responder driver is disabled to improve network security." "Review and disable the policy if not configured."
    } else {
        Add-Result "18.6.9.2" "Fail" "Responder (RSPNDR) driver is not set to Disabled." "Ensure 'Turn on Responder (RSPNDR) driver' is set to 'Disabled'" "Link-Layer Topology Discovery" "Low" "Low" "Ensure Responder driver is disabled to improve network security." "Review and disable the policy if not configured."
    }
} catch {
    Add-Result "18.6.9.2" "Error" "Could not check 'Responder (RSPNDR) driver'. Error: $($_.Exception.Message)" "Ensure 'Turn on Responder (RSPNDR) driver' is set to 'Disabled'" "Link-Layer Topology Discovery" "Low" "Low" "Ensure Responder driver is disabled to improve network security." "Review and disable the policy if not configured."
}

try {
    # Ensure 'Turn off Microsoft Peer-to-Peer Networking Services' is set to 'Enabled'
    $p2pNetworkingServices = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Peernet" -Name "Disabled" -ErrorAction Stop
    if ($p2pNetworkingServices.Disabled -eq 1) {
        Add-Result "18.6.10.2" "Pass" "Turn off Microsoft Peer-to-Peer Networking Services is set to Enabled." "Ensure 'Turn off Microsoft Peer-to-Peer Networking Services' is set to 'Enabled'" "Microsoft Peer-to-Peer Networking Services" "Low" "Low" "Ensure Peer-to-Peer Networking Services are disabled for security." "Review and enable the policy if not configured."
    } else {
        Add-Result "18.6.10.2" "Fail" "Turn off Microsoft Peer-to-Peer Networking Services is not set to Enabled." "Ensure 'Turn off Microsoft Peer-to-Peer Networking Services' is set to 'Enabled'" "Microsoft Peer-to-Peer Networking Services" "Low" "Low" "Ensure Peer-to-Peer Networking Services are disabled for security." "Review and enable the policy if not configured."
    }
} catch {
    Add-Result "18.6.10.2" "Error" "Could not check 'Turn off Microsoft Peer-to-Peer Networking Services'. Error: $($_.Exception.Message)" "Ensure 'Turn off Microsoft Peer-to-Peer Networking Services' is set to 'Enabled'" "Microsoft Peer-to-Peer Networking Services" "Low" "Low" "Ensure Peer-to-Peer Networking Services are disabled for security." "Review and enable the policy if not configured."
}

try {
    # Ensure 'Prohibit installation and configuration of Network Bridge on your DNS domain network' is set to 'Enabled'
    $networkBridge = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Network Connections" -Name "NC_AllowNetBridge_NLA" -ErrorAction Stop
    if ($networkBridge.NC_AllowNetBridge_NLA -eq 0) {
        Add-Result "18.6.11.2" "Pass" "Prohibit installation and configuration of Network Bridge on your DNS domain network is set to Enabled." "Ensure 'Prohibit installation and configuration of Network Bridge on your DNS domain network' is set to 'Enabled'" "Network Connections" "Medium" "Medium" "Ensure network bridges are prohibited on domain networks." "Review and enable the policy if not configured."
    } else {
        Add-Result "18.6.11.2" "Fail" "Prohibit installation and configuration of Network Bridge on your DNS domain network is not set to Enabled." "Ensure 'Prohibit installation and configuration of Network Bridge on your DNS domain network' is set to 'Enabled'" "Network Connections" "Medium" "Medium" "Ensure network bridges are prohibited on domain networks." "Review and enable the policy if not configured."
    }
} catch {
    Add-Result "18.6.11.2" "Error" "Could not check 'Prohibit installation and configuration of Network Bridge on your DNS domain network'. Error: $($_.Exception.Message)" "Ensure 'Prohibit installation and configuration of Network Bridge on your DNS domain network' is set to 'Enabled'" "Network Connections" "Medium" "Medium" "Ensure network bridges are prohibited on domain networks." "Review and enable the policy if not configured."
}

try {
    # Ensure 'Prohibit use of Internet Connection Sharing on your DNS domain network' is set to 'Enabled'
    $internetConnectionSharing = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Network Connections" -Name "NC_AllowICS_NLA" -ErrorAction Stop
    if ($internetConnectionSharing.NC_AllowICS_NLA -eq 0) {
        Add-Result "18.6.11.3" "Pass" "Prohibit use of Internet Connection Sharing on your DNS domain network is set to Enabled." "Ensure 'Prohibit use of Internet Connection Sharing on your DNS domain network' is set to 'Enabled'" "Network Connections" "Medium" "Medium" "Ensure Internet Connection Sharing is prohibited on domain networks." "Review and enable the policy if not configured."
    } else {
        Add-Result "18.6.11.3" "Fail" "Prohibit use of Internet Connection Sharing on your DNS domain network is not set to Enabled." "Ensure 'Prohibit use of Internet Connection Sharing on your DNS domain network' is set to 'Enabled'" "Network Connections" "Medium" "Medium" "Ensure Internet Connection Sharing is prohibited on domain networks." "Review and enable the policy if not configured."
    }
} catch {
    Add-Result "18.6.11.3" "Error" "Could not check 'Prohibit use of Internet Connection Sharing on your DNS domain network'. Error: $($_.Exception.Message)" "Ensure 'Prohibit use of Internet Connection Sharing on your DNS domain network' is set to 'Enabled'" "Network Connections" "Medium" "Medium" "Ensure Internet Connection Sharing is prohibited on domain networks." "Review and enable the policy if not configured."
}

try {
    # Ensure 'Hardened UNC Paths' is set to 'Enabled, with "Require Mutual Authentication", "Require Integrity", and "Require Privacy" set for all NETLOGON and SYSVOL shares'
    $hardenedUNCPaths = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\NetworkProvider\HardenedPaths" -ErrorAction Stop
    if (($hardenedUNCPaths.'\\*\NETLOGON' -like "*RequireMutualAuthentication*") -and 
        ($hardenedUNCPaths.'\\*\SYSVOL' -like "*RequireMutualAuthentication*") -and
        ($hardenedUNCPaths.'\\*\NETLOGON' -like "*RequireIntegrity*") -and
        ($hardenedUNCPaths.'\\*\SYSVOL' -like "*RequireIntegrity*") -and
        ($hardenedUNCPaths.'\\*\NETLOGON' -like "*RequirePrivacy*") -and
        ($hardenedUNCPaths.'\\*\SYSVOL' -like "*RequirePrivacy*")) {
        Add-Result "18.6.14.1" "Pass" "Hardened UNC Paths is configured correctly." "Ensure 'Hardened UNC Paths' is set to 'Enabled, with Require Mutual Authentication, Require Integrity, and Require Privacy set for all NETLOGON and SYSVOL shares'" "Network Provider" "High" "High" "Ensure UNC paths are hardened for enhanced security." "Review and configure the policy if not set."
    } else {
        Add-Result "18.6.14.1" "Fail" "Hardened UNC Paths is not configured correctly." "Ensure 'Hardened UNC Paths' is set to 'Enabled, with Require Mutual Authentication, Require Integrity, and Require Privacy set for all NETLOGON and SYSVOL shares'" "Network Provider" "High" "High" "Ensure UNC paths are hardened for enhanced security." "Review and configure the policy if not set."
    }
} catch {
    Add-Result "18.6.14.1" "Error" "Could not check 'Hardened UNC Paths'. Error: $($_.Exception.Message)" "Ensure 'Hardened UNC Paths' is set to 'Enabled, with Require Mutual Authentication, Require Integrity, and Require Privacy set for all NETLOGON and SYSVOL shares'" "Network Provider" "High" "High" "Ensure UNC paths are hardened for enhanced security." "Review and configure the policy if not set."
}

try {
    # Ensure 'Disable IPv6' (Ensure TCPIP6 Parameter 'DisabledComponents' is set to '0xff (255)')
    $disableIPv6 = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters" -Name "DisabledComponents" -ErrorAction Stop
    if ($disableIPv6.DisabledComponents -eq 255) {
        Add-Result "18.6.19.2.1" "Pass" "IPv6 is disabled (DisabledComponents is set to 0xff)." "Ensure 'Disable IPv6' (Ensure TCPIP6 Parameter 'DisabledComponents' is set to '0xff (255)')" "TCPIP Settings" "Low" "Low" "Ensure IPv6 is disabled for enhanced security." "Review and configure the policy if not set."
    } else {
        Add-Result "18.6.19.2.1" "Fail" "IPv6 is not disabled (DisabledComponents is not set to 0xff)." "Ensure 'Disable IPv6' (Ensure TCPIP6 Parameter 'DisabledComponents' is set to '0xff (255)')" "TCPIP Settings" "Low" "Low" "Ensure IPv6 is disabled for enhanced security." "Review and configure the policy if not set."
    }
} catch {
    Add-Result "18.6.19.2.1" "Error" "Could not check 'Disable IPv6'. Error: $($_.Exception.Message)" "Ensure 'Disable IPv6' (Ensure TCPIP6 Parameter 'DisabledComponents' is set to '0xff (255)')" "TCPIP Settings" "Low" "Low" "Ensure IPv6 is disabled for enhanced security." "Review and configure the policy if not set."
}

try {
    # Ensure 'Configuration of wireless settings using Windows Connect Now' is set to 'Disabled'
    $wirelessConfig = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WCN\Settings" -Name "DisableWcnUi" -ErrorAction Stop
    if ($wirelessConfig.DisableWcnUi -eq 1) {
        Add-Result "18.6.20.1" "Pass" "Configuration of wireless settings using Windows Connect Now is set to Disabled." "Ensure 'Configuration of wireless settings using Windows Connect Now' is set to 'Disabled'" "Windows Connect Now" "Low" "Low" "Ensure wireless settings configuration via Windows Connect Now is disabled to improve security." "Review and disable the policy if not configured."
    } else {
        Add-Result "18.6.20.1" "Fail" "Configuration of wireless settings using Windows Connect Now is not set to Disabled." "Ensure 'Configuration of wireless settings using Windows Connect Now' is set to 'Disabled'" "Windows Connect Now" "Low" "Low" "Ensure wireless settings configuration via Windows Connect Now is disabled to improve security." "Review and disable the policy if not configured."
    }
} catch {
    Add-Result "18.6.20.1" "Error" "Could not check 'Configuration of wireless settings using Windows Connect Now'. Error: $($_.Exception.Message)" "Ensure 'Configuration of wireless settings using Windows Connect Now' is set to 'Disabled'" "Windows Connect Now" "Low" "Low" "Ensure wireless settings configuration via Windows Connect Now is disabled to improve security." "Review and disable the policy if not configured."
}

try {
    # Ensure 'Prohibit access of the Windows Connect Now wizards' is set to 'Enabled'
    $wcnWizards = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WCN\Settings" -Name "DisableWcnAccess" -ErrorAction Stop
    if ($wcnWizards.DisableWcnAccess -eq 1) {
        Add-Result "18.6.20.2" "Pass" "Prohibit access of the Windows Connect Now wizards is set to Enabled." "Ensure 'Prohibit access of the Windows Connect Now wizards' is set to 'Enabled'" "Windows Connect Now" "Low" "Low" "Ensure access to Windows Connect Now wizards is prohibited to improve security." "Review and enable the policy if not configured."
    } else {
        Add-Result "18.6.20.2" "Fail" "Prohibit access of the Windows Connect Now wizards is not set to Enabled." "Ensure 'Prohibit access of the Windows Connect Now wizards' is set to 'Enabled'" "Windows Connect Now" "Low" "Low" "Ensure access to Windows Connect Now wizards is prohibited to improve security." "Review and enable the policy if not configured."
    }
} catch {
    Add-Result "18.6.20.2" "Error" "Could not check 'Prohibit access of the Windows Connect Now wizards'. Error: $($_.Exception.Message)" "Ensure 'Prohibit access of the Windows Connect Now wizards' is set to 'Enabled'" "Windows Connect Now" "Low" "Low" "Ensure access to Windows Connect Now wizards is prohibited to improve security." "Review and enable the policy if not configured."
}

try {
    # Ensure 'Minimize the number of simultaneous connections to the Internet or a Windows Domain' is set to 'Enabled: 3 = Prevent Wi-Fi when on Ethernet'
    $connectionManager = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WcmSvc\GroupPolicy" -Name "fMinimizeConnections" -ErrorAction Stop
    if ($connectionManager.fMinimizeConnections -eq 3) {
        Add-Result "18.6.21.1" "Pass" "Minimize the number of simultaneous connections to the Internet or a Windows Domain is set to 'Enabled: 3 = Prevent Wi-Fi when on Ethernet'." "Ensure 'Minimize the number of simultaneous connections to the Internet or a Windows Domain' is set to 'Enabled: 3 = Prevent Wi-Fi when on Ethernet'" "Windows Connection Manager" "Medium" "Medium" "Ensure the policy minimizes simultaneous connections to prevent security issues." "Review and configure the policy if not set."
    } else {
        Add-Result "18.6.21.1" "Fail" "Minimize the number of simultaneous connections to the Internet or a Windows Domain is not set to 'Enabled: 3 = Prevent Wi-Fi when on Ethernet'." "Ensure 'Minimize the number of simultaneous connections to the Internet or a Windows Domain' is set to 'Enabled: 3 = Prevent Wi-Fi when on Ethernet'" "Windows Connection Manager" "Medium" "Medium" "Ensure the policy minimizes simultaneous connections to prevent security issues." "Review and configure the policy if not set."
    }
} catch {
    Add-Result "18.6.21.1" "Error" "Could not check 'Minimize the number of simultaneous connections to the Internet or a Windows Domain'. Error: $($_.Exception.Message)" "Ensure 'Minimize the number of simultaneous connections to the Internet or a Windows Domain' is set to 'Enabled: 3 = Prevent Wi-Fi when on Ethernet'" "Windows Connection Manager" "Medium" "Medium" "Ensure the policy minimizes simultaneous connections to prevent security issues." "Review and configure the policy if not set."
}

try {
    # Ensure 'Allow Windows to automatically connect to suggested open hotspots, to networks shared by contacts, and to hotspots offering paid services' is set to 'Disabled'
    $autoConnect = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\WcmSvc\GroupPolicy" -Name "AutoConnectAllowed" -ErrorAction Stop
    if ($autoConnect.AutoConnectAllowed -eq 0) {
        Add-Result "18.6.23.2.1" "Pass" "Auto-connect to suggested open hotspots and networks is disabled." "Ensure 'Allow Windows to automatically connect to suggested open hotspots, to networks shared by contacts, and to hotspots offering paid services' is set to 'Disabled'" "WLAN Settings" "High" "High" "Ensure auto-connect is disabled to avoid unauthorized connections." "Review and configure the policy if not set."
    } else {
        Add-Result "18.6.23.2.1" "Fail" "Auto-connect to suggested open hotspots and networks is not disabled." "Ensure 'Allow Windows to automatically connect to suggested open hotspots, to networks shared by contacts, and to hotspots offering paid services' is set to 'Disabled'" "WLAN Settings" "High" "High" "Ensure auto-connect is disabled to avoid unauthorized connections." "Review and configure the policy if not set."
    }
} catch {
    Add-Result "18.6.23.2.1" "Error" "Could not check 'Auto-connect to suggested open hotspots and networks'. Error: $($_.Exception.Message)" "Ensure 'Allow Windows to automatically connect to suggested open hotspots, to networks shared by contacts, and to hotspots offering paid services' is set to 'Disabled'" "WLAN Settings" "High" "High" "Ensure auto-connect is disabled to avoid unauthorized connections." "Review and configure the policy if not set."
}

try {
    # Ensure 'Allow Print Spooler to accept client connections' is set to 'Disabled'
    $printSpooler = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Printers" -Name "DisableServer" -ErrorAction Stop
    if ($printSpooler.DisableServer -eq 1) {
        Add-Result "18.7.1" "Pass" "Print Spooler is set to not accept client connections." "Ensure 'Allow Print Spooler to accept client connections' is set to 'Disabled'" "Printers" "High" "High" "Ensure Print Spooler is configured to enhance security." "Review and disable client connections to Print Spooler."
    } else {
        Add-Result "18.7.1" "Fail" "Print Spooler is set to accept client connections." "Ensure 'Allow Print Spooler to accept client connections' is set to 'Disabled'" "Printers" "High" "High" "Ensure Print Spooler is configured to enhance security." "Review and disable client connections to Print Spooler."
    }
} catch {
    Add-Result "18.7.1" "Error" "Could not check 'Print Spooler client connections'. Error: $($_.Exception.Message)" "Ensure 'Allow Print Spooler to accept client connections' is set to 'Disabled'" "Printers" "High" "High" "Ensure Print Spooler is configured to enhance security." "Review and disable client connections to Print Spooler."
}

try {
    # Ensure 'Configure Redirection Guard' is set to 'Enabled: Redirection Guard Enabled'
    $redirectionGuard = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services" -Name "fEnableRedirectionGuard" -ErrorAction Stop
    if ($redirectionGuard.fEnableRedirectionGuard -eq 1) {
        Add-Result "18.7.2" "Pass" "Redirection Guard is enabled." "Ensure 'Configure Redirection Guard' is set to 'Enabled: Redirection Guard Enabled'" "Printers" "Medium" "Medium" "Ensure Redirection Guard is enabled to prevent unauthorized redirection." "Review and enable Redirection Guard if not configured."
    } else {
        Add-Result "18.7.2" "Fail" "Redirection Guard is not enabled." "Ensure 'Configure Redirection Guard' is set to 'Enabled: Redirection Guard Enabled'" "Printers" "Medium" "Medium" "Ensure Redirection Guard is enabled to prevent unauthorized redirection." "Review and enable Redirection Guard if not configured."
    }
} catch {
    Add-Result "18.7.2" "Error" "Could not check 'Redirection Guard'. Error: $($_.Exception.Message)" "Ensure 'Configure Redirection Guard' is set to 'Enabled: Redirection Guard Enabled'" "Printers" "Medium" "Medium" "Ensure Redirection Guard is enabled to prevent unauthorized redirection." "Review and enable Redirection Guard if not configured."
}

try {
    # Ensure 'Configure RPC connection settings: Protocol to use for outgoing RPC connections' is set to 'Enabled: RPC over TCP'
    $rpcProtocolOutgoing = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Rpc" -Name "RpcUseTcpIp" -ErrorAction Stop
    if ($rpcProtocolOutgoing.RpcUseTcpIp -eq 1) {
        Add-Result "18.7.3" "Pass" "Outgoing RPC connections use RPC over TCP." "Ensure 'Configure RPC connection settings: Protocol to use for outgoing RPC connections' is set to 'Enabled: RPC over TCP'" "Printers" "Medium" "Medium" "Ensure RPC connections use TCP for enhanced security." "Review and configure RPC protocol for outgoing connections."
    } else {
        Add-Result "18.7.3" "Fail" "Outgoing RPC connections do not use RPC over TCP." "Ensure 'Configure RPC connection settings: Protocol to use for outgoing RPC connections' is set to 'Enabled: RPC over TCP'" "Printers" "Medium" "Medium" "Ensure RPC connections use TCP for enhanced security." "Review and configure RPC protocol for outgoing connections."
    }
} catch {
    Add-Result "18.7.3" "Error" "Could not check 'Outgoing RPC protocol'. Error: $($_.Exception.Message)" "Ensure 'Configure RPC connection settings: Protocol to use for outgoing RPC connections' is set to 'Enabled: RPC over TCP'" "Printers" "Medium" "Medium" "Ensure RPC connections use TCP for enhanced security." "Review and configure RPC protocol for outgoing connections."
}

try {
    # Ensure 'Configure RPC connection settings: Use authentication for outgoing RPC connections' is set to 'Enabled: Default'
    $rpcAuthOutgoing = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Rpc" -Name "RpcUseAuthnLevel" -ErrorAction Stop
    if ($rpcAuthOutgoing.RpcUseAuthnLevel -eq 2) {
        Add-Result "18.7.4" "Pass" "Outgoing RPC connections use default authentication." "Ensure 'Configure RPC connection settings: Use authentication for outgoing RPC connections' is set to 'Enabled: Default'" "Printers" "Medium" "Medium" "Ensure outgoing RPC connections use proper authentication." "Review and configure RPC authentication settings."
    } else {
        Add-Result "18.7.4" "Fail" "Outgoing RPC connections do not use default authentication." "Ensure 'Configure RPC connection settings: Use authentication for outgoing RPC connections' is set to 'Enabled: Default'" "Printers" "Medium" "Medium" "Ensure outgoing RPC connections use proper authentication." "Review and configure RPC authentication settings."
    }
} catch {
    Add-Result "18.7.4" "Error" "Could not check 'Outgoing RPC authentication'. Error: $($_.Exception.Message)" "Ensure 'Configure RPC connection settings: Use authentication for outgoing RPC connections' is set to 'Enabled: Default'" "Printers" "Medium" "Medium" "Ensure outgoing RPC connections use proper authentication." "Review and configure RPC authentication settings."
}

try {
    # Ensure 'Limits print driver installation to Administrators' is set to 'Enabled'
    $printDriverAdmin = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Printers" -Name "RestrictDriverInstallationToAdministrators" -ErrorAction Stop
    if ($printDriverAdmin.RestrictDriverInstallationToAdministrators -eq 1) {
        Add-Result "18.7.8" "Pass" "Print driver installation is limited to administrators." "Ensure 'Limits print driver installation to Administrators' is set to 'Enabled'" "Printers" "High" "High" "Ensure only administrators can install print drivers to improve security." "Review and configure the policy if not set."
    } else {
        Add-Result "18.7.8" "Fail" "Print driver installation is not limited to administrators." "Ensure 'Limits print driver installation to Administrators' is set to 'Enabled'" "Printers" "High" "High" "Ensure only administrators can install print drivers to improve security." "Review and configure the policy if not set."
    }
} catch {
    Add-Result "18.7.8" "Error" "Could not check 'Print driver installation policy'. Error: $($_.Exception.Message)" "Ensure 'Limits print driver installation to Administrators' is set to 'Enabled'" "Printers" "High" "High" "Ensure only administrators can install print drivers to improve security." "Review and configure the policy if not set."
}

try {
    # Ensure 'Manage processing of Queue-specific files' is set to 'Enabled: Limit Queue-specific files to Color profiles'
    $queueFilesProcessing = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Printers" -Name "QueueFilesProcessing" -ErrorAction Stop
    if ($queueFilesProcessing.QueueFilesProcessing -eq 1) {
        Add-Result "18.7.9" "Pass" "Queue-specific files processing is limited to Color profiles." "Ensure 'Manage processing of Queue-specific files' is set to 'Enabled: Limit Queue-specific files to Color profiles'" "Printers" "Medium" "Medium" "Ensure processing of Queue-specific files is restricted to improve security." "Review and configure the policy if not set."
    } else {
        Add-Result "18.7.9" "Fail" "Queue-specific files processing is not limited to Color profiles." "Ensure 'Manage processing of Queue-specific files' is set to 'Enabled: Limit Queue-specific files to Color profiles'" "Printers" "Medium" "Medium" "Ensure processing of Queue-specific files is restricted to improve security." "Review and configure the policy if not set."
    }
} catch {
    Add-Result "18.7.9" "Error" "Could not check 'Manage processing of Queue-specific files'. Error: $($_.Exception.Message)" "Ensure 'Manage processing of Queue-specific files' is set to 'Enabled: Limit Queue-specific files to Color profiles'" "Printers" "Medium" "Medium" "Ensure processing of Queue-specific files is restricted to improve security." "Review and configure the policy if not set."
}

try {
    # Ensure 'Point and Print Restrictions: When installing drivers for a new connection' is set to 'Enabled: Show warning and elevation prompt'
    $pointAndPrintNew = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Printers\PointAndPrint" -Name "RestrictDriverInstallationToAdministrators" -ErrorAction Stop
    if ($pointAndPrintNew.RestrictDriverInstallationToAdministrators -eq 1) {
        Add-Result "18.7.10" "Pass" "Point and Print Restrictions for new connections is set to Show warning and elevation prompt." "Ensure 'Point and Print Restrictions: When installing drivers for a new connection' is set to 'Enabled: Show warning and elevation prompt'" "Printers" "High" "High" "Ensure Point and Print Restrictions are configured for secure driver installations." "Review and configure the policy if not set."
    } else {
        Add-Result "18.7.10" "Fail" "Point and Print Restrictions for new connections is not configured properly." "Ensure 'Point and Print Restrictions: When installing drivers for a new connection' is set to 'Enabled: Show warning and elevation prompt'" "Printers" "High" "High" "Ensure Point and Print Restrictions are configured for secure driver installations." "Review and configure the policy if not set."
    }
} catch {
    Add-Result "18.7.10" "Error" "Could not check 'Point and Print Restrictions for new connections'. Error: $($_.Exception.Message)" "Ensure 'Point and Print Restrictions: When installing drivers for a new connection' is set to 'Enabled: Show warning and elevation prompt'" "Printers" "High" "High" "Ensure Point and Print Restrictions are configured for secure driver installations." "Review and configure the policy if not set."
}

try {
    # Ensure 'Point and Print Restrictions: When updating drivers for an existing connection' is set to 'Enabled: Show warning and elevation prompt'
    $pointAndPrintUpdate = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Printers\PointAndPrint" -Name "UpdatePromptSetting" -ErrorAction Stop
    if ($pointAndPrintUpdate.UpdatePromptSetting -eq 1) {
        Add-Result "18.7.11" "Pass" "Point and Print Restrictions for updating drivers is set to Show warning and elevation prompt." "Ensure 'Point and Print Restrictions: When updating drivers for an existing connection' is set to 'Enabled: Show warning and elevation prompt'" "Printers" "High" "High" "Ensure Point and Print Restrictions are configured for secure driver updates." "Review and configure the policy if not set."
    } else {
        Add-Result "18.7.11" "Fail" "Point and Print Restrictions for updating drivers is not configured properly." "Ensure 'Point and Print Restrictions: When updating drivers for an existing connection' is set to 'Enabled: Show warning and elevation prompt'" "Printers" "High" "High" "Ensure Point and Print Restrictions are configured for secure driver updates." "Review and configure the policy if not set."
    }
} catch {
    Add-Result "18.7.11" "Error" "Could not check 'Point and Print Restrictions for updating drivers'. Error: $($_.Exception.Message)" "Ensure 'Point and Print Restrictions: When updating drivers for an existing connection' is set to 'Enabled: Show warning and elevation prompt'" "Printers" "High" "High" "Ensure Point and Print Restrictions are configured for secure driver updates." "Review and configure the policy if not set."
}

try {
    # Ensure 'Turn off notifications network usage' is set to 'Enabled'
    $notificationsUsage = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\System" -Name "DisableNotificationNetworkUsage" -ErrorAction Stop
    if ($notificationsUsage.DisableNotificationNetworkUsage -eq 1) {
        Add-Result "18.8.1.1" "Pass" "Notifications network usage is disabled." "Ensure 'Turn off notifications network usage' is set to 'Enabled'" "Start Menu and Taskbar" "Low" "Low" "Ensure notification network usage is disabled to improve privacy." "Review and enable the policy if not configured."
    } else {
        Add-Result "18.8.1.1" "Fail" "Notifications network usage is not disabled." "Ensure 'Turn off notifications network usage' is set to 'Enabled'" "Start Menu and Taskbar" "Low" "Low" "Ensure notification network usage is disabled to improve privacy." "Review and enable the policy if not configured."
    }
} catch {
    Add-Result "18.8.1.1" "Error" "Could not check 'Notifications network usage'. Error: $($_.Exception.Message)" "Ensure 'Turn off notifications network usage' is set to 'Enabled'" "Start Menu and Taskbar" "Low" "Low" "Ensure notification network usage is disabled to improve privacy." "Review and enable the policy if not configured."
}

try {
    # Ensure 'Remove Personalized Website Recommendations from the Recommended section in the Start Menu' is set to 'Enabled'
    $personalizedRecommendations = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Explorer" -Name "DisableRecommendedSites" -ErrorAction Stop
    if ($personalizedRecommendations.DisableRecommendedSites -eq 1) {
        Add-Result "18.8.2" "Pass" "Personalized website recommendations are removed from the Start Menu." "Ensure 'Remove Personalized Website Recommendations from the Recommended section in the Start Menu' is set to 'Enabled'" "Start Menu and Taskbar" "Low" "Low" "Ensure personalized recommendations are disabled to improve privacy." "Review and enable the policy if not configured."
    } else {
        Add-Result "18.8.2" "Fail" "Personalized website recommendations are not removed from the Start Menu." "Ensure 'Remove Personalized Website Recommendations from the Recommended section in the Start Menu' is set to 'Enabled'" "Start Menu and Taskbar" "Low" "Low" "Ensure personalized recommendations are disabled to improve privacy." "Review and enable the policy if not configured."
    }
} catch {
    Add-Result "18.8.2" "Error" "Could not check 'Personalized website recommendations'. Error: $($_.Exception.Message)" "Ensure 'Remove Personalized Website Recommendations from the Recommended section in the Start Menu' is set to 'Enabled'" "Start Menu and Taskbar" "Low" "Low" "Ensure personalized recommendations are disabled to improve privacy." "Review and enable the policy if not configured."
}

try {
    # Ensure 'Include command line in process creation events' is set to 'Enabled'
    $auditProcessCreation = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\EventLog\Application" -Name "CommandLine" -ErrorAction Stop
    if ($auditProcessCreation.CommandLine -eq 1) {
        Add-Result "18.9.3.1" "Pass" "Command line inclusion in process creation events is enabled." "Ensure 'Include command line in process creation events' is set to 'Enabled'" "Audit Process Creation" "High" "High" "Ensure command line information is captured in process creation events for better auditing." "Review and enable the policy if not configured."
    } else {
        Add-Result "18.9.3.1" "Fail" "Command line inclusion in process creation events is not enabled." "Ensure 'Include command line in process creation events' is set to 'Enabled'" "Audit Process Creation" "High" "High" "Ensure command line information is captured in process creation events for better auditing." "Review and enable the policy if not configured."
    }
} catch {
    Add-Result "18.9.3.1" "Error" "Could not check 'Command line inclusion in process creation events'. Error: $($_.Exception.Message)" "Ensure 'Include command line in process creation events' is set to 'Enabled'" "Audit Process Creation" "High" "High" "Ensure command line information is captured in process creation events for better auditing." "Review and enable the policy if not configured."
}

try {
    # Ensure 'Encryption Oracle Remediation' is set to 'Enabled: Force Updated Clients'
    $encryptionOracleRemediation = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation" -Name "AllowEncryptionOracle" -ErrorAction Stop
    if ($encryptionOracleRemediation.AllowEncryptionOracle -eq 2) {
        Add-Result "18.9.4.1" "Pass" "Encryption Oracle Remediation is set to Force Updated Clients." "Ensure 'Encryption Oracle Remediation' is set to 'Enabled: Force Updated Clients'" "Credentials Delegation" "High" "High" "Ensure proper encryption oracle remediation to improve security." "Review and configure the policy if not set."
    } else {
        Add-Result "18.9.4.1" "Fail" "Encryption Oracle Remediation is not set to Force Updated Clients." "Ensure 'Encryption Oracle Remediation' is set to 'Enabled: Force Updated Clients'" "Credentials Delegation" "High" "High" "Ensure proper encryption oracle remediation to improve security." "Review and configure the policy if not set."
    }
} catch {
    Add-Result "18.9.4.1" "Error" "Could not check 'Encryption Oracle Remediation'. Error: $($_.Exception.Message)" "Ensure 'Encryption Oracle Remediation' is set to 'Enabled: Force Updated Clients'" "Credentials Delegation" "High" "High" "Ensure proper encryption oracle remediation to improve security." "Review and configure the policy if not set."
}

try {
    # Ensure 'Remote host allows delegation of non-exportable credentials' is set to 'Enabled'
    $delegationOfCredentials = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation" -Name "AllowProtectedCreds" -ErrorAction Stop
    if ($delegationOfCredentials.AllowProtectedCreds -eq 1) {
        Add-Result "18.9.4.2" "Pass" "Delegation of non-exportable credentials is enabled." "Ensure 'Remote host allows delegation of non-exportable credentials' is set to 'Enabled'" "Credentials Delegation" "High" "High" "Ensure proper delegation settings for non-exportable credentials to improve security." "Review and configure the policy if not set."
    } else {
        Add-Result "18.9.4.2" "Fail" "Delegation of non-exportable credentials is not enabled." "Ensure 'Remote host allows delegation of non-exportable credentials' is set to 'Enabled'" "Credentials Delegation" "High" "High" "Ensure proper delegation settings for non-exportable credentials to improve security." "Review and configure the policy if not set."
    }
} catch {
    Add-Result "18.9.4.2" "Error" "Could not check 'Delegation of non-exportable credentials'. Error: $($_.Exception.Message)" "Ensure 'Remote host allows delegation of non-exportable credentials' is set to 'Enabled'" "Credentials Delegation" "High" "High" "Ensure proper delegation settings for non-exportable credentials to improve security." "Review and configure the policy if not set."
}

try {
    # Ensure 'Turn On Virtualization Based Security' is set to 'Enabled'
    $vbsEnabled = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceGuard" -Name "EnableVirtualizationBasedSecurity" -ErrorAction Stop
    if ($vbsEnabled.EnableVirtualizationBasedSecurity -eq 1) {
        Add-Result "18.9.5.1" "Pass" "Virtualization Based Security is enabled." "Ensure 'Turn On Virtualization Based Security' is set to 'Enabled'" "Device Guard" "High" "High" "Ensure Virtualization Based Security is enabled for improved protection." "Review and configure the policy if not set."
    } else {
        Add-Result "18.9.5.1" "Fail" "Virtualization Based Security is not enabled." "Ensure 'Turn On Virtualization Based Security' is set to 'Enabled'" "Device Guard" "High" "High" "Ensure Virtualization Based Security is enabled for improved protection." "Review and configure the policy if not set."
    }
} catch {
    Add-Result "18.9.5.1" "Error" "Could not check 'Virtualization Based Security'. Error: $($_.Exception.Message)" "Ensure 'Turn On Virtualization Based Security' is set to 'Enabled'" "Device Guard" "High" "High" "Ensure Virtualization Based Security is enabled for improved protection." "Review and configure the policy if not set."
}

try {
    # Ensure 'Turn On Virtualization Based Security: Select Platform Security Level' is set to 'Secure Boot' or higher
    $vbsPlatformLevel = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceGuard" -Name "PlatformSecurityLevel" -ErrorAction Stop
    if ($vbsPlatformLevel.PlatformSecurityLevel -ge 1) {
        Add-Result "18.9.5.2" "Pass" "Platform Security Level is set to Secure Boot or higher." "Ensure 'Turn On Virtualization Based Security: Select Platform Security Level' is set to 'Secure Boot' or higher" "Device Guard" "High" "High" "Ensure the platform security level is configured correctly for improved protection." "Review and configure the policy if not set."
    } else {
        Add-Result "18.9.5.2" "Fail" "Platform Security Level is not set to Secure Boot or higher." "Ensure 'Turn On Virtualization Based Security: Select Platform Security Level' is set to 'Secure Boot' or higher" "Device Guard" "High" "High" "Ensure the platform security level is configured correctly for improved protection." "Review and configure the policy if not set."
    }
} catch {
    Add-Result "18.9.5.2" "Error" "Could not check 'Platform Security Level'. Error: $($_.Exception.Message)" "Ensure 'Turn On Virtualization Based Security: Select Platform Security Level' is set to 'Secure Boot' or higher" "Device Guard" "High" "High" "Ensure the platform security level is configured correctly for improved protection." "Review and configure the policy if not set."
}

try {
    # Ensure 'Turn On Virtualization Based Security: Virtualization Based Protection of Code Integrity' is set to 'Enabled with UEFI lock'
    $vbsCodeIntegrity = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceGuard" -Name "HypervisorEnforcedCodeIntegrity" -ErrorAction Stop
    if ($vbsCodeIntegrity.HypervisorEnforcedCodeIntegrity -eq 2) {
        Add-Result "18.9.5.3" "Pass" "Virtualization Based Protection of Code Integrity is set to Enabled with UEFI lock." "Ensure 'Turn On Virtualization Based Security: Virtualization Based Protection of Code Integrity' is set to 'Enabled with UEFI lock'" "Device Guard" "High" "High" "Ensure Code Integrity is enforced with UEFI lock for improved protection." "Review and configure the policy if not set."
    } else {
        Add-Result "18.9.5.3" "Fail" "Virtualization Based Protection of Code Integrity is not set to Enabled with UEFI lock." "Ensure 'Turn On Virtualization Based Security: Virtualization Based Protection of Code Integrity' is set to 'Enabled with UEFI lock'" "Device Guard" "High" "High" "Ensure Code Integrity is enforced with UEFI lock for improved protection." "Review and configure the policy if not set."
    }
} catch {
    Add-Result "18.9.5.3" "Error" "Could not check 'Virtualization Based Protection of Code Integrity'. Error: $($_.Exception.Message)" "Ensure 'Turn On Virtualization Based Security: Virtualization Based Protection of Code Integrity' is set to 'Enabled with UEFI lock'" "Device Guard" "High" "High" "Ensure Code Integrity is enforced with UEFI lock for improved protection." "Review and configure the policy if not set."
}

try {
    # Ensure 'Turn On Virtualization Based Security: Require UEFI Memory Attributes Table' is set to 'True (checked)'
    $uefiMemoryAttributes = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceGuard" -Name "RequirePlatformSecurityFeatures" -ErrorAction Stop
    if ($uefiMemoryAttributes.RequirePlatformSecurityFeatures -eq 3) {
        Add-Result "18.9.5.4" "Pass" "UEFI Memory Attributes Table requirement is set to True." "Ensure 'Turn On Virtualization Based Security: Require UEFI Memory Attributes Table' is set to 'True (checked)'" "Device Guard" "High" "High" "Ensure UEFI Memory Attributes Table is enforced for improved protection." "Review and configure the policy if not set."
    } else {
        Add-Result "18.9.5.4" "Fail" "UEFI Memory Attributes Table requirement is not set to True." "Ensure 'Turn On Virtualization Based Security: Require UEFI Memory Attributes Table' is set to 'True (checked)'" "Device Guard" "High" "High" "Ensure UEFI Memory Attributes Table is enforced for improved protection." "Review and configure the policy if not set."
    }
} catch {
    Add-Result "18.9.5.4" "Error" "Could not check 'UEFI Memory Attributes Table'. Error: $($_.Exception.Message)" "Ensure 'Turn On Virtualization Based Security: Require UEFI Memory Attributes Table' is set to 'True (checked)'" "Device Guard" "High" "High" "Ensure UEFI Memory Attributes Table is enforced for improved protection." "Review and configure the policy if not set."
}

try {
    # Ensure 'Turn On Virtualization Based Security: Secure Launch Configuration' is set to 'Enabled'
    $secureLaunchConfig = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceGuard" -Name "EnableSecureLaunch" -ErrorAction Stop
    if ($secureLaunchConfig.EnableSecureLaunch -eq 1) {
        Add-Result "18.9.5.6" "Pass" "Secure Launch Configuration is enabled." "Ensure 'Turn On Virtualization Based Security: Secure Launch Configuration' is set to 'Enabled'" "Device Guard" "High" "High" "Ensure Secure Launch Configuration is enabled for improved protection." "Review and configure the policy if not set."
    } else {
        Add-Result "18.9.5.6" "Fail" "Secure Launch Configuration is not enabled." "Ensure 'Turn On Virtualization Based Security: Secure Launch Configuration' is set to 'Enabled'" "Device Guard" "High" "High" "Ensure Secure Launch Configuration is enabled for improved protection." "Review and configure the policy if not set."
    }
} catch {
    Add-Result "18.9.5.6" "Error" "Could not check 'Secure Launch Configuration'. Error: $($_.Exception.Message)" "Ensure 'Turn On Virtualization Based Security: Secure Launch Configuration' is set to 'Enabled'" "Device Guard" "High" "High" "Ensure Secure Launch Configuration is enabled for improved protection." "Review and configure the policy if not set."
}

try {
    # Ensure 'Turn On Virtualization Based Security: Kernel-mode Hardware-enforced Stack Protection' is set to 'Enabled: Enabled in enforcement mode'
    $kernelStackProtection = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceGuard" -Name "KernelModeStackProtection" -ErrorAction Stop
    if ($kernelStackProtection.KernelModeStackProtection -eq 2) {
        Add-Result "18.9.5.7" "Pass" "Kernel-mode Hardware-enforced Stack Protection is set to Enabled in enforcement mode." "Ensure 'Turn On Virtualization Based Security: Kernel-mode Hardware-enforced Stack Protection' is set to 'Enabled: Enabled in enforcement mode'" "Device Guard" "High" "High" "Ensure Kernel-mode Stack Protection is enabled for improved security." "Review and configure the policy if not set."
    } else {
        Add-Result "18.9.5.7" "Fail" "Kernel-mode Hardware-enforced Stack Protection is not set to Enabled in enforcement mode." "Ensure 'Turn On Virtualization Based Security: Kernel-mode Hardware-enforced Stack Protection' is set to 'Enabled: Enabled in enforcement mode'" "Device Guard" "High" "High" "Ensure Kernel-mode Stack Protection is enabled for improved security." "Review and configure the policy if not set."
    }
} catch {
    Add-Result "18.9.5.7" "Error" "Could not check 'Kernel-mode Hardware-enforced Stack Protection'. Error: $($_.Exception.Message)" "Ensure 'Turn On Virtualization Based Security: Kernel-mode Hardware-enforced Stack Protection' is set to 'Enabled: Enabled in enforcement mode'" "Device Guard" "High" "High" "Ensure Kernel-mode Stack Protection is enabled for improved security." "Review and configure the policy if not set."
}

try {
    # Ensure 'Prevent installation of devices that match any of these device IDs' is set to 'Enabled'
    $preventDeviceIds = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceInstall\Restrictions" -Name "DenyDeviceIDs" -ErrorAction Stop
    if ($preventDeviceIds -ne $null) {
        Add-Result "18.9.7.1.1" "Pass" "Prevent installation of devices that match any of these device IDs is set to Enabled." "Ensure 'Prevent installation of devices that match any of these device IDs' is set to 'Enabled'" "Device Installation" "High" "High" "Ensure restricted devices are blocked from installation." "Review and configure the policy if not set."
    } else {
        Add-Result "18.9.7.1.1" "Fail" "Prevent installation of devices that match any of these device IDs is not set." "Ensure 'Prevent installation of devices that match any of these device IDs' is set to 'Enabled'" "Device Installation" "High" "High" "Ensure restricted devices are blocked from installation." "Review and configure the policy if not set."
    }
} catch {
    Add-Result "18.9.7.1.1" "Error" "Could not check 'Prevent installation of devices that match any of these device IDs'. Error: $($_.Exception.Message)" "Ensure 'Prevent installation of devices that match any of these device IDs' is set to 'Enabled'" "Device Installation" "High" "High" "Ensure restricted devices are blocked from installation." "Review and configure the policy if not set."
}

try {
    # Ensure 'Prevent installation of devices that match any of these device IDs: PCI\CC_0C0A'
    $preventDeviceSpecific = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceInstall\Restrictions" -Name "DenyDeviceIDList" -ErrorAction Stop
    if ($preventDeviceSpecific -like "*PCI\CC_0C0A*") {
        Add-Result "18.9.7.1.2" "Pass" "Device installation restriction includes PCI\\CC_0C0A." "Ensure 'Prevent installation of devices that match any of these device IDs: PCI\CC_0C0A'" "Device Installation" "High" "High" "Ensure devices matching PCI\\CC_0C0A are restricted from installation." "Review and configure the policy if not set."
    } else {
        Add-Result "18.9.7.1.2" "Fail" "Device installation restriction does not include PCI\\CC_0C0A." "Ensure 'Prevent installation of devices that match any of these device IDs: PCI\CC_0C0A'" "Device Installation" "High" "High" "Ensure devices matching PCI\\CC_0C0A are restricted from installation." "Review and configure the policy if not set."
    }
} catch {
    Add-Result "18.9.7.1.2" "Error" "Could not check 'Prevent installation of devices that match any of these device IDs: PCI\CC_0C0A'. Error: $($_.Exception.Message)" "Ensure 'Prevent installation of devices that match any of these device IDs: PCI\CC_0C0A'" "Device Installation" "High" "High" "Ensure devices matching PCI\\CC_0C0A are restricted from installation." "Review and configure the policy if not set."
}

try {
    # Ensure 'Prevent installation of devices that match any of these device IDs: Also apply to matching devices that are already installed' is set to 'True'
    $applyToInstalled = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceInstall\Restrictions" -Name "DenyDeviceIDListPolicy" -ErrorAction Stop
    if ($applyToInstalled -eq 1) {
        Add-Result "18.9.7.1.3" "Pass" "Policy is applied to matching devices that are already installed." "Ensure 'Prevent installation of devices that match any of these device IDs: Also apply to matching devices that are already installed.' is set to 'True'" "Device Installation" "High" "High" "Ensure policy applies to existing matching devices." "Review and configure the policy if not set."
    } else {
        Add-Result "18.9.7.1.3" "Fail" "Policy is not applied to matching devices that are already installed." "Ensure 'Prevent installation of devices that match any of these device IDs: Also apply to matching devices that are already installed.' is set to 'True'" "Device Installation" "High" "High" "Ensure policy applies to existing matching devices." "Review and configure the policy if not set."
    }
} catch {
    Add-Result "18.9.7.1.3" "Error" "Could not check 'Prevent installation of devices that match any of these device IDs: Also apply to matching devices that are already installed'. Error: $($_.Exception.Message)" "Ensure 'Prevent installation of devices that match any of these device IDs: Also apply to matching devices that are already installed.' is set to 'True'" "Device Installation" "High" "High" "Ensure policy applies to existing matching devices." "Review and configure the policy if not set."
}

try {
    # Ensure 'Prevent installation of devices using drivers that match these device setup classes' is set to 'Enabled'
    $denySetupClasses = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceInstall\Restrictions" -Name "DenySetupClasses" -ErrorAction Stop
    if ($denySetupClasses -ne $null) {
        Add-Result "18.9.7.1.4" "Pass" "Device installation restriction by setup classes is enabled." "Ensure 'Prevent installation of devices using drivers that match these device setup classes' is set to 'Enabled'" "Device Installation" "High" "High" "Ensure restricted setup classes are blocked from installation." "Review and configure the policy if not set."
    } else {
        Add-Result "18.9.7.1.4" "Fail" "Device installation restriction by setup classes is not enabled." "Ensure 'Prevent installation of devices using drivers that match these device setup classes' is set to 'Enabled'" "Device Installation" "High" "High" "Ensure restricted setup classes are blocked from installation." "Review and configure the policy if not set."
    }
} catch {
    Add-Result "18.9.7.1.4" "Error" "Could not check 'Prevent installation of devices using drivers that match these device setup classes'. Error: $($_.Exception.Message)" "Ensure 'Prevent installation of devices using drivers that match these device setup classes' is set to 'Enabled'" "Device Installation" "High" "High" "Ensure restricted setup classes are blocked from installation." "Review and configure the policy if not set."
}

try {
    # Ensure 'Prevent installation of devices using drivers that match these device setup classes: IEEE 1394 device setup classes'
    $denySpecificSetupClasses = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceInstall\Restrictions" -Name "DenySetupClassList" -ErrorAction Stop
    if ($denySpecificSetupClasses -like "*IEEE 1394*") {
        Add-Result "18.9.7.1.5" "Pass" "IEEE 1394 setup class is included in the restriction list." "Ensure 'Prevent installation of devices using drivers that match these device setup classes: IEEE 1394 device setup classes'" "Device Installation" "High" "High" "Ensure IEEE 1394 setup class devices are restricted." "Review and configure the policy if not set."
    } else {
        Add-Result "18.9.7.1.5" "Fail" "IEEE 1394 setup class is not included in the restriction list." "Ensure 'Prevent installation of devices using drivers that match these device setup classes: IEEE 1394 device setup classes'" "Device Installation" "High" "High" "Ensure IEEE 1394 setup class devices are restricted." "Review and configure the policy if not set."
    }
} catch {
    Add-Result "18.9.7.1.5" "Error" "Could not check 'Prevent installation of devices using drivers that match these device setup classes: IEEE 1394 device setup classes'. Error: $($_.Exception.Message)" "Ensure 'Prevent installation of devices using drivers that match these device setup classes: IEEE 1394 device setup classes'" "Device Installation" "High" "High" "Ensure IEEE 1394 setup class devices are restricted." "Review and configure the policy if not set."
}

try {
    # Ensure 'Prevent installation of devices using drivers that match these device setup classes: Also apply to matching devices that are already installed.' is set to 'True'
    $applySetupClassesToInstalled = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceInstall\Restrictions" -Name "DenySetupClassPolicy" -ErrorAction Stop
    if ($applySetupClassesToInstalled -eq 1) {
        Add-Result "18.9.7.1.6" "Pass" "Policy for matching setup classes applies to already installed devices." "Ensure 'Prevent installation of devices using drivers that match these device setup classes: Also apply to matching devices that are already installed.' is set to 'True'" "Device Installation" "High" "High" "Ensure policy for setup classes applies to already installed devices." "Review and configure the policy if not set."
    } else {
        Add-Result "18.9.7.1.6" "Fail" "Policy for matching setup classes does not apply to already installed devices." "Ensure 'Prevent installation of devices using drivers that match these device setup classes: Also apply to matching devices that are already installed.' is set to 'True'" "Device Installation" "High" "High" "Ensure policy for setup classes applies to already installed devices." "Review and configure the policy if not set."
    }
} catch {
    Add-Result "18.9.7.1.6" "Error" "Could not check 'Prevent installation of devices using drivers that match these device setup classes: Also apply to matching devices that are already installed'. Error: $($_.Exception.Message)" "Ensure 'Prevent installation of devices using drivers that match these device setup classes: Also apply to matching devices that are already installed.' is set to 'True'" "Device Installation" "High" "High" "Ensure policy for setup classes applies to already installed devices." "Review and configure the policy if not set."
}

try {
    # Ensure 'Prevent device metadata retrieval from the Internet' is set to 'Enabled'
    $deviceMetadata = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Device Metadata" -Name "PreventDeviceMetadataFromNetwork" -ErrorAction Stop
    if ($deviceMetadata.PreventDeviceMetadataFromNetwork -eq 1) {
        Add-Result "18.9.7.2" "Pass" "Device metadata retrieval from the Internet is disabled." "Ensure 'Prevent device metadata retrieval from the Internet' is set to 'Enabled'" "Device Installation" "Medium" "Medium" "Ensure device metadata is not retrieved from the Internet for improved security." "Review and configure the policy if not set."
    } else {
        Add-Result "18.9.7.2" "Fail" "Device metadata retrieval from the Internet is not disabled." "Ensure 'Prevent device metadata retrieval from the Internet' is set to 'Enabled'" "Device Installation" "Medium" "Medium" "Ensure device metadata is not retrieved from the Internet for improved security." "Review and configure the policy if not set."
    }
} catch {
    Add-Result "18.9.7.2" "Error" "Could not check 'Prevent device metadata retrieval from the Internet'. Error: $($_.Exception.Message)" "Ensure 'Prevent device metadata retrieval from the Internet' is set to 'Enabled'" "Device Installation" "Medium" "Medium" "Ensure device metadata is not retrieved from the Internet for improved security." "Review and configure the policy if not set."
}


#19th 
try {
    # Ensure 'Turn off toast notifications on the lock screen' is set to 'Enabled'
    $toastNotifications = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\System" -Name "DisableLockScreenAppNotifications" -ErrorAction Stop
    if ($toastNotifications.DisableLockScreenAppNotifications -eq 1) {
        Add-Result "19.5.1.1" "Pass" "Toast notifications on the lock screen are turned off." "Ensure 'Turn off toast notifications on the lock screen' is set to 'Enabled'" "Start Menu and Taskbar" "Medium" "Medium" "Ensure toast notifications on the lock screen are disabled for privacy and security." "Review and configure the policy if not set."
    } else {
        Add-Result "19.5.1.1" "Fail" "Toast notifications on the lock screen are not turned off." "Ensure 'Turn off toast notifications on the lock screen' is set to 'Enabled'" "Start Menu and Taskbar" "Medium" "Medium" "Ensure toast notifications on the lock screen are disabled for privacy and security." "Review and configure the policy if not set."
    }
} catch {
    Add-Result "19.5.1.1" "Error" "Could not check 'Turn off toast notifications on the lock screen'. Error: $($_.Exception.Message)" "Ensure 'Turn off toast notifications on the lock screen' is set to 'Enabled'" "Start Menu and Taskbar" "Medium" "Medium" "Ensure toast notifications on the lock screen are disabled for privacy and security." "Review and configure the policy if not set."
}

try {
    # Ensure 'Turn off Help Experience Improvement Program' is set to 'Enabled'
    $helpExperience = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Assistance\Client\1.0" -Name "NoCEIP" -ErrorAction Stop
    if ($helpExperience.NoCEIP -eq 1) {
        Add-Result "19.6.6.1.1" "Pass" "Help Experience Improvement Program is turned off." "Ensure 'Turn off Help Experience Improvement Program' is set to 'Enabled'" "Internet Communication Management" "Low" "Low" "Ensure the Help Experience Improvement Program is disabled to improve privacy." "Review and configure the policy if not set."
    } else {
        Add-Result "19.6.6.1.1" "Fail" "Help Experience Improvement Program is not turned off." "Ensure 'Turn off Help Experience Improvement Program' is set to 'Enabled'" "Internet Communication Management" "Low" "Low" "Ensure the Help Experience Improvement Program is disabled to improve privacy." "Review and configure the policy if not set."
    }
} catch {
    Add-Result "19.6.6.1.1" "Error" "Could not check 'Turn off Help Experience Improvement Program'. Error: $($_.Exception.Message)" "Ensure 'Turn off Help Experience Improvement Program' is set to 'Enabled'" "Internet Communication Management" "Low" "Low" "Ensure the Help Experience Improvement Program is disabled to improve privacy." "Review and configure the policy if not set."
}

try {
    # Ensure 'Do not preserve zone information in file attachments' is set to 'Disabled'
    $zoneInformation = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Attachments" -Name "SaveZoneInformation" -ErrorAction Stop
    if ($zoneInformation.SaveZoneInformation -eq 2) {
        Add-Result "19.7.5.1" "Pass" "Zone information in file attachments is not preserved." "Ensure 'Do not preserve zone information in file attachments' is set to 'Disabled'" "Attachment Manager" "Medium" "Medium" "Ensure zone information is preserved to improve attachment security." "Review and configure the policy if not set."
    } else {
        Add-Result "19.7.5.1" "Fail" "Zone information in file attachments is preserved." "Ensure 'Do not preserve zone information in file attachments' is set to 'Disabled'" "Attachment Manager" "Medium" "Medium" "Ensure zone information is preserved to improve attachment security." "Review and configure the policy if not set."
    }
} catch {
    Add-Result "19.7.5.1" "Error" "Could not check 'Do not preserve zone information in file attachments'. Error: $($_.Exception.Message)" "Ensure 'Do not preserve zone information in file attachments' is set to 'Disabled'" "Attachment Manager" "Medium" "Medium" "Ensure zone information is preserved to improve attachment security." "Review and configure the policy if not set."
}

try {
    # Ensure 'Notify antivirus programs when opening attachments' is set to 'Enabled'
    $notifyAntivirus = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Attachments" -Name "ScanWithAntiVirus" -ErrorAction Stop
    if ($notifyAntivirus.ScanWithAntiVirus -eq 1) {
        Add-Result "19.7.5.2" "Pass" "Antivirus programs are notified when opening attachments." "Ensure 'Notify antivirus programs when opening attachments' is set to 'Enabled'" "Attachment Manager" "High" "High" "Ensure antivirus programs are notified for attachment scanning." "Review and configure the policy if not set."
    } else {
        Add-Result "19.7.5.2" "Fail" "Antivirus programs are not notified when opening attachments." "Ensure 'Notify antivirus programs when opening attachments' is set to 'Enabled'" "Attachment Manager" "High" "High" "Ensure antivirus programs are notified for attachment scanning." "Review and configure the policy if not set."
    }
} catch {
    Add-Result "19.7.5.2" "Error" "Could not check 'Notify antivirus programs when opening attachments'. Error: $($_.Exception.Message)" "Ensure 'Notify antivirus programs when opening attachments' is set to 'Enabled'" "Attachment Manager" "High" "High" "Ensure antivirus programs are notified for attachment scanning." "Review and configure the policy if not set."
}

try {
    # Ensure 'Prevent users from sharing files within their profile.' is set to 'Enabled'
    $preventFileSharing = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\NetworkProvider\HardenedPaths" -Name "Sharing" -ErrorAction Stop
    if ($preventFileSharing.Sharing -eq 1) {
        Add-Result "19.7.26.1" "Pass" "Users are prevented from sharing files within their profile." "Ensure 'Prevent users from sharing files within their profile.' is set to 'Enabled'" "Windows Components - Network Sharing" "Medium" "Medium" "Ensure file sharing within user profiles is disabled for improved security." "Review and configure the policy if not set."
    } else {
        Add-Result "19.7.26.1" "Fail" "Users are not prevented from sharing files within their profile." "Ensure 'Prevent users from sharing files within their profile.' is set to 'Enabled'" "Windows Components - Network Sharing" "Medium" "Medium" "Ensure file sharing within user profiles is disabled for improved security." "Review and configure the policy if not set."
    }
} catch {
    Add-Result "19.7.26.1" "Error" "Could not check 'Prevent users from sharing files within their profile.'. Error: $($_.Exception.Message)" "Ensure 'Prevent users from sharing files within their profile.' is set to 'Enabled'" "Windows Components - Network Sharing" "Medium" "Medium" "Ensure file sharing within user profiles is disabled for improved security." "Review and configure the policy if not set."
}

try {
    # Ensure 'Turn off Windows Copilot' is set to 'Enabled'
    $windowsCopilot = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsCopilot" -Name "TurnOffWindowsCopilot" -ErrorAction Stop
    if ($windowsCopilot.TurnOffWindowsCopilot -eq 1) {
        Add-Result "19.7.38.1" "Pass" "Windows Copilot is turned off." "Ensure 'Turn off Windows Copilot' is set to 'Enabled'" "Windows Components - Windows Copilot" "Medium" "Medium" "Ensure Windows Copilot is disabled to improve user privacy and security." "Review and configure the policy if not set."
    } else {
        Add-Result "19.7.38.1" "Fail" "Windows Copilot is not turned off." "Ensure 'Turn off Windows Copilot' is set to 'Enabled'" "Windows Components - Windows Copilot" "Medium" "Medium" "Ensure Windows Copilot is disabled to improve user privacy and security." "Review and configure the policy if not set."
    }
} catch {
    Add-Result "19.7.38.1" "Error" "Could not check 'Turn off Windows Copilot'. Error: $($_.Exception.Message)" "Ensure 'Turn off Windows Copilot' is set to 'Enabled'" "Windows Components - Windows Copilot" "Medium" "Medium" "Ensure Windows Copilot is disabled to improve user privacy and security." "Review and configure the policy if not set."
}

try {
    # Ensure 'Always install with elevated privileges' is set to 'Disabled'
    $elevatedPrivileges = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Installer" -Name "AlwaysInstallElevated" -ErrorAction Stop
    if ($elevatedPrivileges.AlwaysInstallElevated -eq 0) {
        Add-Result "19.7.42.1" "Pass" "Always install with elevated privileges is disabled." "Ensure 'Always install with elevated privileges' is set to 'Disabled'" "Windows Components - Windows Installer" "High" "High" "Ensure elevated privileges for installation are disabled to reduce potential security risks." "Review and configure the policy if not set."
    } else {
        Add-Result "19.7.42.1" "Fail" "Always install with elevated privileges is not disabled." "Ensure 'Always install with elevated privileges' is set to 'Disabled'" "Windows Components - Windows Installer" "High" "High" "Ensure elevated privileges for installation are disabled to reduce potential security risks." "Review and configure the policy if not set."
    }
} catch {
    Add-Result "19.7.42.1" "Error" "Could not check 'Always install with elevated privileges'. Error: $($_.Exception.Message)" "Ensure 'Always install with elevated privileges' is set to 'Disabled'" "Windows Components - Windows Installer" "High" "High" "Ensure elevated privileges for installation are disabled to reduce potential security risks." "Review and configure the policy if not set."
}

try {
    # Ensure 'Prevent Codec Download' is set to 'Enabled'
    $codecDownload = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\WindowsMediaPlayer" -Name "PreventCodecDownload" -ErrorAction Stop
    if ($codecDownload.PreventCodecDownload -eq 1) {
        Add-Result "19.7.44.2.1" "Pass" "Codec downloads are prevented." "Ensure 'Prevent Codec Download' is set to 'Enabled'" "Windows Media Player - Playback" "Low" "Low" "Ensure codec downloads are disabled to avoid unnecessary risks." "Review and configure the policy if not set."
    } else {
        Add-Result "19.7.44.2.1" "Fail" "Codec downloads are not prevented." "Ensure 'Prevent Codec Download' is set to 'Enabled'" "Windows Media Player - Playback" "Low" "Low" "Ensure codec downloads are disabled to avoid unnecessary risks." "Review and configure the policy if not set."
    }
} catch {
    Add-Result "19.7.44.2.1" "Error" "Could not check 'Prevent Codec Download'. Error: $($_.Exception.Message)" "Ensure 'Prevent Codec Download' is set to 'Enabled'" "Windows Media Player - Playback" "Low" "Low" "Ensure codec downloads are disabled to avoid unnecessary risks." "Review and configure the policy if not set."
}

# Final completion status
Add-Result "Completion" "Complete" "Audit completed successfully." "Audit completion status" "Audit" "N/A" "N/A" "N/A" "N/A"

# Generate report metadata
$reportMetadata = @{
    report_title = "Extended Compliance Report"
    generated_by = "System Auditor"
    generated_on = (Get-Date).ToString("o")
    audit_scope = "Windows 11"
    report_version = "2.0"
}

# Generate summary
$controlEntries = $auditResults.GetEnumerator() | Where-Object { $_.Key -ne "Completion" } # Exclude completion entry
$totalControls = $controlEntries.Count
$compliantControls = ($controlEntries | Where-Object { $_.Value.Status -eq "Pass" }).Count
$nonCompliantControls = $totalControls - $compliantControls
$compliancePercentage = if ($totalControls -ne 0) {
    [math]::Round(($compliantControls / $totalControls) * 100, 2)
} else {
    0
}

$severityBreakdown = @{
    High = ($controlEntries | Where-Object { $_.Value.Severity -eq "High" }).Count
    Medium = ($controlEntries | Where-Object { $_.Value.Severity -eq "Medium" }).Count
    Low = ($controlEntries | Where-Object { $_.Value.Severity -eq "Low" }).Count
}

$priorityBreakdown = @{
    High = ($controlEntries | Where-Object { $_.Value.Priority -eq "High" }).Count
    Medium = ($controlEntries | Where-Object { $_.Value.Priority -eq "Medium" }).Count
    Low = ($controlEntries | Where-Object { $_.Value.Priority -eq "Low" }).Count
}

$summary = @{
    total_controls = $totalControls
    compliant_controls = $compliantControls
    non_compliant_controls = $nonCompliantControls
    compliance_percentage = $compliancePercentage
    severity_breakdown = $severityBreakdown
    priority_breakdown = $priorityBreakdown
}

# Generate detailed findings
$detailedFindings = $auditResults.GetEnumerator() | ForEach-Object {
    @{
        control_id = $_.Key
        description = $_.Value.Description
        category = $_.Value.Category
        priority = $_.Value.Priority
        severity = $_.Value.Severity
        is_compliant = ($_.Value.Status -eq "Pass")
        frequency_checked = 1
        non_compliant_occurrences = if ($_.Value.Status -eq "Pass") { 0 } else { 1 }
        non_compliance_reasons = if ($_.Value.Status -eq "Pass") { @() } else { @($_.Value.Message) }
        recommendation = $_.Value.Recommendation
        corrective_action = $_.Value.CorrectiveAction
        last_checked = $_.Value.LastChecked
        priority_score = switch ($_.Value.Priority) {
            "High" { 3 }
            "Medium" { 2 }
            "Low" { 1 }
            default { 0 }
        }
        severity_score = switch ($_.Value.Severity) {
            "High" { 3 }
            "Medium" { 2 }
            "Low" { 1 }
            default { 0 }
        }
    }
}

# Generate categorized results
$categorizedResults = @{
    "Account Policy" = @{
        "Password Policy" = $detailedFindings | Where-Object { $_.category -eq "Password Policy" }
        "Account Lockout Policy" = $detailedFindings | Where-Object { $_.category -eq "Account Lockout Policy" }
    }
    "Local Policies" = @{
        "Audit Policy" = $detailedFindings | Where-Object { $_.category -eq "Audit Policy" }
        "User Rights Assignment" = $detailedFindings | Where-Object { $_.category -eq "User Rights Assignment" }
        "Security Options" = $detailedFindings | Where-Object { $_.category -eq "Security Options" }
        "Accounts" = $detailedFindings | Where-Object { $_.category -eq "Accounts" }
        "Audit" = $detailedFindings | Where-Object { $_.category -eq "Audit" }
        "DCOM" = $detailedFindings | Where-Object { $_.category -eq "DCOM" }
        "Devices" = $detailedFindings | Where-Object { $_.category -eq "Devices" }
        "Domain controller" = $detailedFindings | Where-Object { $_.category -eq "Domain controller" }
        "Domain member" = $detailedFindings | Where-Object { $_.category -eq "Domain member" }
        "Interactive logon" = $detailedFindings | Where-Object { $_.category -eq "Interactive logon" }
        "Microsoft network client" = $detailedFindings | Where-Object { $_.category -eq "Microsoft network client" }
        "Microsoft network server" = $detailedFindings | Where-Object { $_.category -eq "Microsoft network server" }
        "Network access" = $detailedFindings | Where-Object { $_.category -eq "Network access" }
        "Network security" = $detailedFindings | Where-Object { $_.category -eq "Network security" }
        "Recovery console" = $detailedFindings | Where-Object { $_.category -eq "Recovery consoley" }
        "Shutdown" = $detailedFindings | Where-Object { $_.category -eq "Shutdown" }
        "System cryptography" = $detailedFindings | Where-Object { $_.category -eq "System cryptography" }
        "System objects" = $detailedFindings | Where-Object { $_.category -eq "System objects" }
        "System settings" = $detailedFindings | Where-Object { $_.category -eq "System settings" }
        "User Account Control" = $detailedFindings | Where-Object { $_.category -eq "User Account Control" }
    }
    "Event Log" = @{}

    "Restricted Groups" = @{}

    "System Services" = @{
        "System Services" = $detailedFindings | Where-Object { $_.category -eq "System Services" }
    }

    "Registry" = @{}

    "File System" = @{}

    "Wired Network (IEEE 802.3) Policies" = @{}

    "Windows Defender Firewall with Advanced Security (formerly Windows Firewall with 
Advanced Security)" = @{
        "Domain Profile" = $detailedFindings | Where-Object { $_.category -eq "Domain Profile" }
        "Private Profile" = $detailedFindings | Where-Object { $_.category -eq "Private Profile" }
        "Public Profile" = $detailedFindings | Where-Object { $_.category -eq "Public Profile" }
    }

    "Network List Manager Policies" = @{}

    "Wireless Network (IEEE 802.11) Policies" = @{}

    "Public Key Policies" = @{}

    "Software Restriction Policies" = @{}

    "Network Access Protection NAP Client Configuration" = @{}

    "Application Control Policies" = @{}

    "IP Security Policies" = @{}

    "Advanced Audit Policy Configuration" = @{
        "Account Logon" = $detailedFindings | Where-Object { $_.category -eq "Account Logon" }
        "Account Management" = $detailedFindings | Where-Object { $_.category -eq "Account Management" }
        "Detailed Tracking" = $detailedFindings | Where-Object { $_.category -eq "Detailed Tracking" }
        "DS Access" = $detailedFindings | Where-Object { $_.category -eq "DS Access" }
        "Logon/Logoff" = $detailedFindings | Where-Object { $_.category -eq "Logon/Logoff" }
        "Object Access" = $detailedFindings | Where-Object { $_.category -eq "Object Access" }
        "Policy Change" = $detailedFindings | Where-Object { $_.category -eq "Policy Change" }
        "Privilege Use" = $detailedFindings | Where-Object { $_.category -eq "Privilege Use" }
        "System" = $detailedFindings | Where-Object { $_.category -eq "System" }
    }

    "Administrative Templates (Computer)" = @{
        "Control Panel" = $detailedFindings | Where-Object { $_.category -eq "Control Panel" }
        "Desktop" = $detailedFindings | Where-Object { $_.category -eq "Desktop" }
        "LAPS (legacy)" = $detailedFindings | Where-Object { $_.category -eq "LAPS (legacy)" }
        "MS Security Guide" = $detailedFindings | Where-Object { $_.category -eq "MS Security Guide" }
        "MSS (Legacy)" = $detailedFindings | Where-Object { $_.category -eq "MSS (Legacy)" }
        "Network" = $detailedFindings | Where-Object { $_.category -eq "Network" }
        "Printers" = $detailedFindings | Where-Object { $_.category -eq "Printers" }
        "Start Menu and Taskbar" = $detailedFindings | Where-Object { $_.category -eq "Start Menu and Taskbar" }
        "System" = $detailedFindings | Where-Object { $_.category -eq "System" }
        "Device Installation" = $detailedFindings | Where-Object { $_.category -eq "Device Installation" }
        "Windows Components" = $detailedFindings | Where-Object { $_.category -eq "Windows Components" }
    }

    "Administrative Templates (User)" = @{
        "Control Panel" = $detailedFindings | Where-Object { $_.category -eq "Control Panel" }
        "Desktop" = $detailedFindings | Where-Object { $_.category -eq "Desktop" }
        "Network" = $detailedFindings | Where-Object { $_.category -eq "Network" }
        "Shared Folders" = $detailedFindings | Where-Object { $_.category -eq "Shared Folders" }
        "Start Menu and Taskbar" = $detailedFindings | Where-Object { $_.category -eq "Start Menu and Taskbar" }
        "System" = $detailedFindings | Where-Object { $_.category -eq "System" }
        "Windows Components" = $detailedFindings | Where-Object { $_.category -eq "Windows Components" }
    }
}


# Combine all parts into the final report
$finalReport = [ordered]@{
    summary = $summary
    report_metadata = $reportMetadata
    #detailed_findings = $detailedFindings
    categorized_results = $categorizedResults
}

# Generate a timestamp
$timestamp = (Get-Date).ToString("yyyyMMddHHmmss")

# Ensure the results folder exists
$resultsFolder = "$PSScriptRoot\..\..\results"
if (-not (Test-Path -Path $resultsFolder)) {
    New-Item -ItemType Directory -Path $resultsFolder | Out-Null
}

# Ensure the results folder exists
$resultsFolder = "$PSScriptRoot\..\..\results"
if (-not (Test-Path -Path $resultsFolder)) {
    New-Item -ItemType Directory -Path $resultsFolder | Out-Null
}

# Save the audit results with a timestamp in the filename
$resultsFilePath = "$resultsFolder\windows11Standalone_audit_results_$timestamp.json"

# Assuming $auditResults is the variable containing your results
$auditResults | ConvertTo-Json -Depth 4 | Out-File -FilePath $resultsFilePath -Encoding utf8

# Output the JSON results to standard output
$finalReport | ConvertTo-Json -Depth 4