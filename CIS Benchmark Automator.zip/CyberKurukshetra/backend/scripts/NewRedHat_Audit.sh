#!/bin/bash

# Function to check prerequisites
install_prerequisites() {
    echo "Checking prerequisites..."
    if ! command -v jq &> /dev/null; then
        echo "jq is not installed. Installing jq..."
        if [ -f /etc/redhat-release ]; then
            sudo yum install jq -y
        elif [ -f /etc/debian_version ]; then
            sudo apt update && sudo apt install jq -y
        else
            echo "Unsupported OS. Please install jq manually."
            exit 1
        fi
    else
        echo "jq is already installed."
    fi
}

# Ensure the script is running with root privileges
if [ "$EUID" -ne 0 ]; then
    echo "Please run this script as root (use sudo)."
    exit 1
fi

# Install prerequisites
install_prerequisites

# Generate timestamp
TIMESTAMP=$(date --iso-8601=seconds)

# Define controls, categories, priorities, and severities
declare -A controls
controls["1.1.1"]="Ensure the system has a password policy enforcing password history."
controls["1.1.2"]="Ensure the maximum password age is set to 365 days or less, but not 0."
controls["1.1.3"]="Ensure the minimum password age is set to 1 or more days."
controls["1.1.4"]="Ensure the minimum password length is set to 14 or more characters."
controls["1.1.5"]="Ensure password complexity requirements are enabled."

declare -A categories
categories["1.1.1"]="Password Policy"
categories["1.1.2"]="Password Policy"
categories["1.1.3"]="Password Policy"
categories["1.1.4"]="Password Policy"
categories["1.1.5"]="Password Policy"

declare -A priorities
priorities["1.1.1"]="High"
priorities["1.1.2"]="Medium"
priorities["1.1.3"]="Low"
priorities["1.1.4"]="High"
priorities["1.1.5"]="High"

declare -A severities
severities["1.1.1"]="High"
severities["1.1.2"]="Medium"
severities["1.1.3"]="Low"
severities["1.1.4"]="High"
severities["1.1.5"]="High"

# Helper function to check compliance
check_control() {
    local control_id=$1
    local command=$2
    local expected=$3
    local result
    result=$(eval "$command")

    if [[ "$result" == "$expected" ]]; then
        echo "true"
    elif [[ -z "$result" ]]; then
        echo "null"
    else
        echo "false"
    fi
}

# Define checks
declare -A checks
checks["1.1.1"]="grep 'remember' /etc/security/pwquality.conf | awk '{print \$NF}'"
checks["1.1.2"]="grep 'PASS_MAX_DAYS' /etc/login.defs | awk '{print \$2}'"
checks["1.1.3"]="grep 'minlen' /etc/security/pwquality.conf | awk '{print \$NF}'"
checks["1.1.4"]="grep 'ucredit=' /etc/security/pwquality.conf | wc -l"
checks["1.1.5"]="grep 'rotate' /etc/logrotate.conf | awk '{print \$2}'"

# Expected values
declare -A expected_values
expected_values["1.1.1"]="5"
expected_values["1.1.2"]="365"
expected_values["1.1.3"]="1"
expected_values["1.1.4"]="14"
expected_values["1.1.5"]="1"

# Initialize counters for summary
total_controls=0
compliant_controls=0
non_compliant_controls=0
declare -A priority_counts
priority_counts["Low"]=0
priority_counts["Medium"]=0
priority_counts["High"]=0

# Prepare JSON structure
detailed_findings=""
categorized_results=""

# Loop through controls
for control_id in "${!controls[@]}"; do
    total_controls=$((total_controls + 1))
    compliance=$(check_control "$control_id" "${checks[$control_id]}" "${expected_values[$control_id]}")

    if [[ "$compliance" == "true" ]]; then
        compliant_controls=$((compliant_controls + 1))
    elif [[ "$compliance" == "false" ]]; then
        non_compliant_controls=$((non_compliant_controls + 1))
    fi

    priority_counts["${priorities[$control_id]}"]=$((priority_counts["${priorities[$control_id]}"] + 1))

    detailed_findings+="{
        \"control_id\": \"$control_id\",
        \"description\": \"${controls[$control_id]}\",
        \"priority\": \"${priorities[$control_id]}\",
        \"severity\": \"${severities[$control_id]}\",
        \"is_compliant\": $compliance,
        \"last_checked\": \"$TIMESTAMP\",
        \"recommendation\": \"Review and update system settings as per the control's requirements.\",
        \"non_compliance_reasons\": \"To be determined.\",
        \"frequency_checked\": 1
    },"
done

# Build summary
summary="{
    \"priority_breakdown\": {
        \"Low\": ${priority_counts["Low"]},
        \"Medium\": ${priority_counts["Medium"]},
        \"High\": ${priority_counts["High"]}
    },
    \"total_controls\": $total_controls,
    \"severity_breakdown\": {
        \"Low\": ${priority_counts["Low"]},
        \"Medium\": ${priority_counts["Medium"]},
        \"High\": ${priority_counts["High"]}
    },
    \"compliant_controls\": $compliant_controls,
    \"compliance_percentage\": $(echo "scale=2; ($compliant_controls / $total_controls) * 100" | bc),
    \"non_compliant_controls\": $non_compliant_controls
}"

# Build metadata
metadata="{
    \"report_title\": \"Extended Compliance Report\",
    \"generated_on\": \"$TIMESTAMP\",
    \"generated_by\": \"System Auditor\",
    \"report_version\": \"2.0\",
    \"audit_scope\": \"Linux System\"
}"

# Final JSON
json="{
    \"summary\": $summary,
    \"report_metadata\": $metadata,
    \"detailed_findings\": [${detailed_findings%,}],
    \"categorized_results\": {}
}"

# Save to file
output_file="formatted_compliance_report.json"
echo "$json" > "$output_file"

echo "Compliance report generated: $output_file"
