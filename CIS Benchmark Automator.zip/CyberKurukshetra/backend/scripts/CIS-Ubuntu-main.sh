#!/bin/bash

# Define the directory containing all the CIS control scripts
scripts_dir="/CIS-Ubuntu-22.04"

# Output file for the results
output_file="\..\..\results\cis_ubuntu22_audit_output.json"
echo "{" > "$output_file"

# Counter for control IDs
control_counter=1

# Get the total number of scripts to handle the comma at the end
total_scripts=$(ls "$scripts_dir"/*.sh | wc -l)
current_script=1

# Loop through all .sh files in the directory
for script in "$scripts_dir"/*.sh; do
  if [[ -f "$script" ]]; then
    # Extract the file name (without the directory path and extension)
    file_name=$(basename "$script" .sh)

    # Start writing the control result to the JSON file
    echo "  \"$file_name\": {" >> "$output_file"

    # Execute the script and capture the output
    output=$(bash "$script" 2>&1)

    # Check if the script executed successfully or failed
    if [[ $? -eq 0 ]]; then
      status="Pass"
      message="Control executed successfully."
    else
      status="Error"
      message="Error during execution: $output"
    fi

    # Write the result to the JSON output
    echo "    \"Message\": \"$message\"," >> "$output_file"
    echo "    \"CorrectiveAction\": \"Refer to the CIS documentation for remediation steps.\"," >> "$output_file"
    echo "    \"Description\": \"Control description for $file_name\"," >> "$output_file"
    echo "    \"Recommendation\": \"Review and fix the issue for $file_name.\"," >> "$output_file"
    echo "    \"Category\": \"General\"," >> "$output_file"
    echo "    \"Presence\": \"\"," >> "$output_file"
    echo "    \"LastChecked\": \"$(date --iso-8601=seconds)\"," >> "$output_file"
    echo "    \"Severity\": \"Medium\"," >> "$output_file"
    echo "    \"Status\": \"$status\"," >> "$output_file"
    echo "    \"Priority\": \"Medium\"" >> "$output_file"
    echo "  }" >> "$output_file"

    # Add a comma if this is not the last script
    if [[ "$current_script" -lt "$total_scripts" ]]; then
      echo "," >> "$output_file"
    fi

    # Increment the control counter and script counter
    ((control_counter++))
    ((current_script++))
  fi
done

# Finalize the JSON structure
echo "}" >> "$output_file"

# Inform the user
echo "Audit complete. Results saved to $output_file."