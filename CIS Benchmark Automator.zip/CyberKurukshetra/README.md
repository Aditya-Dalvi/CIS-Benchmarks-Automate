SIH Project

please create python virtual environment and then run the project.

For windows:-
python -m venv venv
venv\Scripts\activate or source venv/Scripts/activate