// Show the loader
function showLoader(message = "Processing your request. Please wait...") {
    const loaderOverlay = document.getElementById('loaderOverlay');
    loaderOverlay.style.display = 'flex';
    loaderOverlay.querySelector('p').innerText = message;
}

// Hide the loader
function hideLoader() {
    const loaderOverlay = document.getElementById('loaderOverlay');
    loaderOverlay.style.display = 'none';
}

// Add event listener for the "Start Audit Scan" button
document.getElementById('startAuditBtn').addEventListener('click', () => {
    // Show loader and update message
    showLoader("Running audit scan. This may take a moment...");

    // Disable the button to prevent multiple clicks
    document.getElementById('startAuditBtn').disabled = true;
    document.getElementById('startAuditBtn').innerText = 'Running Audit...';

    // Hide the result table initially
    document.getElementById('resultTable').innerHTML = '';

    // Call the API to trigger the audit
    fetch('/api/audit', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${localStorage.getItem('access_token')}`
        }
    })
    .then(response => {
        if (response.ok) {
            // Wait for 10 seconds before showing the buttons and table
            setTimeout(() => {
                // Show the buttons and update UI
                document.querySelectorAll('.button-group button').forEach(button => {
                    button.style.display = 'inline-block';
                });
                // Reset the start button
                document.getElementById('startAuditBtn').disabled = false;
                document.getElementById('startAuditBtn').innerText = 'Start Audit Scan';
                hideLoader(); // Hide loader after buttons appear
                fetchDataAndRender('summary', 'Summary');
            }, 10000); // 10 seconds delay
        } else {
            return response.json();
        }
    })
    .then(data => {
        if (data && data.error) {
            alert(`Error: ${data.error}`);
        }
    })
    .catch(error => {
        console.error('Error starting audit:', error);
        alert('An error occurred while starting the audit.');
        // Reset the start button on error
        document.getElementById('startAuditBtn').disabled = false;
        document.getElementById('startAuditBtn').innerText = 'Start Audit Scan';
        hideLoader(); // Hide loader on error
    });
});

// Add event listeners for the permanent buttons
document.getElementById('showSummaryBtn').addEventListener('click', () => {
    showLoader("Fetching summary results...");
    fetchDataAndRender('summary', 'Summary');
});

document.getElementById('showMetadataBtn').addEventListener('click', () => {
    showLoader("Fetching report metadata...");
    fetchDataAndRender('report_metadata', 'Report Metadata');
});

document.getElementById('showCategorizedBtn').addEventListener('click', () => {
    showLoader("Fetching categorized results...");
    fetchDataAndRender('categorized_results', 'Categorized Results');
});

// Function to fetch data and render the corresponding table
function fetchDataAndRender(section, title) {
    const token = localStorage.getItem('access_token');

    fetch('/api/audit', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.results) {
            let sectionData = data.results[section];
            if (section === 'categorized_results') {
                renderCategorizedResults(document.getElementById('resultTable'), sectionData);
            } else {
                if (!Array.isArray(sectionData)) {
                    sectionData = [sectionData]; // Wrap single objects in an array
                }
                renderTable(document.getElementById('resultTable'), sectionData, title);
            }
        } else if (data.error) {
            document.getElementById('resultTable').innerHTML = `<p>${data.error}</p>`;
        }
        hideLoader(); // Hide loader after data is fetched and rendered
    })
    .catch(error => {
        console.error('Error:', error);
        document.getElementById('resultTable').innerHTML = '<p>An error occurred while fetching the data.</p>';
        hideLoader(); // Hide loader on error
    });
}

// Function to render categorized results dynamically
function renderCategorizedResults(container, data) {
    let html = '';

    for (const [category, categoryData] of Object.entries(data)) {
        let categoryContent = '';

        for (const [subcategory, subcategoryData] of Object.entries(categoryData)) {
            if (Array.isArray(subcategoryData) && subcategoryData.length > 0) {
                categoryContent += `
                    <h4>${subcategory}</h4>
                    <div class="table-container">
                        <table>
                            <thead>
                                <tr>
                                    <th>Recommendation</th>
                                    <th>Corrective Action</th>
                                    <th>Severity</th>
                                    <th>Description</th>
                                    <th>Priority</th>
                                    <th>Is Compliant</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${subcategoryData.map(item => `
                                    <tr>
                                        <td>${item.recommendation || 'N/A'}</td>
                                        <td>${item.corrective_action || 'N/A'}</td>
                                        <td>${item.severity || 'N/A'}</td>
                                        <td>${item.description || 'N/A'}</td>
                                        <td>${item.priority || 'N/A'}</td>
                                        <td>${item.is_compliant ? 'Yes' : 'No'}</td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                `;
            }
        }

        if (categoryContent) {
            html += `<h3>${category}</h3>${categoryContent}`;
        }
    }

    container.innerHTML = html || '<p>No valid data available to display.</p>';
}

// Function to render general tables for non-categorized sections
function renderTable(container, data, title) {
    container.innerHTML = `
        <h3>${title}</h3>
        <div class="table-container">
            <table>
                <thead>
                    <tr>${Object.keys(data[0]).map(key => `<th>${key}</th>`).join('')}</tr>
                </thead>
                <tbody>
                    ${data.map(row => `
                        <tr>${Object.values(row).map(value => `
                            <td>${typeof value === 'object' ? formatNestedObject(value) : value}</td>
                        `).join('')}</tr>
                    `).join('')}
                </tbody>
            </table>
        </div>
    `;
}

// Helper function for formatting nested objects
function formatNestedObject(obj) {
    return Object.entries(obj)
        .map(([key, value]) => `<b>${key}:</b> ${value}`)
        .join('<br>');
}
