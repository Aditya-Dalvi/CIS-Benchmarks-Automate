document.addEventListener('DOMContentLoaded', function() {
    const signupBtn = document.getElementById('signupBtn');
    const signinBtn = document.getElementById('signinBtn');

    function showAlert(message, type) {
        const alertBox = document.getElementById('customAlert');
        const alertMessage = document.getElementById('alertMessage');
        const closeAlert = document.getElementById('closeAlert');
    
        // Update message and class for the alert box
        alertMessage.textContent = message;
        alertBox.className = `alert ${type}`; // Ensure classes are not overridden (e.g., 'alert success' or 'alert danger')
        alertBox.classList.remove('hidden');
    
        // Remove any previously added click event listener on the close button
        closeAlert.onclick = () => {
            alertBox.classList.add('hidden');
        };
    
        // Clear any existing timeout to avoid multiple timers
        if (alertBox.timeoutId) {
            clearTimeout(alertBox.timeoutId);
        }
    
        // Auto-hide the alert after 5 seconds
        alertBox.timeoutId = setTimeout(() => {
            alertBox.classList.add('hidden');
        }, 5000);
    }
    

    signupBtn.addEventListener('click', function() {
        const username = document.getElementById('signupUsername').value;
        const email = document.getElementById('signupEmail').value;
        const password = document.getElementById('signupPassword').value;

        fetch('/signup', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username: username, email: email, password: password })
        })
        .then(response => response.json())
        .then(data => {
            if (data.message) {
                showAlert('Signup successful!', 'success');
            } else if (data.error) {
                showAlert('Signup failed: ' + data.error, 'danger');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showAlert('An error occurred. Please try again.', 'danger');
        });
    });

    signinBtn.addEventListener('click', function() {
        const username = document.getElementById('signinUsername').value;
        const password = document.getElementById('signinPassword').value;

        fetch('/signin', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username: username, password: password })
        })
        .then(response => response.json())
        .then(data => {
            if (data.access_token) {
                showAlert('Sign in successful!', 'success');
                localStorage.setItem('access_token', data.access_token);
                window.location.href = '/audit';
            } else if (data.error) {
                showAlert('Sign in failed: ' + data.error, 'danger');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showAlert('An error occurred. Please try again.', 'danger');
        });
    });
});
